# Owned publication child processes and source-gate execution.

function ConvertTo-DeliveryUtcDateTime {
    param([Parameter(Mandatory = $true)][AllowNull()][object]$Value)

    if ($Value -is [DateTimeOffset]) { return ([DateTimeOffset]$Value).UtcDateTime }
    if ($Value -is [DateTime]) { return ([DateTime]$Value).ToUniversalTime() }
    if ($Value -isnot [string] -or [string]::IsNullOrWhiteSpace([string]$Value)) {
        throw "Delivery timestamp must be a DateTime, DateTimeOffset, or round-trip string."
    }
    return [DateTimeOffset]::Parse(
        [string]$Value,
        [Globalization.CultureInfo]::InvariantCulture,
        [Globalization.DateTimeStyles]::RoundtripKind
    ).UtcDateTime
}

function Get-SourceGateHardBudgetSeconds {
    param(
        [Parameter(Mandatory = $true)][string]$Mode,
        [Parameter(Mandatory = $true)][string]$WorkingRoot,
        [switch]$AllowMissingCatalog
    )

    # An injected gate is not the repository quality gate and may use a
    # deliberately minimal fixture repository. Give it the maximum wrapper
    # allowance; its own process remains subject to the no-progress watchdog.
    if ($AllowMissingCatalog) { return 7500 }

    $catalogPath = Join-Path $WorkingRoot "tests\quality-contracts.json"
    if (-not (Test-Path -LiteralPath $catalogPath -PathType Leaf)) {
        throw "Quality contract catalog is missing: $catalogPath"
    }
    $catalog = Get-Content -LiteralPath $catalogPath -Raw -Encoding UTF8 | ConvertFrom-Json
    $effectiveMode = if ($Mode -eq "Fast") { "Smoke" } else { $Mode }
    $budgetPrefix = $effectiveMode.Substring(0, 1).ToLowerInvariant() + $effectiveMode.Substring(1)
    $propertyName = "${budgetPrefix}HardSeconds"
    $property = $catalog.budgets.PSObject.Properties[$propertyName]
    if (-not $property -or [int]$property.Value -le 0) { throw "Invalid $effectiveMode hard budget in the quality contract catalog." }

    # The child owns the authoritative gate budget. The wrapper only adds time
    # for the child to finalize its summary and exit without racing that budget.
    $hardSeconds = [int]$property.Value
    if ($effectiveMode -eq 'Release' -and (Test-Path -LiteralPath (Join-Path $WorkingRoot 'scripts/release-e2e/stages.json') -PathType Leaf)) {
        $stages = Get-QualityReleaseStageCatalog -RepositoryRoot $WorkingRoot
        $projection = Get-ReleaseE2EBudgetProjection -StageCatalog $stages -QualityCatalog $catalog -RequireRelease
        $hardSeconds = [int]$projection.gateHardSeconds
    }
    return $hardSeconds + 300
}

function Get-SourceGateSupervisionBudgetSeconds {
    param(
        [Parameter(Mandatory = $true)][string]$Mode,
        [Parameter(Mandatory = $true)][string]$WorkingRoot,
        [int]$PlanBudgetSeconds = 0,
        [switch]$InjectedGate
    )

    if ($InjectedGate -and $PlanBudgetSeconds -gt 0) { return $PlanBudgetSeconds }
    $childAllowance = Get-SourceGateHardBudgetSeconds -Mode $Mode -WorkingRoot $WorkingRoot -AllowMissingCatalog:$InjectedGate
    return [Math]::Max($childAllowance, $PlanBudgetSeconds)
}

function Test-DeliveryProcessCreationIdentity {
    param([int]$ProcessId, [datetime]$CreatedAt)
    try {
        $current = Get-Process -Id $ProcessId -ErrorAction Stop
        return -not $current.HasExited -and $current.StartTime.ToUniversalTime().Ticks -eq $CreatedAt.ToUniversalTime().Ticks
    } catch { return $false }
}

function Get-DeliveryDescendantProcessIdentities {
    param([int]$RootProcessId, [datetime]$RootCreatedAt)
    if ($env:OS -ne 'Windows_NT' -or -not (Test-DeliveryProcessCreationIdentity -ProcessId $RootProcessId -CreatedAt $RootCreatedAt)) { return @() }
    try {
        $rows = @(Get-CimInstance Win32_Process -OperationTimeoutSec 1 -ErrorAction Stop)
        $knownParents = [Collections.Generic.HashSet[int]]::new()
        [void]$knownParents.Add($RootProcessId)
        $descendantIds = [Collections.Generic.List[int]]::new()
        $changed = $true
        while ($changed) {
            $changed = $false
            foreach ($row in $rows) {
                $childId = [int]$row.ProcessId
                if ($knownParents.Contains([int]$row.ParentProcessId) -and $knownParents.Add($childId)) {
                    $descendantIds.Add($childId) | Out-Null
                    $changed = $true
                }
            }
        }
        if (-not (Test-DeliveryProcessCreationIdentity -ProcessId $RootProcessId -CreatedAt $RootCreatedAt)) { return @() }
        return @($descendantIds | ForEach-Object {
            $childId = [int]$_
            try {
                $child = Get-Process -Id $childId -ErrorAction Stop
                $createdAt = $child.StartTime.ToUniversalTime()
                if (-not $child.HasExited -and $createdAt -ge $RootCreatedAt.ToUniversalTime()) {
                    [pscustomobject]@{ processId=$childId; createdAt=$createdAt }
                }
            } catch {}
        })
    } catch { return @() }
}

function Stop-DeliveryProcessTree {
    param([AllowNull()][object]$Process, [int]$TimeoutMilliseconds = 5000, [object[]]$CapturedDescendants = @())
    if (-not $Process) { return }
    try {
        $processId = [int]$Process.Id
        $processStartedAt = $Process.StartTime.ToUniversalTime()
        $processExited = [bool]$Process.HasExited
        $processExitedAt = if ($processExited) { $Process.ExitTime.ToUniversalTime() } else { [DateTime]::MaxValue }
    } catch { return }
    $deadline = [DateTime]::UtcNow.AddMilliseconds([Math]::Max(1, $TimeoutMilliseconds))
    $rootIdentityLive = -not $processExited -and (Test-DeliveryProcessCreationIdentity -ProcessId $processId -CreatedAt $processStartedAt)
    try {
        if ($env:OS -eq "Windows_NT" -and $rootIdentityLive -and (Test-DeliveryProcessCreationIdentity -ProcessId $processId -CreatedAt $processStartedAt)) {
            # Use the .NET launcher instead of a PowerShell native-command
            # pipeline: Ctrl+C stops that pipeline, while finally still needs
            # to run taskkill for every descendant owned by the gate.
            $taskkillPath = Join-Path $env:SystemRoot "System32\taskkill.exe"
            $startInfo = [Diagnostics.ProcessStartInfo]::new()
            $startInfo.FileName = $taskkillPath
            $startInfo.Arguments = "/PID $processId /T /F"
            $startInfo.UseShellExecute = $false
            $startInfo.CreateNoWindow = $true
            $startInfo.RedirectStandardOutput = $true
            $startInfo.RedirectStandardError = $true
            $killer = [Diagnostics.Process]::Start($startInfo)
            try {
                $stdoutTask = $killer.StandardOutput.ReadToEndAsync()
                $stderrTask = $killer.StandardError.ReadToEndAsync()
                $remaining = [Math]::Max(1, [int]($deadline - [DateTime]::UtcNow).TotalMilliseconds)
                if (-not $killer.WaitForExit($remaining)) {
                    try { $killer.Kill() } catch {}
                    $remaining = [Math]::Max(1, [int]($deadline - [DateTime]::UtcNow).TotalMilliseconds)
                    try { [void]$killer.WaitForExit($remaining) } catch {}
                }
                foreach ($reader in @($stdoutTask, $stderrTask)) {
                    $remaining = [Math]::Max(1, [int]($deadline - [DateTime]::UtcNow).TotalMilliseconds)
                    try { [void]$reader.Wait($remaining) } catch {}
                }
            } finally { $killer.Dispose() }
        } elseif ($env:OS -ne "Windows_NT" -and $rootIdentityLive) {
            $Process.Kill()
        }
    } catch {}
    try {
        if ($Process.HasExited) { $processExitedAt = $Process.ExitTime.ToUniversalTime() }
    } catch {}
    foreach ($descendant in @($CapturedDescendants | Sort-Object processId -Descending)) {
        try {
            $descendantId = [int]$descendant.processId
            $descendantCreatedAt = ([DateTime]$descendant.createdAt).ToUniversalTime()
            if ($descendantCreatedAt -lt $processStartedAt -or $descendantCreatedAt -gt $processExitedAt) { continue }
            if (Test-DeliveryProcessCreationIdentity -ProcessId $descendantId -CreatedAt $descendantCreatedAt) {
                Stop-Process -Id $descendantId -Force -ErrorAction Stop
            }
        } catch {}
    }
    if (Test-DeliveryProcessCreationIdentity -ProcessId $processId -CreatedAt $processStartedAt) {
        try { $Process.Kill() } catch {}
    }
    $remaining = [Math]::Max(1, [int]($deadline - [DateTime]::UtcNow).TotalMilliseconds)
    try { [void]$Process.WaitForExit($remaining) } catch {}
}

function Start-DeliveryProcess {
    param(
        [Parameter(Mandatory = $true)][string]$ArgumentList,
        [Parameter(Mandatory = $true)][string]$WorkingDirectory,
        [Parameter(Mandatory = $true)][string]$StandardOutputPath,
        [Parameter(Mandatory = $true)][string]$StandardErrorPath
    )
    if ($env:OS -ne "Windows_NT") {
        $process = Start-Process -FilePath "powershell.exe" -ArgumentList $ArgumentList -WorkingDirectory $WorkingDirectory -RedirectStandardOutput $StandardOutputPath -RedirectStandardError $StandardErrorPath -PassThru
        $null = $process.Handle
        return [pscustomobject]@{ process = $process; jobHandle = [IntPtr]::Zero }
    }
    if (-not ("ItlDeliveryProcessJob" -as [type])) {
        Add-Type -TypeDefinition @'
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Text;

public static class ItlDeliveryProcessJob
{
    private const UInt32 JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE = 0x00002000;
    private const Int32 JobObjectBasicAccountingInformation = 1;
    private const Int32 JobObjectBasicProcessIdList = 3;
    private const Int32 JobObjectExtendedLimitInformation = 9;
    private const UInt32 EXTENDED_STARTUPINFO_PRESENT = 0x00080000;
    private const UInt32 CREATE_NO_WINDOW = 0x08000000;
    private const UInt32 CREATE_SUSPENDED = 0x00000004;
    private const UInt32 CREATE_UNICODE_ENVIRONMENT = 0x00000400;
    private const UInt32 STARTF_USESTDHANDLES = 0x00000100;
    private const UInt32 PROC_THREAD_ATTRIBUTE_HANDLE_LIST = 0x00020002;
    private const UInt32 PROC_THREAD_ATTRIBUTE_JOB_LIST = 0x0002000D;
    private const UInt32 GENERIC_READ = 0x80000000;
    private const UInt32 GENERIC_WRITE = 0x40000000;
    private const UInt32 FILE_SHARE_READ = 0x00000001;
    private const UInt32 FILE_SHARE_WRITE = 0x00000002;
    private const UInt32 CREATE_ALWAYS = 2;
    private const UInt32 OPEN_EXISTING = 3;
    private const UInt32 FILE_ATTRIBUTE_NORMAL = 0x00000080;
    private static readonly IntPtr INVALID_HANDLE_VALUE = new IntPtr(-1);

    [StructLayout(LayoutKind.Sequential)]
    private struct JOBOBJECT_BASIC_LIMIT_INFORMATION
    {
        public Int64 PerProcessUserTimeLimit;
        public Int64 PerJobUserTimeLimit;
        public UInt32 LimitFlags;
        public UIntPtr MinimumWorkingSetSize;
        public UIntPtr MaximumWorkingSetSize;
        public UInt32 ActiveProcessLimit;
        public UIntPtr Affinity;
        public UInt32 PriorityClass;
        public UInt32 SchedulingClass;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct IO_COUNTERS
    {
        public UInt64 ReadOperationCount;
        public UInt64 WriteOperationCount;
        public UInt64 OtherOperationCount;
        public UInt64 ReadTransferCount;
        public UInt64 WriteTransferCount;
        public UInt64 OtherTransferCount;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct JOBOBJECT_EXTENDED_LIMIT_INFORMATION
    {
        public JOBOBJECT_BASIC_LIMIT_INFORMATION BasicLimitInformation;
        public IO_COUNTERS IoInfo;
        public UIntPtr ProcessMemoryLimit;
        public UIntPtr JobMemoryLimit;
        public UIntPtr PeakProcessMemoryUsed;
        public UIntPtr PeakJobMemoryUsed;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct SECURITY_ATTRIBUTES
    {
        public Int32 nLength;
        public IntPtr lpSecurityDescriptor;
        [MarshalAs(UnmanagedType.Bool)] public bool bInheritHandle;
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    private struct STARTUPINFOEX
    {
        public Int32 cb;
        public string lpReserved;
        public string lpDesktop;
        public string lpTitle;
        public UInt32 dwX;
        public UInt32 dwY;
        public UInt32 dwXSize;
        public UInt32 dwYSize;
        public UInt32 dwXCountChars;
        public UInt32 dwYCountChars;
        public UInt32 dwFillAttribute;
        public UInt32 dwFlags;
        public UInt16 wShowWindow;
        public UInt16 cbReserved2;
        public IntPtr lpReserved2;
        public IntPtr hStdInput;
        public IntPtr hStdOutput;
        public IntPtr hStdError;
        public IntPtr lpAttributeList;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct PROCESS_INFORMATION
    {
        public IntPtr hProcess;
        public IntPtr hThread;
        public UInt32 dwProcessId;
        public UInt32 dwThreadId;
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    private struct RTL_OSVERSIONINFOEX
    {
        public UInt32 dwOSVersionInfoSize;
        public UInt32 dwMajorVersion;
        public UInt32 dwMinorVersion;
        public UInt32 dwBuildNumber;
        public UInt32 dwPlatformId;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)] public string szCSDVersion;
        public UInt16 wServicePackMajor;
        public UInt16 wServicePackMinor;
        public UInt16 wSuiteMask;
        public Byte wProductType;
        public Byte wReserved;
    }

    public sealed class StartedProcess
    {
        public Process Process;
        public IntPtr JobHandle;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct JOBOBJECT_BASIC_ACCOUNTING_INFORMATION
    {
        public Int64 TotalUserTime;
        public Int64 TotalKernelTime;
        public Int64 ThisPeriodTotalUserTime;
        public Int64 ThisPeriodTotalKernelTime;
        public UInt32 TotalPageFaultCount;
        public UInt32 TotalProcesses;
        public UInt32 ActiveProcesses;
        public UInt32 TotalTerminatedProcesses;
    }

    [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    private static extern IntPtr CreateJobObject(IntPtr jobAttributes, string name);

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern bool SetInformationJobObject(IntPtr job, Int32 informationClass, ref JOBOBJECT_EXTENDED_LIMIT_INFORMATION information, UInt32 informationLength);

    [DllImport("kernel32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool TerminateJobObject(IntPtr job, UInt32 exitCode);

    [DllImport("kernel32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool QueryInformationJobObject(IntPtr job, Int32 informationClass, out JOBOBJECT_BASIC_ACCOUNTING_INFORMATION information, UInt32 informationLength, IntPtr returnLength);

    [DllImport("kernel32.dll", EntryPoint = "QueryInformationJobObject", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool QueryJobProcessIdList(IntPtr job, Int32 informationClass, IntPtr information, UInt32 informationLength, IntPtr returnLength);

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern IntPtr OpenProcess(UInt32 desiredAccess, bool inheritHandle, UInt32 processId);

    [DllImport("kernel32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool IsProcessInJob(IntPtr process, IntPtr job, [MarshalAs(UnmanagedType.Bool)] out bool result);

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern UInt32 WaitForSingleObject(IntPtr handle, UInt32 milliseconds);

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern bool CloseHandle(IntPtr handle);

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern bool InitializeProcThreadAttributeList(IntPtr attributeList, Int32 attributeCount, UInt32 flags, ref IntPtr size);

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern bool UpdateProcThreadAttribute(IntPtr attributeList, UInt32 flags, IntPtr attribute, IntPtr value, IntPtr size, IntPtr previousValue, IntPtr returnSize);

    [DllImport("kernel32.dll")]
    private static extern void DeleteProcThreadAttributeList(IntPtr attributeList);

    [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    private static extern IntPtr CreateFile(string fileName, UInt32 desiredAccess, UInt32 shareMode, ref SECURITY_ATTRIBUTES securityAttributes, UInt32 creationDisposition, UInt32 flagsAndAttributes, IntPtr templateFile);

    [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool CreateProcess(string applicationName, StringBuilder commandLine, IntPtr processAttributes, IntPtr threadAttributes, bool inheritHandles, UInt32 creationFlags, IntPtr environment, string currentDirectory, ref STARTUPINFOEX startupInfo, out PROCESS_INFORMATION processInformation);

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern UInt32 ResumeThread(IntPtr thread);

    [DllImport("ntdll.dll", CharSet = CharSet.Unicode)]
    private static extern Int32 RtlGetVersion(ref RTL_OSVERSIONINFOEX versionInformation);

    private static void AssertAtomicJobListSupport()
    {
        RTL_OSVERSIONINFOEX version = new RTL_OSVERSIONINFOEX();
        version.dwOSVersionInfoSize = (UInt32)Marshal.SizeOf(typeof(RTL_OSVERSIONINFOEX));
        Int32 status = RtlGetVersion(ref version);
        if (status != 0)
            throw new PlatformNotSupportedException("Unable to verify Windows 10 or Windows Server 2016+ support required for atomic publication child process ownership (RtlGetVersion status " + status + ").");
        if (version.dwMajorVersion < 10)
            throw new PlatformNotSupportedException("Atomic publication child process ownership requires Windows 10 or Windows Server 2016+; detected Windows " + version.dwMajorVersion + "." + version.dwMinorVersion + " build " + version.dwBuildNumber + ".");
    }

    private static IntPtr CreateInheritedFile(string path, UInt32 access, UInt32 disposition)
    {
        SECURITY_ATTRIBUTES attributes = new SECURITY_ATTRIBUTES();
        attributes.nLength = Marshal.SizeOf(typeof(SECURITY_ATTRIBUTES));
        attributes.bInheritHandle = true;
        IntPtr handle = CreateFile(path, access, FILE_SHARE_READ | FILE_SHARE_WRITE, ref attributes, disposition, FILE_ATTRIBUTE_NORMAL, IntPtr.Zero);
        if (handle == INVALID_HANDLE_VALUE) throw new Win32Exception(Marshal.GetLastWin32Error(), "CreateFile failed for " + path + ".");
        return handle;
    }

    private static IntPtr CreateEnvironmentWithout(string excludedName)
    {
        SortedDictionary<string, string> variables = new SortedDictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        foreach (DictionaryEntry entry in Environment.GetEnvironmentVariables())
        {
            string name = Convert.ToString(entry.Key);
            if (!String.Equals(name, excludedName, StringComparison.OrdinalIgnoreCase))
                variables[name] = Convert.ToString(entry.Value);
        }
        StringBuilder block = new StringBuilder();
        foreach (KeyValuePair<string, string> variable in variables)
            block.Append(variable.Key).Append('=').Append(variable.Value).Append('\0');
        block.Append('\0');
        return Marshal.StringToHGlobalUni(block.ToString());
    }

    public static StartedProcess Start(string executable, string arguments, string workingDirectory, string standardOutputPath, string standardErrorPath, bool resetPowerShellModulePath)
    {
        AssertAtomicJobListSupport();
        IntPtr job = CreateJobObject(IntPtr.Zero, null);
        if (job == IntPtr.Zero) throw new Win32Exception(Marshal.GetLastWin32Error(), "CreateJobObject failed.");
        IntPtr attributeList = IntPtr.Zero;
        IntPtr jobList = IntPtr.Zero;
        IntPtr handleList = IntPtr.Zero;
        IntPtr standardInput = IntPtr.Zero;
        IntPtr standardOutput = IntPtr.Zero;
        IntPtr standardError = IntPtr.Zero;
        IntPtr environment = IntPtr.Zero;
        PROCESS_INFORMATION processInformation = new PROCESS_INFORMATION();
        try
        {
            JOBOBJECT_EXTENDED_LIMIT_INFORMATION information = new JOBOBJECT_EXTENDED_LIMIT_INFORMATION();
            information.BasicLimitInformation.LimitFlags = JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE;
            UInt32 length = (UInt32)Marshal.SizeOf(typeof(JOBOBJECT_EXTENDED_LIMIT_INFORMATION));
            if (!SetInformationJobObject(job, JobObjectExtendedLimitInformation, ref information, length))
                throw new Win32Exception(Marshal.GetLastWin32Error(), "SetInformationJobObject failed.");

            IntPtr attributeSize = IntPtr.Zero;
            InitializeProcThreadAttributeList(IntPtr.Zero, 2, 0, ref attributeSize);
            attributeList = Marshal.AllocHGlobal(attributeSize);
            if (!InitializeProcThreadAttributeList(attributeList, 2, 0, ref attributeSize))
                throw new Win32Exception(Marshal.GetLastWin32Error(), "InitializeProcThreadAttributeList failed.");

            jobList = Marshal.AllocHGlobal(IntPtr.Size);
            Marshal.WriteIntPtr(jobList, job);
            if (!UpdateProcThreadAttribute(attributeList, 0, new IntPtr(PROC_THREAD_ATTRIBUTE_JOB_LIST), jobList, new IntPtr(IntPtr.Size), IntPtr.Zero, IntPtr.Zero))
                throw new Win32Exception(Marshal.GetLastWin32Error(), "UpdateProcThreadAttribute for the delivery job failed.");

            standardInput = CreateInheritedFile("NUL", GENERIC_READ, OPEN_EXISTING);
            standardOutput = CreateInheritedFile(standardOutputPath, GENERIC_WRITE, CREATE_ALWAYS);
            standardError = CreateInheritedFile(standardErrorPath, GENERIC_WRITE, CREATE_ALWAYS);
            handleList = Marshal.AllocHGlobal(IntPtr.Size * 3);
            Marshal.WriteIntPtr(handleList, 0, standardInput);
            Marshal.WriteIntPtr(handleList, IntPtr.Size, standardOutput);
            Marshal.WriteIntPtr(handleList, IntPtr.Size * 2, standardError);
            if (!UpdateProcThreadAttribute(attributeList, 0, new IntPtr(PROC_THREAD_ATTRIBUTE_HANDLE_LIST), handleList, new IntPtr(IntPtr.Size * 3), IntPtr.Zero, IntPtr.Zero))
                throw new Win32Exception(Marshal.GetLastWin32Error(), "UpdateProcThreadAttribute for delivery standard handles failed.");

            STARTUPINFOEX startupInfo = new STARTUPINFOEX();
            startupInfo.cb = Marshal.SizeOf(typeof(STARTUPINFOEX));
            startupInfo.dwFlags = STARTF_USESTDHANDLES;
            startupInfo.hStdInput = standardInput;
            startupInfo.hStdOutput = standardOutput;
            startupInfo.hStdError = standardError;
            startupInfo.lpAttributeList = attributeList;
            StringBuilder commandLine = new StringBuilder("\"" + executable + "\" " + arguments);
            UInt32 creationFlags = EXTENDED_STARTUPINFO_PRESENT | CREATE_NO_WINDOW | CREATE_SUSPENDED;
            if (resetPowerShellModulePath)
            {
                environment = CreateEnvironmentWithout("PSModulePath");
                creationFlags |= CREATE_UNICODE_ENVIRONMENT;
            }
            if (!CreateProcess(executable, commandLine, IntPtr.Zero, IntPtr.Zero, true, creationFlags, environment, workingDirectory, ref startupInfo, out processInformation))
                throw new Win32Exception(Marshal.GetLastWin32Error(), "CreateProcess for the delivery child failed.");
            StartedProcess started = new StartedProcess();
            started.Process = Process.GetProcessById((Int32)processInformation.dwProcessId);
            IntPtr ownedProcessHandle = started.Process.Handle;
            started.JobHandle = job;
            if (ResumeThread(processInformation.hThread) == UInt32.MaxValue)
                throw new Win32Exception(Marshal.GetLastWin32Error(), "ResumeThread for the delivery child failed.");
            job = IntPtr.Zero;
            return started;
        }
        finally
        {
            if (processInformation.hThread != IntPtr.Zero) CloseHandle(processInformation.hThread);
            if (processInformation.hProcess != IntPtr.Zero) CloseHandle(processInformation.hProcess);
            if (standardInput != IntPtr.Zero && standardInput != INVALID_HANDLE_VALUE) CloseHandle(standardInput);
            if (standardOutput != IntPtr.Zero && standardOutput != INVALID_HANDLE_VALUE) CloseHandle(standardOutput);
            if (standardError != IntPtr.Zero && standardError != INVALID_HANDLE_VALUE) CloseHandle(standardError);
            if (environment != IntPtr.Zero) Marshal.FreeHGlobal(environment);
            if (attributeList != IntPtr.Zero) { DeleteProcThreadAttributeList(attributeList); Marshal.FreeHGlobal(attributeList); }
            if (jobList != IntPtr.Zero) Marshal.FreeHGlobal(jobList);
            if (handleList != IntPtr.Zero) Marshal.FreeHGlobal(handleList);
            if (job != IntPtr.Zero) CloseHandle(job);
        }
    }

    private static void CaptureJobProcessHandles(IntPtr job, List<IntPtr> handles, Stopwatch watch, Int32 timeoutMilliseconds)
    {
        Int32 capacity = 16;
        while (true)
        {
            Int32 length = checked(8 + IntPtr.Size * capacity);
            IntPtr information = Marshal.AllocHGlobal(length);
            try
            {
                bool complete = QueryJobProcessIdList(job, JobObjectBasicProcessIdList, information, (UInt32)length, IntPtr.Zero);
                Int32 error = complete ? 0 : Marshal.GetLastWin32Error();
                if (!complete && error != 234)
                    throw new Win32Exception(error, "DELIVERY_PROCESS_JOB_QUIESCENCE_UNAVAILABLE: owned process-id list query failed.");
                Int32 assigned = Marshal.ReadInt32(information, 0);
                Int32 listed = Marshal.ReadInt32(information, 4);
                if (!complete)
                {
                    if (watch.ElapsedMilliseconds >= timeoutMilliseconds)
                        throw new TimeoutException("DELIVERY_PROCESS_JOB_QUIESCENCE_TIMEOUT: owned process-id list was not complete before the deadline.");
                    capacity = Math.Max(checked(capacity * 2), assigned);
                    continue;
                }
                if (assigned < 0 || listed < 0 || assigned != listed || listed > capacity)
                    throw new InvalidOperationException("DELIVERY_PROCESS_JOB_QUIESCENCE_UNAVAILABLE: incomplete owned process-id list.");
                for (Int32 index = 0; index < listed; index++)
                {
                    if (watch.ElapsedMilliseconds >= timeoutMilliseconds)
                        throw new TimeoutException("DELIVERY_PROCESS_JOB_QUIESCENCE_TIMEOUT: owned process handles were not captured before the deadline.");
                    UInt32 processId = checked((UInt32)Marshal.ReadIntPtr(information, 8 + IntPtr.Size * index).ToInt64());
                    IntPtr process = OpenProcess(0x00100000 | 0x00001000, false, processId);
                    if (process == IntPtr.Zero)
                        throw new Win32Exception(Marshal.GetLastWin32Error(), "DELIVERY_PROCESS_JOB_QUIESCENCE_UNAVAILABLE: could not hold an owned process handle.");
                    try
                    {
                        bool inJob;
                        if (!IsProcessInJob(process, job, out inJob))
                            throw new Win32Exception(Marshal.GetLastWin32Error(), "DELIVERY_PROCESS_JOB_QUIESCENCE_UNAVAILABLE: process job membership query failed.");
                        if (!inJob)
                            throw new InvalidOperationException("DELIVERY_PROCESS_JOB_QUIESCENCE_UNAVAILABLE: captured process no longer belongs to the owned job.");
                        handles.Add(process);
                        process = IntPtr.Zero;
                    }
                    finally { if (process != IntPtr.Zero) CloseHandle(process); }
                }
                return;
            }
            finally { Marshal.FreeHGlobal(information); }
        }
    }

    public static UInt32 StopAndWait(IntPtr job, Int32 timeoutMilliseconds)
    {
        if (job == IntPtr.Zero)
            throw new ArgumentException("DELIVERY_PROCESS_JOB_QUIESCENCE_UNAVAILABLE: no owned job handle.");
        if (timeoutMilliseconds < 0) throw new ArgumentOutOfRangeException("timeoutMilliseconds");
        Stopwatch watch = Stopwatch.StartNew();
        List<IntPtr> processes = new List<IntPtr>();
        try
        {
            CaptureJobProcessHandles(job, processes, watch, timeoutMilliseconds);
            if (!TerminateJobObject(job, 1))
                throw new Win32Exception(Marshal.GetLastWin32Error(), "DELIVERY_PROCESS_JOB_QUIESCENCE_UNAVAILABLE: TerminateJobObject failed.");
            foreach (IntPtr process in processes)
            {
                Int64 remaining = Math.Max(0, (Int64)timeoutMilliseconds - watch.ElapsedMilliseconds);
                UInt32 result = WaitForSingleObject(process, (UInt32)remaining);
                if (result == 258)
                    throw new TimeoutException("DELIVERY_PROCESS_JOB_QUIESCENCE_TIMEOUT: an owned process handle is not signaled.");
                if (result != 0)
                    throw new Win32Exception(Marshal.GetLastWin32Error(), "DELIVERY_PROCESS_JOB_QUIESCENCE_UNAVAILABLE: owned process handle wait failed.");
            }
            UInt32 length = (UInt32)Marshal.SizeOf(typeof(JOBOBJECT_BASIC_ACCOUNTING_INFORMATION));
            while (true)
            {
                JOBOBJECT_BASIC_ACCOUNTING_INFORMATION information;
                if (!QueryInformationJobObject(job, JobObjectBasicAccountingInformation, out information, length, IntPtr.Zero))
                    throw new Win32Exception(Marshal.GetLastWin32Error(), "DELIVERY_PROCESS_JOB_QUIESCENCE_UNAVAILABLE: QueryInformationJobObject failed.");
                if (information.ActiveProcesses == 0) return 0;
                Int64 remaining = (Int64)timeoutMilliseconds - watch.ElapsedMilliseconds;
                if (remaining <= 0)
                    throw new TimeoutException("DELIVERY_PROCESS_JOB_QUIESCENCE_TIMEOUT: owned job still has " + information.ActiveProcesses + " active process(es).");
                System.Threading.Thread.Sleep((Int32)Math.Min(25, remaining));
            }
        }
        finally
        {
            foreach (IntPtr process in processes) CloseHandle(process);
        }
    }

    public static void Close(IntPtr job)
    {
        if (job != IntPtr.Zero && !CloseHandle(job))
            throw new Win32Exception(Marshal.GetLastWin32Error(), "CloseHandle for delivery process job failed.");
    }
}
'@
    }
    $powershellPath = (Get-Command "powershell.exe" -ErrorAction Stop).Source
    # Native CreateProcess would pass PowerShell Core's PSModulePath through
    # unchanged. Omit it so Windows PowerShell rebuilds its own module roots.
    $resetModulePathForWindowsPowerShell = [string]$PSVersionTable.PSEdition -eq "Core"
    $started = [ItlDeliveryProcessJob]::Start($powershellPath, $ArgumentList, $WorkingDirectory, $StandardOutputPath, $StandardErrorPath, $resetModulePathForWindowsPowerShell)
    try {
        $process = $started.Process
        $null = $process.Handle
        return [pscustomobject]@{ process = $process; jobHandle = [IntPtr]$started.JobHandle }
    } catch {
        try { [ItlDeliveryProcessJob]::Close([IntPtr]$started.JobHandle) } catch {}
        throw
    }
}

function Stop-DeliveryProcessJobAndWait {
    param(
        [Parameter(Mandatory = $true)][IntPtr]$JobHandle,
        [Parameter(Mandatory = $true)][Diagnostics.Process]$Process,
        [ValidateRange(0, 2147483647)][int]$TimeoutMilliseconds = 5000
    )
    if ($env:OS -ne 'Windows_NT' -or $JobHandle -eq [IntPtr]::Zero -or -not ('ItlDeliveryProcessJob' -as [type])) {
        throw 'DELIVERY_PROCESS_JOB_QUIESCENCE_UNAVAILABLE: an initialized owned Windows job is required.'
    }
    $processId = [int]$Process.Id
    $watch = [Diagnostics.Stopwatch]::StartNew()
    # Accounting zero can precede process-handle signaling. Hold and wait the
    # current job processes, then confirm zero while the job remains open. The
    # caller retains its existing finally/Close ownership on every outcome.
    $activeProcesses = [ItlDeliveryProcessJob]::StopAndWait($JobHandle, $TimeoutMilliseconds)
    $remaining = [Math]::Max(0, $TimeoutMilliseconds - [int]$watch.ElapsedMilliseconds)
    if (-not $Process.WaitForExit($remaining)) {
        throw 'DELIVERY_PROCESS_JOB_QUIESCENCE_TIMEOUT: the owned parent process handle is not signaled.'
    }
    $watch.Stop()
    return [pscustomobject]@{
        jobHandle = $JobHandle.ToInt64().ToString([Globalization.CultureInfo]::InvariantCulture)
        processId = $processId
        activeProcesses = [int]$activeProcesses
        stopped = $true
        quiescenceConfirmed = $true
        processHandleWaitsVerified = $true
        elapsedMilliseconds = [int64]$watch.ElapsedMilliseconds
    }
}

function Close-DeliveryProcessJob {
    param([IntPtr]$JobHandle, [AllowNull()][object]$Process, [string]$PriorErrorMessage = "")
    if ($JobHandle -eq [IntPtr]::Zero -or $env:OS -ne "Windows_NT") { return }
    try { [ItlDeliveryProcessJob]::Close($JobHandle) } catch {
        $closeMessage = $_.Exception.Message
        Stop-DeliveryProcessTree -Process $Process
        if ($PriorErrorMessage) {
            throw "Publication child failed: $PriorErrorMessage Additionally, its process job could not be closed: $closeMessage The owned process tree was stopped best-effort."
        }
        throw "Publication child process job could not be closed: $closeMessage The owned process tree was stopped best-effort; publication cannot continue."
    }
}

function Invoke-SourceGate {
    param([string]$Mode, [string]$WorkingRoot, [string]$TargetBaseRef = "", [int]$HardBudgetSeconds = 0, [string[]]$ReleaseCapability = @())
    $gate = if ($script:GateScript -eq (Join-Path $script:Root "scripts\check.ps1")) { Join-Path $WorkingRoot "scripts\check.ps1" } else { $script:GateScript }
    if (-not (Test-Path -LiteralPath $gate -PathType Leaf)) { throw "Source gate was not found: $gate" }
    $arguments = @("-NoLogo", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", $gate, "-Mode", $Mode)
    if ($TargetBaseRef) { $arguments += @("-BaseRef", $TargetBaseRef) }
    $contracts = @($CoverageContract | Where-Object { $_ })
    if ($contracts.Count -gt 0) { $arguments += @("-CoverageContract", ($contracts -join ",")) }
    if ($AiRulesSource) { $arguments += @("-AiRulesSource", ([System.IO.Path]::GetFullPath($AiRulesSource))) }
    if ($E2EProjectRoot) { $arguments += @("-E2EProjectRoot", ([System.IO.Path]::GetFullPath($E2EProjectRoot))) }
    $clientParameter = Get-Variable -Name AgentTarget -ErrorAction SilentlyContinue
    if ($Mode -in @("Develop", "Release") -and $clientParameter -and -not [string]::IsNullOrWhiteSpace([string]$clientParameter.Value)) {
        $arguments += @("-AgentTarget", [string]$clientParameter.Value)
    }
    if ($Mode -eq "Release") {
        $arguments += @("-ReleaseResumeMode", $ReleaseResumeMode)
        if (@($ReleaseCapability).Count -gt 0) { $arguments += @("-ReleaseCapabilities", (@($ReleaseCapability) -join ',')) }
    }
    $quoted = @($arguments | ForEach-Object {
        $value = [string]$_
        if ($value -notmatch '[\s"]') { $value } else { '"' + $value.Replace('"', '\"') + '"' }
    })
    $logRoot = Join-Path $WorkingRoot "build\test-results\delivery"
    New-Item -ItemType Directory -Force -Path $logRoot | Out-Null
    $stdout = Join-Path $logRoot ("gate-$($Mode.ToLowerInvariant()).stdout.log")
    $stderr = Join-Path $logRoot ("gate-$($Mode.ToLowerInvariant()).stderr.log")
    $gateStartedAt = [DateTime]::UtcNow
    $gateStatus = "failed"; $gateError = ""; $process = $null; $processJob = [IntPtr]::Zero
    try {
        $started = Start-DeliveryProcess -ArgumentList ($quoted -join " ") -WorkingDirectory $WorkingRoot -StandardOutputPath $stdout -StandardErrorPath $stderr
        $process = $started.process
        $processJob = [IntPtr]$started.jobHandle
        Update-DeliveryOperation -Values @{ mode = $Mode; workingRoot = $WorkingRoot; gatePid = [int]$process.Id; gateProcessStartedAt = $process.StartTime.ToUniversalTime().ToString("o"); gateStatus = "running" }
        $authoritativeGate = Join-Path $WorkingRoot "scripts\check.ps1"
        $hardSeconds = Get-SourceGateSupervisionBudgetSeconds -Mode $Mode -WorkingRoot $WorkingRoot -PlanBudgetSeconds $HardBudgetSeconds -InjectedGate:($gate -ne $authoritativeGate)
        $watch = [Diagnostics.Stopwatch]::StartNew(); $lastLength = -1L; $lastProgress = [DateTime]::UtcNow
        while (-not $process.WaitForExit(5000)) {
            $length = 0L
            foreach ($path in @($stdout, $stderr)) { if (Test-Path $path) { $length += (Get-Item $path).Length } }
            if ($length -ne $lastLength) { $lastLength = $length; $lastProgress = [DateTime]::UtcNow }
            if ($watch.Elapsed.TotalSeconds -ge $hardSeconds -or ([DateTime]::UtcNow - $lastProgress).TotalMinutes -ge 15) {
                Stop-DeliveryProcessTree -Process $process
                throw "$Mode source gate exceeded its hard/no-progress budget. See $stdout and $stderr"
            }
        }
        $process.WaitForExit(); $process.Refresh(); $watch.Stop()
        if ([int]$process.ExitCode -ne 0) { throw "$Mode source gate failed with exit code $($process.ExitCode). See $stdout and $stderr" }
        if ($gate -eq (Join-Path $WorkingRoot "scripts\check.ps1")) {
            $summaryPath = Join-Path $WorkingRoot "build\test-results\local\check-summary.json"
            if (-not (Test-Path -LiteralPath $summaryPath -PathType Leaf)) { throw "$Mode source gate returned without an authoritative check summary." }
            $summary = Get-Content -LiteralPath $summaryPath -Raw -Encoding UTF8 | ConvertFrom-Json
            if ([string]$summary.mode -ne $Mode -or [string]$summary.status -ne "passed" -or (ConvertTo-DeliveryUtcDateTime -Value $summary.finishedAt) -lt $gateStartedAt.AddSeconds(-2)) { throw "$Mode source gate did not produce a fresh passed summary. See $summaryPath" }
        }
        $gateStatus = "passed"
    } catch { $gateError = $_.Exception.Message; throw } finally {
        $jobCloseError = $null
        try { Close-DeliveryProcessJob -JobHandle $processJob -Process $process -PriorErrorMessage $gateError } catch { $jobCloseError = $_ }
        Stop-DeliveryProcessTree -Process $process
        $finishedAt = [DateTime]::UtcNow
        $historyError = $null
        try {
            $runRecordPath = Write-DeliveryRunRecord -Mode $Mode -Status $gateStatus -ErrorMessage $gateError -WorkingRoot $WorkingRoot -StartedAt $gateStartedAt -FinishedAt $finishedAt -ExitCode $(if ($process -and $process.HasExited) { [int]$process.ExitCode } else { -1 }) -ReleaseCapability $ReleaseCapability
            Update-DeliveryOperation -Values @{ gatePid = 0; gateProcessStartedAt = ""; gateStatus = $gateStatus; gateFinishedAt = $finishedAt.ToString("o"); runRecordPath = $runRecordPath }
        }
        catch { if ($gateStatus -eq "passed") { $historyError = $_ } else { Write-Warning "Unable to persist failed gate history: $($_.Exception.Message)" } }
        if ($jobCloseError) { throw $jobCloseError }
        if ($historyError) { throw $historyError }
    }
}

function Assert-DeliveryReleaseStandReady {
    param([Parameter(Mandatory = $true)][string]$CandidateRoot)
    if ($script:DeliveryCustomGateBoundary) { return }
    if (-not $E2EProjectRoot -or -not $AiRulesSource) { throw 'Release stand preflight requires the configured E2E project and exact controlled-fork checkout.' }
    $runner = Join-Path $CandidateRoot 'scripts\test-release-readiness.ps1'
    if (-not (Test-Path -LiteralPath $runner -PathType Leaf)) { throw "Release stand preflight is missing from the candidate: $runner" }
    $logRoot = Join-Path $CandidateRoot 'build\test-results\delivery'
    New-Item -ItemType Directory -Force -Path $logRoot | Out-Null
    $output = Join-Path $logRoot 'release-stand-preflight.json'
    Remove-Item -LiteralPath $output -Force -ErrorAction SilentlyContinue
    $stdout = Join-Path $logRoot 'release-stand-preflight.stdout.log'
    $stderr = Join-Path $logRoot 'release-stand-preflight.stderr.log'
    $arguments = @('-NoLogo', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', $runner,
        '-Mode', 'Release', '-RepositoryRoot', $CandidateRoot, '-E2EProjectRoot', ([IO.Path]::GetFullPath($E2EProjectRoot)),
        '-AiRulesSource', ([IO.Path]::GetFullPath($AiRulesSource)), '-ResumeMode', $ReleaseResumeMode, '-OutputPath', $output)
    $quoted = @($arguments | ForEach-Object { ConvertTo-DeliveryNativeArgument -Value ([string]$_) })
    $process = $null; $job = [IntPtr]::Zero; $priorError = ''
    try {
        $started = Start-DeliveryProcess -ArgumentList ($quoted -join ' ') -WorkingDirectory $CandidateRoot -StandardOutputPath $stdout -StandardErrorPath $stderr
        $process = $started.process; $job = [IntPtr]$started.jobHandle
        if (-not $process.WaitForExit(300000)) {
            Stop-DeliveryProcessTree -Process $process
            throw "Release stand preflight exceeded five minutes. See $stdout and $stderr"
        }
        $process.Refresh()
        if (-not (Test-Path -LiteralPath $output -PathType Leaf)) { throw "Release stand preflight returned without context. See $stdout and $stderr" }
        $context = Get-Content -LiteralPath $output -Raw -Encoding UTF8 | ConvertFrom-Json
        if ([string]$context.status -cne 'passed' -or [int]$process.ExitCode -ne 0) {
            $issues = @($context.issues | ForEach-Object { "$($_.code): $($_.message) Recovery: $($_.recovery)" }) -join '; '
            throw "Release stand is not ready before Develop: $issues. See $output"
        }
    } catch { $priorError = $_.Exception.Message; throw } finally {
        $closeError = $null
        try { Close-DeliveryProcessJob -JobHandle $job -Process $process -PriorErrorMessage $priorError } catch { $closeError = $_ }
        Stop-DeliveryProcessTree -Process $process
        if ($closeError) { throw $closeError }
    }
}

function Get-DeliveryOperationLockPath {
    return Join-Path (Get-DeliveryCommonGitDirectory) "itl\delivery-operation"
}

function Test-DeliveryProcessIdentity {
    param([int]$ProcessId, [AllowNull()][object]$StartedAt)
    if ($ProcessId -le 0 -or -not $StartedAt) { return $false }
    $process = Get-Process -Id $ProcessId -ErrorAction SilentlyContinue
    if (-not $process) { return $false }
    try {
        $expected = ConvertTo-DeliveryUtcDateTime -Value $StartedAt
        return [Math]::Abs(($process.StartTime.ToUniversalTime() - $expected).TotalSeconds) -lt 2
    } catch { return $false }
}

function Read-DeliveryOperation {
    $path = Join-Path (Get-DeliveryOperationLockPath) "operation.json"
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { return $null }
    try { return Get-Content -LiteralPath $path -Raw -Encoding UTF8 | ConvertFrom-Json } catch { return $null }
}

function Write-DeliveryOperation {
    param([Parameter(Mandatory = $true)][object]$Operation)
    $root = Get-DeliveryOperationLockPath
    if (-not (Test-Path -LiteralPath $root -PathType Container)) { throw "Delivery operation lock disappeared while it was active: $root" }
    $target = Join-Path $root "operation.json"; $temp = Join-Path $root ("operation." + [guid]::NewGuid().ToString("N") + ".tmp")
    [IO.File]::WriteAllText($temp, (($Operation | ConvertTo-Json -Depth 8) + [Environment]::NewLine), [Text.UTF8Encoding]::new($false))
    Move-Item -LiteralPath $temp -Destination $target -Force
}

function Get-DeliveryOperationStatus {
    $operation = Read-DeliveryOperation
    if (-not $operation) { return $null }
    $ownerAlive = Test-DeliveryProcessIdentity -ProcessId ([int]$operation.ownerPid) -StartedAt $operation.ownerProcessStartedAt
    $gateAlive = Test-DeliveryProcessIdentity -ProcessId ([int]$operation.gatePid) -StartedAt $operation.gateProcessStartedAt
    $cleanupPidProperty = $operation.PSObject.Properties['cleanupExecutorPid']
    $cleanupPid = if ($cleanupPidProperty) { [int]$cleanupPidProperty.Value } else { 0 }
    $cleanupDelegationProperty = $operation.PSObject.Properties['cleanupDelegation']
    $cleanupDelegation = if ($cleanupDelegationProperty) { $cleanupDelegationProperty.Value } else { $null }
    $cleanupStartedAt = if ($cleanupDelegation -and $cleanupDelegation.PSObject.Properties['childProcessStartedAt']) { $cleanupDelegation.childProcessStartedAt } else { $null }
    $cleanupAlive = Test-DeliveryProcessIdentity -ProcessId $cleanupPid -StartedAt $cleanupStartedAt
    return [pscustomobject]@{
        id = [string]$operation.id; action = [string]$operation.action; startedAt = [string]$operation.startedAt
        ownerPid = [int]$operation.ownerPid; ownerAlive = $ownerAlive; gatePid = [int]$operation.gatePid; gateAlive = $gateAlive
        cleanupExecutorPid = $cleanupPid; cleanupExecutorAlive = $cleanupAlive
        cleanupExecutor = $(if ($cleanupDelegation) { [pscustomobject]@{
            channel=[string]$cleanupDelegation.channel; phase=[string]$cleanupDelegation.phase; commit=[string]$cleanupDelegation.commit
            authorityCommit=[string]$cleanupDelegation.authorityCommit; status=[string]$cleanupDelegation.status
        } } else { $null })
        mode = [string]$operation.mode; candidatePath = [string]$operation.workingRoot; status = $(if ($ownerAlive -or $gateAlive -or $cleanupAlive) { "running" } else { "stale" })
    }
}

function Get-DeliveryFailureClass {
    param([string]$Message, [string]$Stage = "")
    $value = "$Stage $Message"
    if ($value -match '(?i)cleanup|housekeeping|remove stale|could not be removed') { return "cleanup" }
    if ($value -match '(?i)QUALITY_OWNER_MISSING|quality contract|test contract|assertion contract') { return "test-contract" }
    if ($value -match '(?i)parameter|argument|ValidateSet|requires an explicit|is valid only|invocation') { return "invocation" }
    if ($value -match '(?i)timeout|timed out|no.progress|port.+(?:busy|occupied)|environment|unavailable|access.+denied') { return "environment" }
    if ($value -match '(?i)DELIVERY_PLAN|supervisor|queue|checkpoint|operation.+lock|publication stage') { return "supervisor" }
    return "product"
}

$script:DeliveryRunHotIndexCapacity = 2048
$script:DeliveryRunHotIndexLockTimeoutMilliseconds = 30000

function Get-DeliveryRunHotIndexPath {
    return Join-Path (Get-DeliveryCommonGitDirectory) "itl\run-index\v1\hot.json"
}

function Get-DeliveryRunHotIndexPendingRoot {
    return Join-Path (Split-Path -Parent (Get-DeliveryRunHotIndexPath)) 'pending'
}

function Write-DeliveryRunHotIndexPendingMarker {
    param([Parameter(Mandatory = $true)][string]$RawPath)
    $root = Get-DeliveryRunHotIndexPendingRoot
    New-Item -ItemType Directory -Force -Path $root | Out-Null
    $path = Join-Path $root ((Split-Path -Leaf $RawPath) + '.pending')
    $temporary = Join-Path $root ((Split-Path -Leaf $path) + '.' + [guid]::NewGuid().ToString('N') + '.tmp')
    try {
        $writer = Get-Process -Id $PID -ErrorAction Stop
        $payload = [pscustomobject][ordered]@{
            schemaVersion=1; kind='itl-delivery-run-index-pending'; rawPath=[IO.Path]::GetFullPath($RawPath)
            writerPid=[int]$PID; writerStartedAt=$writer.StartTime.ToUniversalTime().ToString('o')
        }
        [IO.File]::WriteAllText($temporary, (($payload | ConvertTo-Json -Compress) + [Environment]::NewLine), [Text.UTF8Encoding]::new($false))
        Move-Item -LiteralPath $temporary -Destination $path -Force
    } finally { Remove-Item -LiteralPath $temporary -Force -ErrorAction SilentlyContinue }
    return $path
}

function Enter-DeliveryRunHotIndexLock {
    param([int]$TimeoutMilliseconds = 30000)
    $path = Join-Path (Split-Path -Parent (Get-DeliveryRunHotIndexPath)) 'write.lock'
    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $path) | Out-Null
    $deadline = [DateTime]::UtcNow.AddMilliseconds([Math]::Max(1, $TimeoutMilliseconds))
    do {
        try { return [IO.File]::Open($path, [IO.FileMode]::OpenOrCreate, [IO.FileAccess]::ReadWrite, [IO.FileShare]::None) }
        catch [IO.IOException] {
            if ([DateTime]::UtcNow -ge $deadline) { throw "DELIVERY_RUN_INDEX_LOCK_TIMEOUT: $path" }
            Start-Sleep -Milliseconds 25
        }
    } while ($true)
}

function Test-DeliveryRunRecordShape {
    param([Parameter(Mandatory = $true)][object]$Record)
    $present = $Record.PSObject.Properties["mode"] -and $Record.PSObject.Properties["status"] -and
        $Record.PSObject.Properties["startedAt"] -and $Record.PSObject.Properties["durationMs"] -and
        $Record.PSObject.Properties["tree"]
    if (-not $present) { return $false }
    try {
        [void](ConvertTo-DeliveryUtcDateTime -Value $Record.startedAt)
        $duration = [int64]$Record.durationMs
        return $duration -ge 0
    } catch { return $false }
}

function ConvertTo-DeliveryRunHotIndexEntry {
    param(
        [Parameter(Mandatory = $true)][object]$Record,
        [Parameter(Mandatory = $true)][string]$RawPath
    )
    return [pscustomobject][ordered]@{
        rawPath=[IO.Path]::GetFullPath($RawPath)
        schemaVersion=$(if($Record.PSObject.Properties["schemaVersion"]){[int]$Record.schemaVersion}else{0})
        id=$(if($Record.PSObject.Properties["id"]){[string]$Record.id}else{""})
        mode=[string]$Record.mode; status=[string]$Record.status
        failureClass=$(if($Record.PSObject.Properties["failureClass"]){[string]$Record.failureClass}else{""})
        exitCode=$(if($Record.PSObject.Properties["exitCode"]){[int]$Record.exitCode}else{-1})
        startedAt=[string]$Record.startedAt
        finishedAt=$(if($Record.PSObject.Properties["finishedAt"]){[string]$Record.finishedAt}else{""})
        durationMs=[int64]$Record.durationMs
        commit=$(if($Record.PSObject.Properties["commit"]){[string]$Record.commit}else{""})
        tree=[string]$Record.tree
        error=$(if($Record.PSObject.Properties["error"]){[string]$Record.error}else{""})
        tests=$(if($Record.PSObject.Properties["tests"]){$Record.tests}else{$null})
        stages=$(if($Record.PSObject.Properties["stages"]){@($Record.stages)}else{@()})
        releaseE2E=$(if($Record.PSObject.Properties["releaseE2E"]){$Record.releaseE2E}else{$null})
    }
}

function New-DeliveryRunHotIndex {
    param(
        [Parameter(Mandatory = $true)][string]$RunRoot,
        [ref]$ProcessedRawPaths
    )
    $entries = [Collections.Generic.List[object]]::new()
    $valid = [Collections.Generic.List[object]]::new()
    $processed = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
    $invalidCount = 0
    if (Test-Path -LiteralPath $RunRoot -PathType Container) {
        foreach ($file in @(Get-ChildItem -LiteralPath $RunRoot -File -Filter "*.json" | Sort-Object Name -Descending)) {
            [void]$processed.Add([IO.Path]::GetFullPath($file.FullName))
            try {
                $record = Get-Content -LiteralPath $file.FullName -Raw -Encoding UTF8 | ConvertFrom-Json
                if (-not (Test-DeliveryRunRecordShape -Record $record)) { $invalidCount++; continue }
                $entry = ConvertTo-DeliveryRunHotIndexEntry -Record $record -RawPath $file.FullName
                $valid.Add($entry) | Out-Null
                if ($entries.Count -lt $script:DeliveryRunHotIndexCapacity) { $entries.Add($entry) | Out-Null }
            } catch { $invalidCount++ }
        }
    }
    $byMode = @($valid | Group-Object mode | Sort-Object Name | ForEach-Object {
        [pscustomobject][ordered]@{ mode=$_.Name; count=[int]$_.Count; durationMs=[int64](($_.Group | Measure-Object durationMs -Sum).Sum) }
    })
    $directoryStamp = if (Test-Path -LiteralPath $RunRoot -PathType Container) {
        (Get-Item -LiteralPath $RunRoot).LastWriteTimeUtc.ToString("o")
    } else { "" }
    $totalDurationMs = [int64]0
    foreach ($entry in $valid) { $totalDurationMs += [int64]$entry.durationMs }
    if ($ProcessedRawPaths) { $ProcessedRawPaths.Value = $processed }
    return [pscustomobject][ordered]@{
        schemaVersion=1; kind="itl-delivery-run-hot-index"; capacity=$script:DeliveryRunHotIndexCapacity
        sourceDirectory=[IO.Path]::GetFullPath($RunRoot); sourceDirectoryLastWriteTimeUtc=$directoryStamp
        validRunCount=$valid.Count; invalidRunCount=$invalidCount
        totalDurationMs=$totalDurationMs
        byMode=$byMode; entries=@($entries); truncated=($valid.Count -gt $script:DeliveryRunHotIndexCapacity)
        updatedAt=[DateTime]::UtcNow.ToString("o")
    }
}

function Get-DeliveryRunHotIndexContentSha256 {
    param([Parameter(Mandatory = $true)][object]$Index)
    $content = [pscustomobject][ordered]@{
        schemaVersion=[int]$Index.schemaVersion; kind=[string]$Index.kind; capacity=[int]$Index.capacity
        sourceDirectory=[string]$Index.sourceDirectory; sourceDirectoryLastWriteTimeUtc=[string]$Index.sourceDirectoryLastWriteTimeUtc
        validRunCount=[int64]$Index.validRunCount; invalidRunCount=[int]$Index.invalidRunCount
        totalDurationMs=[int64]$Index.totalDurationMs; byMode=@($Index.byMode); entries=@($Index.entries)
        truncated=[bool]$Index.truncated; updatedAt=[string]$Index.updatedAt
    }
    $bytes = [Text.Encoding]::UTF8.GetBytes(($content | ConvertTo-Json -Depth 16 -Compress))
    $sha = [Security.Cryptography.SHA256]::Create()
    try { return ([BitConverter]::ToString($sha.ComputeHash($bytes))).Replace('-', '').ToLowerInvariant() }
    finally { $sha.Dispose() }
}

function Write-DeliveryRunHotIndex {
    param([Parameter(Mandatory = $true)][object]$Index)
    $contentSha = Get-DeliveryRunHotIndexContentSha256 -Index $Index
    if ($Index.PSObject.Properties['contentSha256']) { $Index.contentSha256 = $contentSha }
    else { $Index | Add-Member -NotePropertyName contentSha256 -NotePropertyValue $contentSha }
    $path = Get-DeliveryRunHotIndexPath
    $parent = Split-Path -Parent $path
    New-Item -ItemType Directory -Force -Path $parent | Out-Null
    $temporary = Join-Path $parent ("hot." + [guid]::NewGuid().ToString("N") + ".tmp")
    try {
        [IO.File]::WriteAllText($temporary, (($Index | ConvertTo-Json -Depth 16) + [Environment]::NewLine), [Text.UTF8Encoding]::new($false))
        Move-Item -LiteralPath $temporary -Destination $path -Force
    } finally { Remove-Item -LiteralPath $temporary -Force -ErrorAction SilentlyContinue }
    return $path
}

function Read-DeliveryRunHotIndex {
    param([switch]$IgnoreSourceStamp)
    $path = Get-DeliveryRunHotIndexPath
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { return [pscustomobject]@{ status="missing"; path=$path; index=$null } }
    $pendingRoot = Get-DeliveryRunHotIndexPendingRoot
    if ((Test-Path -LiteralPath $pendingRoot -PathType Container) -and
        $null -ne (Get-ChildItem -LiteralPath $pendingRoot -File -Filter '*.pending' -ErrorAction SilentlyContinue | Select-Object -First 1)) {
        return [pscustomobject]@{ status="stale"; path=$path; index=$null; error='pending raw run records require serialized repair' }
    }
    try {
        $index = Get-Content -LiteralPath $path -Raw -Encoding UTF8 | ConvertFrom-Json
        if ([int]$index.schemaVersion -ne 1 -or [string]$index.kind -cne "itl-delivery-run-hot-index" -or
            [int]$index.capacity -ne $script:DeliveryRunHotIndexCapacity -or @($index.entries).Count -gt $script:DeliveryRunHotIndexCapacity -or
            [int64]$index.validRunCount -lt @($index.entries).Count -or [string]$index.contentSha256 -notmatch '^[a-f0-9]{64}$' -or
            [string]$index.contentSha256 -cne (Get-DeliveryRunHotIndexContentSha256 -Index $index)) { throw "unsupported, inconsistent, or SHA-mismatched index schema" }
        $runRoot = Join-Path (Get-DeliveryCommonGitDirectory) "itl\runs"
        if ([IO.Path]::GetFullPath([string]$index.sourceDirectory) -cne [IO.Path]::GetFullPath($runRoot)) { throw "source directory mismatch" }
        if (-not $IgnoreSourceStamp) {
            $actualStamp = if (Test-Path -LiteralPath $runRoot -PathType Container) { (Get-Item -LiteralPath $runRoot).LastWriteTimeUtc.ToString("o") } else { "" }
            if ([string]$index.sourceDirectoryLastWriteTimeUtc -cne $actualStamp) { return [pscustomobject]@{ status="stale"; path=$path; index=$null } }
        }
        return [pscustomobject]@{ status="ready"; path=$path; index=$index }
    } catch { return [pscustomobject]@{ status="corrupt"; path=$path; index=$null; error=$_.Exception.Message } }
}

function Repair-DeliveryRunHotIndex {
    param([switch]$LockHeld)
    $lock = $null
    try {
        if (-not $LockHeld) { $lock = Enter-DeliveryRunHotIndexLock }
        $current = Read-DeliveryRunHotIndex
        if ([string]$current.status -eq "ready") {
            return [pscustomobject]@{ status="reused"; path=[string]$current.path; validRunCount=[int]$current.index.validRunCount; invalidRunCount=[int]$current.index.invalidRunCount; retained=@($current.index.entries).Count }
        }
        $runRoot = Join-Path (Get-DeliveryCommonGitDirectory) "itl\runs"
        $pendingRoot = Get-DeliveryRunHotIndexPendingRoot
        $pending = if (Test-Path -LiteralPath $pendingRoot -PathType Container) { @(Get-ChildItem -LiteralPath $pendingRoot -File -Filter '*.pending') } else { @() }
        $processedRawPaths = $null
        $index = New-DeliveryRunHotIndex -RunRoot $runRoot -ProcessedRawPaths ([ref]$processedRawPaths)
        $path = Write-DeliveryRunHotIndex -Index $index
        foreach ($marker in $pending) {
            try {
                $markerState = Get-Content -LiteralPath $marker.FullName -Raw -Encoding UTF8 | ConvertFrom-Json
                if ([int]$markerState.schemaVersion -ne 1 -or [string]$markerState.kind -cne 'itl-delivery-run-index-pending' -or
                    [int]$markerState.writerPid -le 0 -or -not $markerState.PSObject.Properties['writerStartedAt']) { throw 'invalid marker contract' }
                $markedRawPath = [IO.Path]::GetFullPath([string]$markerState.rawPath)
                $expectedLeaf = $marker.Name.Substring(0, $marker.Name.Length - '.pending'.Length)
                if (-not [string]::Equals((Split-Path -Parent $markedRawPath), [IO.Path]::GetFullPath($runRoot), [StringComparison]::OrdinalIgnoreCase) -or
                    -not [string]::Equals((Split-Path -Leaf $markedRawPath), $expectedLeaf, [StringComparison]::OrdinalIgnoreCase)) {
                    throw 'marker path does not match its owned run filename'
                }
            } catch {
                if ($marker.Name -match '^\d{8}-\d{6}-\d{3}-[a-z0-9-]+-[a-f0-9]{32}\.json\.pending$') {
                    Remove-Item -LiteralPath $marker.FullName -Force -ErrorAction SilentlyContinue
                }
                continue
            }
            if ($processedRawPaths.Contains($markedRawPath)) {
                Remove-Item -LiteralPath $marker.FullName -Force -ErrorAction SilentlyContinue
            } elseif (-not (Test-Path -LiteralPath $markedRawPath -PathType Leaf) -and
                -not (Test-DeliveryProcessCreationIdentity -ProcessId ([int]$markerState.writerPid) -CreatedAt (ConvertTo-DeliveryUtcDateTime -Value $markerState.writerStartedAt))) {
                Remove-Item -LiteralPath $marker.FullName -Force -ErrorAction SilentlyContinue
            }
        }
        return [pscustomobject]@{ status="rebuilt"; previousStatus=[string]$current.status; path=$path; validRunCount=[int]$index.validRunCount; invalidRunCount=[int]$index.invalidRunCount; retained=@($index.entries).Count }
    } finally {
        if ($lock) { $lock.Dispose() }
    }
}

function Add-DeliveryRunToHotIndex {
    param(
        [Parameter(Mandatory = $true)][object]$PreviousIndexState,
        [Parameter(Mandatory = $true)][object]$Record,
        [Parameter(Mandatory = $true)][string]$RawPath
    )
    if ([string]$PreviousIndexState.status -ne "ready") { return Repair-DeliveryRunHotIndex -LockHeld }
    $index = $PreviousIndexState.index
    if (@($index.entries | Where-Object { [string]$_.rawPath -ceq [IO.Path]::GetFullPath($RawPath) }).Count -gt 0) { return [string]$PreviousIndexState.path }
    $entry = ConvertTo-DeliveryRunHotIndexEntry -Record $Record -RawPath $RawPath
    $index.entries = @(@($entry) + @($index.entries) | Sort-Object @{ Expression={ ConvertTo-DeliveryUtcDateTime -Value $_.startedAt }; Descending=$true }, @{ Expression={ [string]$_.rawPath }; Descending=$true } | Select-Object -First $script:DeliveryRunHotIndexCapacity)
    $index.validRunCount = [int64]$index.validRunCount + 1
    $index.totalDurationMs = [int64]$index.totalDurationMs + [int64]$entry.durationMs
    $modes = @($index.byMode)
    $mode = @($modes | Where-Object { [string]$_.mode -ceq [string]$entry.mode } | Select-Object -First 1)
    if ($mode.Count) { $mode[0].count = [int]$mode[0].count + 1; $mode[0].durationMs = [int64]$mode[0].durationMs + [int64]$entry.durationMs }
    else { $modes += [pscustomobject][ordered]@{ mode=[string]$entry.mode; count=1; durationMs=[int64]$entry.durationMs } }
    $index.byMode = @($modes | Sort-Object mode)
    $index.truncated = [int64]$index.validRunCount -gt $script:DeliveryRunHotIndexCapacity
    $runRoot = Join-Path (Get-DeliveryCommonGitDirectory) "itl\runs"
    $index.sourceDirectoryLastWriteTimeUtc = (Get-Item -LiteralPath $runRoot).LastWriteTimeUtc.ToString("o")
    $index.updatedAt = [DateTime]::UtcNow.ToString("o")
    return Write-DeliveryRunHotIndex -Index $index
}

function Write-DeliveryRunRecord {
    param([string]$Mode, [string]$Status, [string]$ErrorMessage, [string]$WorkingRoot, [datetime]$StartedAt, [datetime]$FinishedAt, [int]$ExitCode, [string[]]$ReleaseCapability = @())
    $runRoot = Join-Path (Get-DeliveryCommonGitDirectory) "itl\runs"; New-Item -ItemType Directory -Force -Path $runRoot | Out-Null
    $summaryPath = Join-Path $WorkingRoot "build\test-results\local\check-summary.json"; $summary = $null
    if (Test-Path -LiteralPath $summaryPath -PathType Leaf) {
        try {
            $summary = Get-Content -LiteralPath $summaryPath -Raw -Encoding UTF8 | ConvertFrom-Json
            if (-not $summary.PSObject.Properties["startedAt"] -or (ConvertTo-DeliveryUtcDateTime -Value $summary.startedAt) -lt $StartedAt.AddSeconds(-2)) { $summary = $null }
        } catch { $summary = $null }
    }
    $releaseE2E = $null
    $e2eReportProperty = if ($summary) { $summary.PSObject.Properties["e2eReportPath"] } else { $null }
    if ($e2eReportProperty -and [string]$e2eReportProperty.Value -and (Test-Path -LiteralPath ([string]$e2eReportProperty.Value) -PathType Leaf)) {
        try {
            $e2e = Get-Content -LiteralPath ([string]$e2eReportProperty.Value) -Raw -Encoding UTF8 | ConvertFrom-Json
            $e2eStages = @($e2e.stages.PSObject.Properties | ForEach-Object {
                [pscustomobject]@{ name = $_.Name; execution = [string]$_.Value.execution; durationMs = [int64]$_.Value.currentRunDurationMs; proofDurationMs = [int64]$_.Value.proofDurationMs; reuseReason = [string]$_.Value.reuseReason }
            })
            $releaseE2E = [pscustomobject]@{
                durationMs = [int64]$e2e.durationMs
                executedStages = @($e2e.executedStages)
                reusedStages = @($e2eStages | Where-Object execution -eq "reused" | ForEach-Object { [pscustomobject]@{ name=$_.name; reason=$_.reuseReason } })
                invalidatedStages = @($e2e.invalidatedStages)
                invalidationDetails = $(if ($e2e.PSObject.Properties["invalidationDetails"]) { @($e2e.invalidationDetails) } else { @() })
                slowestStages = @($e2eStages | Where-Object execution -eq "executed" | Sort-Object durationMs -Descending | Select-Object -First 5)
            }
        } catch { $releaseE2E = $null }
    }
    $record = [ordered]@{ schemaVersion = 3; id = [guid]::NewGuid().ToString("N"); mode = $Mode; status = $Status; failureClass = $(if($Status -eq "passed"){""}else{Get-DeliveryFailureClass -Message $ErrorMessage -Stage $Mode}); exitCode = $ExitCode; startedAt = $StartedAt.ToString("o"); finishedAt = $FinishedAt.ToString("o"); durationMs = [int64]($FinishedAt - $StartedAt).TotalMilliseconds; commit = (Invoke-WorktreeGit -Root $WorkingRoot -Arguments @("rev-parse", "HEAD")).stdout.Trim(); tree = (Invoke-WorktreeGit -Root $WorkingRoot -Arguments @("rev-parse", "HEAD^{tree}")).stdout.Trim(); error = $ErrorMessage; releaseCapabilities = $(if ($summary -and $summary.PSObject.Properties["releaseCapabilities"]) { @($summary.releaseCapabilities) } else { @($ReleaseCapability) }); tests = $(if ($summary) { $summary.tests } else { $null }); stages = $(if ($summary) { @($summary.stages | Sort-Object durationMs -Descending | Select-Object -First 10) } else { @() }); releaseE2E = $releaseE2E }
    $name = "{0}-{1}-{2}.json" -f $StartedAt.ToString("yyyyMMdd-HHmmss-fff"), $Mode.ToLowerInvariant(), $record.id; $target = Join-Path $runRoot $name; $temp = "$target.tmp"
    $indexLock = $null
    $pendingMarker = $null
    try {
        try { $indexLock = Enter-DeliveryRunHotIndexLock -TimeoutMilliseconds $script:DeliveryRunHotIndexLockTimeoutMilliseconds }
        catch {
            if ($_.Exception.Message -notlike 'DELIVERY_RUN_INDEX_LOCK_TIMEOUT:*') { throw }
            $pendingMarker = Write-DeliveryRunHotIndexPendingMarker -RawPath $target
            [IO.File]::WriteAllText($temp, (($record | ConvertTo-Json -Depth 12) + [Environment]::NewLine), [Text.UTF8Encoding]::new($false)); Move-Item -LiteralPath $temp -Destination $target
            return $target
        }
        $previousIndexState = Read-DeliveryRunHotIndex
        $pendingMarker = Write-DeliveryRunHotIndexPendingMarker -RawPath $target
        [IO.File]::WriteAllText($temp, (($record | ConvertTo-Json -Depth 12) + [Environment]::NewLine), [Text.UTF8Encoding]::new($false)); Move-Item -LiteralPath $temp -Destination $target
        try {
            [void](Add-DeliveryRunToHotIndex -PreviousIndexState $previousIndexState -Record ([pscustomobject]$record) -RawPath $target)
            Remove-Item -LiteralPath $pendingMarker -Force -ErrorAction SilentlyContinue
        } catch {}
    } finally {
        Remove-Item -LiteralPath $temp -Force -ErrorAction SilentlyContinue
        if ($pendingMarker -and -not (Test-Path -LiteralPath $target -PathType Leaf)) {
            Remove-Item -LiteralPath $pendingMarker -Force -ErrorAction SilentlyContinue
        }
        if ($indexLock) { $indexLock.Dispose() }
    }
    return $target
}

function Get-DeliveryRunHistory {
    param([int]$Limit = 3, [switch]$IncludeDetails)
    $runRoot = Join-Path (Get-DeliveryCommonGitDirectory) "itl\runs"
    $state = Read-DeliveryRunHotIndex
    if ([string]$state.status -ne "ready") {
        return [pscustomobject]@{ root=$runRoot; indexPath=[string]$state.path; indexStatus=[string]$state.status; count=0; totalDurationMs=0; byMode=@(); lastRuns=@(); truncated=$false; nextAction="run serialized Cleanup to rebuild the hot index" }
    }
    $index = $state.index
    $runs = @($index.entries)
    $lastRuns = if ($IncludeDetails) { @($runs | Select-Object -First $Limit) } else {
        @($runs | Select-Object -First $Limit | ForEach-Object {
            [pscustomobject]@{ mode=$_.mode; status=$_.status; failureClass=$(if($_.PSObject.Properties["failureClass"]){$_.failureClass}else{""}); startedAt=$_.startedAt; finishedAt=$_.finishedAt; durationMs=$_.durationMs; commit=$_.commit; error=$_.error }
        })
    }
    return [pscustomobject]@{ root=$runRoot; indexPath=[string]$state.path; indexStatus="ready"; count=[int64]$index.validRunCount; invalidCount=[int]$index.invalidRunCount; totalDurationMs=[int64]$index.totalDurationMs; byMode=@($index.byMode); lastRuns=$lastRuns; truncated=[bool]$index.truncated; nextAction="" }
}

function Get-DeliveryQualificationTimingSummary {
    param([Parameter(Mandatory = $true)][string]$Tree, [Parameter(Mandatory = $true)][datetime]$NotBefore, [datetime]$OperationStartedAt = $NotBefore)
    $history = Get-DeliveryRunHistory -Limit $script:DeliveryRunHotIndexCapacity -IncludeDetails
    $runs = @($history.lastRuns | Where-Object {
        [string]$_.tree -ceq $Tree -and (ConvertTo-DeliveryUtcDateTime -Value $_.startedAt) -ge $NotBefore.AddSeconds(-2)
    } | Sort-Object { ConvertTo-DeliveryUtcDateTime -Value $_.startedAt })
    $finishedAt = [DateTime]::UtcNow
    $earliestHot = @($history.lastRuns | Sort-Object { ConvertTo-DeliveryUtcDateTime -Value $_.startedAt } | Select-Object -First 1)
    $historyComplete = [string]$history.indexStatus -eq "ready" -and (-not [bool]$history.truncated -or
        ($earliestHot.Count -gt 0 -and (ConvertTo-DeliveryUtcDateTime -Value $earliestHot[0].startedAt) -le $NotBefore.AddSeconds(-2)))
    $gateDurationMs = [int64]0
    foreach ($run in $runs) { $gateDurationMs += [int64]$run.durationMs }
    return [pscustomobject]@{
        operationDurationMs = [int64]($finishedAt - $OperationStartedAt).TotalMilliseconds
        gateDurationMs = $gateDurationMs
        historyStatus = [string]$history.indexStatus
        historyComplete = $historyComplete
        gates = @($runs | ForEach-Object { [pscustomobject]@{ mode=$_.mode; status=$_.status; durationMs=$_.durationMs; stages=$_.stages; releaseE2E=$(if ($_.PSObject.Properties["releaseE2E"]) { $_.releaseE2E } else { $null }) } })
    }
}

function Get-DeliveryQualificationCachePath {
    param([Parameter(Mandatory = $true)][string]$Tree)
    if ($Tree -notmatch '^[a-f0-9]{40}$') { throw "Invalid candidate tree for qualification cache: $Tree" }
    return Join-Path (Get-DeliveryCommonGitDirectory) ("itl\qualifications\" + $Tree)
}

function Save-DeliveryQualification {
    param([Parameter(Mandatory = $true)][string]$CandidateRoot, [Parameter(Mandatory = $true)][string]$Tree)
    $source = Join-Path $CandidateRoot "build\test-results\qualification"
    foreach ($name in @("full.json", "develop.json", "develop-e2e-summary.json")) {
        if (-not (Test-Path -LiteralPath (Join-Path $source $name) -PathType Leaf)) { throw "Develop gate did not create reusable qualification file '$name'." }
    }
    $target = Get-DeliveryQualificationCachePath -Tree $Tree
    $parent = Split-Path -Parent $target
    New-Item -ItemType Directory -Force -Path $parent | Out-Null
    $staging = Join-Path $parent ("." + $Tree + "." + [guid]::NewGuid().ToString("N") + ".tmp")
    New-Item -ItemType Directory -Path $staging | Out-Null
    $routeReports = @("develop-e2e-upgrade.json", "develop-e2e-fresh.json")
    try {
        Copy-Item -LiteralPath (Join-Path $source "full.json"), (Join-Path $source "develop.json"), (Join-Path $source "develop-e2e-summary.json") -Destination $staging -Force
        if (Test-Path -LiteralPath (Join-Path $source "pester.xml") -PathType Leaf) { Copy-Item -LiteralPath (Join-Path $source "pester.xml") -Destination $staging -Force }
        foreach ($name in $routeReports) {
            if (Test-Path -LiteralPath (Join-Path $source $name) -PathType Leaf) { Copy-Item -LiteralPath (Join-Path $source $name) -Destination $staging -Force }
        }
        if (-not (Test-Path -LiteralPath $target)) { Move-Item -LiteralPath $staging -Destination $target }
        else {
            $availableRoutes = @($routeReports | Where-Object { Test-Path -LiteralPath (Join-Path $staging $_) -PathType Leaf })
            if ($availableRoutes.Count -gt 0) {
                $backup = Join-Path $parent ("." + $Tree + "." + [guid]::NewGuid().ToString("N") + ".old")
                Move-Item -LiteralPath $target -Destination $backup
                try { Move-Item -LiteralPath $staging -Destination $target } catch { Move-Item -LiteralPath $backup -Destination $target; throw }
                Remove-Item -LiteralPath $backup -Recurse -Force
            }
        }
    } finally {
        if (Test-Path -LiteralPath $staging) { Remove-Item -LiteralPath $staging -Recurse -Force }
    }
    return $target
}

function Restore-DeliveryQualification {
    param([Parameter(Mandatory = $true)][string]$CandidateRoot, [Parameter(Mandatory = $true)][string]$Tree)
    $source = Get-DeliveryQualificationCachePath -Tree $Tree
    foreach ($name in @("full.json", "develop.json", "develop-e2e-summary.json")) {
        if (-not (Test-Path -LiteralPath (Join-Path $source $name) -PathType Leaf)) { return $false }
    }
    $target = Join-Path $CandidateRoot "build\test-results\qualification"
    New-Item -ItemType Directory -Force -Path $target | Out-Null
    Get-ChildItem -LiteralPath $source -File | Copy-Item -Destination $target -Force
    return $true
}

function Archive-StaleDeliveryOperation {
    param([Parameter(Mandatory = $true)][object]$Operation)
    $workingRoot = [string]$Operation.workingRoot
    $summary = $null
    if ($workingRoot) {
        $summaryPath = Join-Path $workingRoot "build\test-results\local\check-summary.json"
        if (Test-Path -LiteralPath $summaryPath -PathType Leaf) {
            try { $summary = Get-Content -LiteralPath $summaryPath -Raw -Encoding UTF8 | ConvertFrom-Json } catch { $summary = $null }
        }
    }
    if ($summary -and -not [string]$Operation.runRecordPath -and (Test-Path -LiteralPath $workingRoot -PathType Container)) {
        $startedAt = ConvertTo-DeliveryUtcDateTime -Value $summary.startedAt; $finishedAt = ConvertTo-DeliveryUtcDateTime -Value $summary.finishedAt
        $status = if ([string]$summary.status -eq "passed") { "passed" } else { "failed" }
        $error = if ($status -eq "passed") { "" } else { "Recovered after the delivery wrapper ended before recording the completed gate: $([string]$summary.error)" }
        $Operation.runRecordPath = Write-DeliveryRunRecord -Mode ([string]$summary.mode) -Status $status -ErrorMessage $error -WorkingRoot $workingRoot -StartedAt $startedAt -FinishedAt $finishedAt -ExitCode $(if ($status -eq "passed") { 0 } else { 1 })
        if ($status -eq "passed" -and [string]$summary.mode -eq "Develop") {
            $tree = (Invoke-WorktreeGit -Root $workingRoot -Arguments @("rev-parse", "HEAD^{tree}")).stdout.Trim()
            [void](Save-DeliveryQualification -CandidateRoot $workingRoot -Tree $tree)
        }
    }
    $Operation | Add-Member -NotePropertyName recoveredAt -NotePropertyValue ([DateTime]::UtcNow.ToString("o")) -Force
    $archiveRoot = Join-Path (Get-DeliveryCommonGitDirectory) "itl\operations"; New-Item -ItemType Directory -Force -Path $archiveRoot | Out-Null
    [IO.File]::WriteAllText((Join-Path $archiveRoot ("$([string]$Operation.id).json")), (($Operation | ConvertTo-Json -Depth 10) + [Environment]::NewLine), [Text.UTF8Encoding]::new($false))
    Remove-Item -LiteralPath (Get-DeliveryOperationLockPath) -Recurse -Force
}

function Enter-DeliveryOperation {
    param([Parameter(Mandatory = $true)][string]$Action)
    $lockPath = Get-DeliveryOperationLockPath
    if (Test-Path -LiteralPath $lockPath -PathType Container) {
        $status = Get-DeliveryOperationStatus
        if ($status -and ($status.ownerAlive -or $status.gateAlive)) {
            throw "Delivery operation '$($status.action)' is already active (owner PID $($status.ownerPid), gate PID $($status.gatePid), candidate '$($status.candidatePath)'). Wait for it and inspect Status before retrying."
        }
        $stale = Read-DeliveryOperation
        if ($stale) { Archive-StaleDeliveryOperation -Operation $stale }
        else {
            $lockAge = ([DateTime]::UtcNow - (Get-Item -LiteralPath $lockPath).LastWriteTimeUtc).TotalMinutes
            if ($lockAge -lt 2) { throw "Another delivery operation is acquiring the shared lock. Inspect source-delivery Status before retrying." }
            Remove-Item -LiteralPath $lockPath -Recurse -Force
        }
    }
    try { New-Item -ItemType Directory -Path $lockPath -ErrorAction Stop | Out-Null } catch { throw "Another delivery operation acquired the shared lock. Inspect source-delivery Status before retrying." }
    $owner = Get-Process -Id $PID
    $operation = [pscustomobject]@{
        schemaVersion = 1; id = [guid]::NewGuid().ToString("N"); action = $Action; startedAt = [DateTime]::UtcNow.ToString("o")
        ownerPid = $PID; ownerProcessStartedAt = $owner.StartTime.ToUniversalTime().ToString("o")
        mode = ""; workingRoot = ""; gatePid = 0; gateProcessStartedAt = ""; gateStatus = "pending"; runRecordPath = ""
    }
    Write-DeliveryOperation -Operation $operation
    $script:ActiveOperation = $operation
    return $operation
}

function Update-DeliveryOperation {
    param([hashtable]$Values)
    if (-not $script:ActiveOperation) { return }
    foreach ($key in $Values.Keys) { $script:ActiveOperation | Add-Member -NotePropertyName $key -NotePropertyValue $Values[$key] -Force }
    Write-DeliveryOperation -Operation $script:ActiveOperation
}

function Exit-DeliveryOperation {
    if (-not $script:ActiveOperation) { return }
    $current = Read-DeliveryOperation
    if ($current -and [string]$current.id -eq [string]$script:ActiveOperation.id) { Remove-Item -LiteralPath (Get-DeliveryOperationLockPath) -Recurse -Force }
    $script:ActiveOperation = $null
}
