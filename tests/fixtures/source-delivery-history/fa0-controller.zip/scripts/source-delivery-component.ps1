# Immutable component verification and publication finalization.
. (Join-Path $PSScriptRoot 'client-mcp-build.ps1')

function ConvertTo-DeliveryNativeArgument {
    param([AllowNull()][string]$Value)
    if ($null -eq $Value -or $Value.Length -eq 0) { return '""' }
    if ($Value -notmatch '[\s"]') { return $Value }
    $escaped = $Value -replace '(\\*)"', '$1$1\"'
    $escaped = $escaped -replace '(\\+)$', '$1$1'
    return '"' + $escaped + '"'
}

function Get-DeliveryGitHubRepository {
    param([string]$CandidateRoot)
    $remoteUrl = (Invoke-WorktreeGit -Root $CandidateRoot -Arguments @("remote", "get-url", $script:Remote)).stdout.Trim()
    $match = [regex]::Match($remoteUrl, '^(?:https://github\.com/|git@github\.com:|ssh://git@github\.com/)(?<owner>[^/]+)/(?<repo>[^/]+?)(?:\.git)?$')
    if (-not $match.Success) { throw "Component publication requires $($script:Remote) to be an exact github.com repository URL; actual='$remoteUrl'." }
    return [pscustomobject]@{ owner = $match.Groups["owner"].Value; repo = $match.Groups["repo"].Value; slug = ($match.Groups["owner"].Value + "/" + $match.Groups["repo"].Value) }
}

function Get-DeliveryRemoteAssetState {
    param(
        [string]$Url,
        [string]$ExpectedSha256,
        [ValidateRange(1, 3)][int]$NetworkAttempts = 3,
        [ValidateRange(1, 12)][int]$AvailabilityAttempts = 1
    )
    for ($availabilityAttempt = 1; $availabilityAttempt -le $AvailabilityAttempts; $availabilityAttempt++) {
        $downloadPath = Join-Path ([IO.Path]::GetTempPath()) ("itl-component-download-" + [guid]::NewGuid().ToString("N") + ".bin")
        try {
            try {
                $download = Invoke-ItlImmutableFileDownload -Uri $Url -DestinationPath $downloadPath -ExpectedSha256 $ExpectedSha256 `
                    -Label "Published owned component asset" -MaxAttempts $NetworkAttempts -TimeoutSeconds 300
                return [pscustomobject]@{ status = "matched"; sha256 = [string]$download.sha256 }
            } catch {
                if ($_.Exception -is [System.IO.InvalidDataException]) { throw }
                if ((Get-ItlHttpFailureStatusCode -ErrorRecord $_) -ne 404) {
                    throw "Unable to verify the immutable owned component asset without mutation: $($_.Exception.Message)"
                }
                if ($availabilityAttempt -ge $AvailabilityAttempts) {
                    return [pscustomobject]@{ status = "missing"; sha256 = "" }
                }
                Start-Sleep -Seconds ([Math]::Min(2 * $availabilityAttempt, 10))
            }
        } finally {
            Remove-Item -LiteralPath $downloadPath -Force -ErrorAction SilentlyContinue
        }
    }
    throw "Unable to determine the immutable Vanessa asset state: $Url"
}

function Get-DeliveryOwnedAssetNodes {
    param([object]$Value, [string]$Path)
    if ($null -eq $Value -or $Value -is [string]) { return }
    if ($Value -is [array]) {
        for ($index = 0; $index -lt $Value.Count; $index++) {
            Get-DeliveryOwnedAssetNodes -Value $Value[$index] -Path "$Path[$index]"
        }
        return
    }
    if ($null -ne $Value.PSObject.Properties['url']) {
        [pscustomobject]@{ path = $Path; lock = $Value }
    }
    foreach ($property in @($Value.PSObject.Properties)) {
        if ($property.Name -eq 'url') { continue }
        if ($property.Value -is [pscustomobject] -or $property.Value -is [array]) {
            Get-DeliveryOwnedAssetNodes -Value $property.Value -Path "$Path.$($property.Name)"
        }
    }
}

function Get-DeliveryOwnedAssetContracts {
    param([Parameter(Mandatory = $true)][object]$Lock, [Parameter(Mandatory = $true)][string]$RepositorySlug)
    $known = @{
        'dependencies.vanessaAutomation' = 'extension-smoke'
        'dependencies.vanessaMcp.vaExtension' = 'extension-smoke'
        'dependencies.itlOndemandMcp' = 'ondemand-mcp'
        'dependencies.vanessaMcp.clientMcp' = 'ondemand-mcp'
        'dependencies.vanessaMcp.clientMcp.correspondingSource' = 'ondemand-mcp'
    }
    $contracts = New-Object System.Collections.Generic.List[object]
    foreach ($node in @(Get-DeliveryOwnedAssetNodes -Value $Lock.dependencies -Path 'dependencies')) {
        $uri = $null
        $validUri = [Uri]::TryCreate([string]$node.lock.url, [UriKind]::Absolute, [ref]$uri)
        $match = if ($validUri) { [regex]::Match($uri.AbsolutePath, '^/(?<slug>[^/]+/[^/]+)/releases/download/(?<tag>[^/]+)/(?<asset>[^/]+)$') } else { $null }
        $ownedUrl = $validUri -and $uri.Scheme -ceq 'https' -and $uri.Host -ceq 'github.com' -and $match.Success -and
            [Uri]::UnescapeDataString($match.Groups['slug'].Value) -ceq $RepositorySlug
        $sourceProperty = $node.lock.PSObject.Properties['source']
        if (-not $ownedUrl -and ($null -eq $sourceProperty -or [string]$sourceProperty.Value -cne 'workflow-pinned')) { continue }
        if (-not $known.ContainsKey([string]$node.path)) {
            throw "Candidate dependency lock requires owned asset '$($node.path)' that this published supervisor cannot finalize. Publish supervisor support before introducing the asset."
        }
        $assetName = [string]$node.lock.assetName
        $releaseTag = [string]$node.lock.releaseTag
        $sha256 = ([string]$node.lock.sha256).ToLowerInvariant()
        if (-not $ownedUrl -or -not $assetName -or -not $releaseTag -or $sha256 -notmatch '^[a-f0-9]{64}$' -or
            [Uri]::UnescapeDataString($match.Groups['tag'].Value) -cne $releaseTag -or
            [Uri]::UnescapeDataString($match.Groups['asset'].Value) -cne $assetName) {
            throw "Candidate owned asset '$($node.path)' has an invalid URL, tag, name, or SHA256."
        }
        $contracts.Add([pscustomobject]@{
            path = [string]$node.path; url = [string]$node.lock.url; assetName = $assetName
            releaseTag = $releaseTag; sha256 = $sha256; releaseCapability = [string]$known[[string]$node.path]
        }) | Out-Null
    }
    # Recognition must be published while the previous external client pin is
    # still valid. Only the existing owned assets are unconditionally required.
    foreach ($path in @('dependencies.vanessaAutomation', 'dependencies.vanessaMcp.vaExtension', 'dependencies.itlOndemandMcp')) {
        if (@($contracts | Where-Object { $_.path -ceq $path }).Count -ne 1) {
            throw "Candidate dependency lock must define exactly one owned asset '$path'."
        }
    }
    $clientCount = @($contracts | Where-Object path -CEQ 'dependencies.vanessaMcp.clientMcp').Count
    $sourceCount = @($contracts | Where-Object path -CEQ 'dependencies.vanessaMcp.clientMcp.correspondingSource').Count
    if ($clientCount -ne $sourceCount) { throw 'Owned clientMcp requires its immutable corresponding-source ZIP in the same lock.' }
    if ($clientCount -eq 1) {
        $client = $Lock.dependencies.vanessaMcp.clientMcp
        if ([string]$client.version -cne 'v0.6.5' -or [string]$client.downstreamRevision -cnotmatch '^itl-r[1-9][0-9]*$' -or
            [string]$client.manifestSha256 -cnotmatch '^[a-f0-9]{64}$' -or [string]$client.upstreamCommit -cnotmatch '^[a-f0-9]{40}$' -or
            [string]$client.releaseTag -cne [string]$client.correspondingSource.releaseTag) {
            throw 'Owned clientMcp has an invalid compatibility, provenance or paired source identity.'
        }
    }
    return @($contracts.ToArray() | Sort-Object path)
}

function Assert-DeliveryOwnedAssetsPublished {
    param([Parameter(Mandatory = $true)][string]$CandidateRoot, [string]$CandidateCommit = '')
    if ($CandidateCommit) {
        if ($CandidateCommit -notmatch '^[a-f0-9]{40}$') { throw "Owned asset verification requires an exact candidate commit." }
        $lockResult = Invoke-WorktreeGit -Root $CandidateRoot -Arguments @('show', "${CandidateCommit}:templates/dependency-lock.json") -AllowFailure
        if ($lockResult.exitCode -ne 0) { throw "Owned asset verification cannot read the dependency lock at candidate '$CandidateCommit'." }
        $lock = $lockResult.stdout | ConvertFrom-Json
    } else {
        $lock = Get-Content -LiteralPath (Join-Path $CandidateRoot 'templates\dependency-lock.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    }
    $repository = Get-DeliveryGitHubRepository -CandidateRoot $CandidateRoot
    $contracts = @(Get-DeliveryOwnedAssetContracts -Lock $lock -RepositorySlug ([string]$repository.slug))
    foreach ($contract in $contracts) {
        $remote = Get-DeliveryRemoteAssetState -Url $contract.url -ExpectedSha256 $contract.sha256 -AvailabilityAttempts 12
        if ([string]$remote.status -cne 'matched' -or [string]$remote.sha256 -cne $contract.sha256) {
            throw "Required owned asset '$($contract.path)' is not published at its locked URL with SHA256 '$($contract.sha256)'. The develop queue is preserved."
        }
    }
    return [pscustomobject]@{ status = 'passed'; assets = $contracts }
}

function Get-DeliveryExactVanessaCandidate {
    param([string]$CandidateRoot, [object]$Lock)
    $expected = ([string]$Lock.sha256).ToLowerInvariant()
    $override = [Environment]::GetEnvironmentVariable("ITL_VANESSA_AUTOMATION_SOURCE_BUILD_ARCHIVE", "Process")
    if (-not [string]::IsNullOrWhiteSpace($override)) {
        $path = [IO.Path]::GetFullPath($override)
        if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { throw "ITL_VANESSA_AUTOMATION_SOURCE_BUILD_ARCHIVE does not exist: $path" }
        $actual = (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($actual -cne $expected) { throw "Vanessa source-build override SHA256 mismatch. expected='$expected'; actual='$actual'." }
        return $path
    }

    $folder = ([string]$Lock.compatibilityVersion) + "-" + ([string]$Lock.downstreamRevision)
    $relative = Join-Path ("build\third-party\vanessa-automation\" + $folder) ([string]$Lock.assetName)
    foreach ($root in @($CandidateRoot, $script:Root) | Select-Object -Unique) {
        $path = Join-Path $root $relative
        if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { continue }
        $actual = (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($actual -cne $expected) { throw "Canonical Vanessa candidate SHA256 mismatch. expected='$expected'; actual='$actual'; path='$path'." }
        return $path
    }
    throw "The immutable Vanessa URL is absent and no exact local candidate is available. Set ITL_VANESSA_AUTOMATION_SOURCE_BUILD_ARCHIVE or place the locked asset at the canonical candidate path."
}

function Copy-DeliveryVanessaPairedExtensionFromArchive {
    param(
        [Parameter(Mandatory = $true)][string]$ArchivePath,
        [Parameter(Mandatory = $true)][object]$Lock,
        [Parameter(Mandatory = $true)][string]$DestinationPath
    )
    foreach ($field in @("assetName", "sha256")) {
        if ($null -eq $Lock.PSObject.Properties[$field] -or [string]::IsNullOrWhiteSpace([string]$Lock.$field)) {
            throw "Vanessa paired extension lock is missing '$field'."
        }
    }
    $assetName = [string]$Lock.assetName
    $expectedSha = ([string]$Lock.sha256).ToLowerInvariant()
    if ([IO.Path]::GetFileName($assetName) -cne $assetName -or $assetName -cnotmatch '^VAExtension\.[0-9]+\.[0-9]+-itl-r[0-9]+\.cfe$') {
        throw "Vanessa paired extension assetName is invalid: $assetName"
    }
    if ($expectedSha -notmatch '^[a-f0-9]{64}$') { throw "Vanessa paired extension lock has an invalid SHA256: $expectedSha" }

    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $archive = [IO.Compression.ZipFile]::OpenRead($ArchivePath)
    try {
        $entries = @($archive.Entries | Where-Object { [string]$_.FullName -ceq $assetName })
        if ($entries.Count -ne 1) { throw "Vanessa archive must contain exactly one paired extension '$assetName'; actual=$($entries.Count)." }
        [void][IO.Directory]::CreateDirectory((Split-Path -Parent $DestinationPath))
        $input = $entries[0].Open()
        try {
            $output = [IO.File]::Open($DestinationPath, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::None)
            try { $input.CopyTo($output) } finally { $output.Dispose() }
        } finally { $input.Dispose() }
    } catch {
        Remove-Item -LiteralPath $DestinationPath -Force -ErrorAction SilentlyContinue
        throw
    } finally { $archive.Dispose() }
    $actualSha = (Get-FileHash -LiteralPath $DestinationPath -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($actualSha -cne $expectedSha) {
        Remove-Item -LiteralPath $DestinationPath -Force -ErrorAction SilentlyContinue
        throw "Vanessa paired extension SHA256 mismatch. expected='$expectedSha'; actual='$actualSha'."
    }
    return $DestinationPath
}

function Get-DeliveryRemoteAnnotatedTagCommit {
    param([string]$CandidateRoot, [string]$Tag)
    $result = Invoke-WorktreeGit -Root $CandidateRoot -Arguments @("ls-remote", "--tags", $script:Remote, "refs/tags/$Tag", "refs/tags/$Tag^{}") -AllowFailure
    if ($result.exitCode -ne 0) { throw "Unable to inspect remote component tag '$Tag'." }
    $direct = ""; $peeled = ""
    foreach ($line in @($result.stdout -split "`r?`n" | Where-Object { $_ })) {
        $parts = $line -split "\s+", 2
        if ($parts.Count -ne 2) { continue }
        if ($parts[1] -eq "refs/tags/$Tag") { $direct = $parts[0] }
        if ($parts[1] -eq "refs/tags/$Tag^{}") { $peeled = $parts[0] }
    }
    if (-not $direct) { return "" }
    if (-not $peeled) { throw "Remote component tag '$Tag' is lightweight; an immutable annotated tag is required." }
    return $peeled
}

function Assert-DeliveryComponentTagLockAgreement {
    param([string]$CandidateRoot, [string]$TagCommit, [object]$CandidateLock, [string[]]$AssetPaths)
    if (-not $TagCommit) { return }
    $tagLockResult = Invoke-WorktreeGit -Root $CandidateRoot -Arguments @('show', "${TagCommit}:templates/dependency-lock.json") -AllowFailure
    if ($tagLockResult.exitCode -ne 0) {
        throw "Existing component tag commit '$TagCommit' is not readable locally; fetch that exact tag before publication."
    }
    try { $tagLock = $tagLockResult.stdout | ConvertFrom-Json } catch {
        throw "Existing component tag commit '$TagCommit' has an invalid dependency lock."
    }
    foreach ($path in $AssetPaths) {
        $candidateAsset = $CandidateLock
        $tagAsset = $tagLock
        foreach ($segment in @($path -split '\.')) {
            $candidateAsset = if ($candidateAsset) { $candidateAsset.$segment } else { $null }
            $tagAsset = if ($tagAsset) { $tagAsset.$segment } else { $null }
        }
        $identityFields = @('releaseTag', 'url', 'assetName', 'sha256')
        if ($path -eq 'dependencies.vanessaAutomation') { $identityFields += @('compatibilityVersion', 'downstreamRevision') }
        if ($path -eq 'dependencies.vanessaMcp.vaExtension') { $identityFields += 'protocol' }
        if ($path -eq 'dependencies.vanessaMcp.clientMcp') { $identityFields += @('version', 'downstreamRevision', 'manifestSha256', 'upstreamCommit') }
        if ($path -eq 'dependencies.itlOndemandMcp') { $identityFields += 'version' }
        foreach ($field in $identityFields) {
            if (-not $candidateAsset -or -not $tagAsset -or
                -not $candidateAsset.PSObject.Properties[$field] -or -not $tagAsset.PSObject.Properties[$field] -or
                [string]$candidateAsset.$field -cne [string]$tagAsset.$field) {
                throw "Existing component tag '$TagCommit' has a different locked $path.$field; refusing to add assets to that release."
            }
        }
    }
}

function ConvertTo-DeliveryRepositoryIdentity {
    param([string]$Url)
    $value = $Url.Replace('\', '/').TrimEnd('/')
    if ($value.EndsWith('.git', [StringComparison]::OrdinalIgnoreCase)) { $value = $value.Substring(0, $value.Length - 4) }
    $value = $value -replace '^git@github\.com:', 'https://github.com/'
    $value = $value -replace '^ssh://git@github\.com/', 'https://github.com/'
    return $value.ToLowerInvariant()
}

function Get-DeliveryAiRulesRemoteState {
    param([string]$SourceRoot, [object]$Lock)
    $tag = [string]$Lock.ref
    $releaseBranch = "release/$tag"
    $result = Invoke-WorktreeGit -Root $SourceRoot -Arguments @("ls-remote", "origin", "refs/heads/$releaseBranch", "refs/tags/$tag", "refs/tags/$tag^{}", "refs/heads/main") -AllowFailure
    if ($result.exitCode -ne 0) { throw "Unable to inspect remote ai_rules_1c release '$tag'." }
    $refs = @{}
    foreach ($line in @($result.stdout -split "`r?`n" | Where-Object { $_ })) {
        $parts = $line -split "\s+", 2
        if ($parts.Count -eq 2) { $refs[$parts[1]] = $parts[0].ToLowerInvariant() }
    }
    $branchCommit = [string]$refs["refs/heads/$releaseBranch"]
    $tagObject = [string]$refs["refs/tags/$tag"]
    $tagCommit = [string]$refs["refs/tags/$tag^{}"]
    $mainCommit = [string]$refs["refs/heads/main"]
    $expected = ([string]$Lock.commit).ToLowerInvariant()
    $presentCount = @($branchCommit, $tagObject, $tagCommit | Where-Object { $_ }).Count
    $status = if ($presentCount -eq 0) {
        "missing"
    } elseif ($presentCount -eq 3 -and $branchCommit -ceq $expected -and $tagCommit -ceq $expected) {
        "matched"
    } elseif ($presentCount -lt 3) {
        "partial"
    } else {
        "mismatch"
    }
    return [pscustomobject]@{
        status = $status; releaseBranch = $releaseBranch; tag = $tag; branchCommit = $branchCommit
        tagObject = $tagObject; tagCommit = $tagCommit; mainCommit = $mainCommit
    }
}

function Remove-DeliveryPreparedAiRulesWorktree {
    if (-not $script:DeliveryPreparedAiRulesWorktree) { return }
    $prepared = $script:DeliveryPreparedAiRulesWorktree
    $repository = $script:DeliveryPreparedAiRulesRepository
    $script:DeliveryPreparedAiRulesWorktree = ""
    $script:DeliveryPreparedAiRulesRepository = ""
    if ($repository -and (Test-Path -LiteralPath $repository -PathType Container)) {
        [void](Invoke-WorktreeGit -Root $repository -Arguments @("worktree", "remove", "--force", $prepared) -AllowFailure)
        [void](Invoke-WorktreeGit -Root $repository -Arguments @("worktree", "prune") -AllowFailure)
    }
    if (Test-Path -LiteralPath $prepared) { Remove-Item -LiteralPath $prepared -Recurse -Force -ErrorAction SilentlyContinue }
}

function Get-DeliveryAiRulesWorktreeRecords {
    param([Parameter(Mandatory = $true)][string]$RepositoryRoot)
    $fields = @(Get-RepositoryGitPathList -RepositoryRoot $RepositoryRoot -Arguments @("worktree", "list", "--porcelain", "-z"))
    $records = New-Object System.Collections.Generic.List[object]
    $current = $null
    foreach ($field in $fields) {
        if ($field.StartsWith("worktree ", [StringComparison]::Ordinal)) {
            if ($current) { $records.Add([pscustomobject]$current) | Out-Null }
            $current = [ordered]@{ path = $field.Substring(9); head = "" }
        } elseif ($current -and $field.StartsWith("HEAD ", [StringComparison]::Ordinal)) {
            $current.head = $field.Substring(5).Trim().ToLowerInvariant()
        }
    }
    if ($current) { $records.Add([pscustomobject]$current) | Out-Null }
    return $records.ToArray()
}

function Test-DeliveryAiRulesQualificationFile {
    param([string]$Path, [string]$Commit, [string]$Tree)
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return $false }
    try { $qualification = Get-Content -LiteralPath $Path -Raw -Encoding UTF8 | ConvertFrom-Json } catch { return $false }
    return [string]$qualification.kind -ceq "itl-ai-rules-full-qualification" -and
        [string]$qualification.status -ceq "passed" -and [bool]$qualification.reusable -and
        [string]$qualification.repository.commit -ceq $Commit -and
        [string]$qualification.repository.tree -ceq $Tree -and [bool]$qualification.repository.worktreeClean
}

function Resolve-DeliveryAiRulesSource {
    param([object]$Lock)
    $requested = if ($script:DeliveryRequestedAiRulesSource) { [IO.Path]::GetFullPath($script:DeliveryRequestedAiRulesSource) } else { "" }
    if (-not $requested -or -not (Test-Path -LiteralPath $requested -PathType Container)) {
        throw "Owned ai_rules_1c publication requires explicit -AiRulesSource pointing to a checkout of the locked repository."
    }
    $expected = ([string]$Lock.commit).ToLowerInvariant()
    $origin = (Invoke-WorktreeGit -Root $requested -Arguments @("remote", "get-url", "origin")).stdout.Trim()
    if ((ConvertTo-DeliveryRepositoryIdentity -Url $origin) -cne (ConvertTo-DeliveryRepositoryIdentity -Url ([string]$Lock.repo))) {
        throw "ai_rules_1c source origin does not match the canonical lock repository."
    }
    $treeResult = Invoke-WorktreeGit -Root $requested -Arguments @("rev-parse", "$expected^{tree}") -AllowFailure
    $expectedTree = $treeResult.stdout.Trim().ToLowerInvariant()

    foreach ($record in @(Get-DeliveryAiRulesWorktreeRecords -RepositoryRoot $requested)) {
        if ([string]$record.head -cne $expected -or -not (Test-Path -LiteralPath ([string]$record.path) -PathType Container)) { continue }
        $status = (Invoke-WorktreeGit -Root ([string]$record.path) -Arguments @("status", "--porcelain", "--untracked-files=all")).stdout
        if ($status) { continue }
        $candidateQualification = Join-Path ([string]$record.path) "build\test-results\qualification\full.json"
        if (-not $expectedTree -or -not (Test-DeliveryAiRulesQualificationFile -Path $candidateQualification -Commit $expected -Tree $expectedTree)) { continue }
        $script:AiRulesSource = [IO.Path]::GetFullPath([string]$record.path)
        return $script:AiRulesSource
    }

    $qualificationSource = Join-Path $requested "build\test-results\qualification\full.json"
    if ($treeResult.exitCode -eq 0 -and $expectedTree -and (Test-DeliveryAiRulesQualificationFile -Path $qualificationSource -Commit $expected -Tree $expectedTree)) {
        Remove-DeliveryPreparedAiRulesWorktree
        $prepared = Join-Path ([IO.Path]::GetTempPath()) ("itl-ai-rules-exact-" + [guid]::NewGuid().ToString("N"))
        $added = Invoke-WorktreeGit -Root $requested -Arguments @("worktree", "add", "--detach", $prepared, $expected) -AllowFailure
        if ($added.exitCode -eq 0) {
            $qualificationTarget = Join-Path $prepared "build\test-results\qualification\full.json"
            New-Item -ItemType Directory -Force -Path (Split-Path -Parent $qualificationTarget) | Out-Null
            Copy-Item -LiteralPath $qualificationSource -Destination $qualificationTarget
            $script:DeliveryPreparedAiRulesWorktree = $prepared
            $script:DeliveryPreparedAiRulesRepository = $requested
            $script:AiRulesSource = $prepared
            return $prepared
        }
        if (Test-Path -LiteralPath $prepared) { Remove-Item -LiteralPath $prepared -Recurse -Force -ErrorAction SilentlyContinue }
    }
    throw "No clean ai_rules_1c worktree or reusable Full proof is available for locked commit '$expected'. Prepare the exact controlled-fork release checkout before publication."
}

function Get-DeliveryLocalAiRulesSource {
    param([object]$Lock)
    $sourceRoot = Resolve-DeliveryAiRulesSource -Lock $Lock
    $origin = (Invoke-WorktreeGit -Root $sourceRoot -Arguments @("remote", "get-url", "origin")).stdout.Trim()
    if ((ConvertTo-DeliveryRepositoryIdentity -Url $origin) -cne (ConvertTo-DeliveryRepositoryIdentity -Url ([string]$Lock.repo))) {
        throw "ai_rules_1c source origin does not match the canonical lock repository."
    }
    $status = (Invoke-WorktreeGit -Root $sourceRoot -Arguments @("status", "--porcelain", "--untracked-files=all")).stdout
    if ($status) { throw "ai_rules_1c publication source must be clean: $sourceRoot" }
    $head = (Invoke-WorktreeGit -Root $sourceRoot -Arguments @("rev-parse", "HEAD")).stdout.Trim().ToLowerInvariant()
    $expected = ([string]$Lock.commit).ToLowerInvariant()
    if ($head -cne $expected) { throw "ai_rules_1c publication source is not the locked commit. expected='$expected'; actual='$head'." }
    $tag = [string]$Lock.ref
    $tagType = (Invoke-WorktreeGit -Root $sourceRoot -Arguments @("cat-file", "-t", "refs/tags/$tag") -AllowFailure).stdout.Trim()
    $tagCommit = (Invoke-WorktreeGit -Root $sourceRoot -Arguments @("rev-parse", "refs/tags/$tag^{}") -AllowFailure).stdout.Trim().ToLowerInvariant()
    if ($tagType -cne "tag" -or $tagCommit -cne $expected) { throw "Local ai_rules_1c tag '$tag' is not an annotated tag for '$expected'." }
    $releaseBranch = "release/$tag"
    $branchCommit = (Invoke-WorktreeGit -Root $sourceRoot -Arguments @("rev-parse", "refs/heads/$releaseBranch") -AllowFailure).stdout.Trim().ToLowerInvariant()
    if ($branchCommit -cne $expected) { throw "Local ai_rules_1c release branch '$releaseBranch' does not match '$expected'." }
    $tree = (Invoke-WorktreeGit -Root $sourceRoot -Arguments @("rev-parse", "HEAD^{tree}")).stdout.Trim().ToLowerInvariant()
    $qualificationPath = Join-Path $sourceRoot "build\test-results\qualification\full.json"
    if (-not (Test-Path -LiteralPath $qualificationPath -PathType Leaf)) { throw "Exact ai_rules_1c Full qualification is missing: $qualificationPath" }
    $qualification = Get-Content -LiteralPath $qualificationPath -Raw -Encoding UTF8 | ConvertFrom-Json
    if ([string]$qualification.kind -cne "itl-ai-rules-full-qualification" -or [string]$qualification.status -cne "passed" -or
        -not [bool]$qualification.reusable -or [string]$qualification.repository.commit -cne $expected -or
        [string]$qualification.repository.tree -cne $tree -or -not [bool]$qualification.repository.worktreeClean) {
        throw "ai_rules_1c Full qualification does not match the exact locked commit and tree."
    }
    return [pscustomobject]@{ root = $sourceRoot; commit = $expected; tree = $tree; tag = $tag; releaseBranch = $releaseBranch; qualificationPath = $qualificationPath }
}

function Invoke-AiRulesComponentPublicationFinalize {
    param([string]$CandidateRoot, [string]$CandidateCommit)
    $lock = (Get-Content -LiteralPath (Join-Path $CandidateRoot "templates\dependency-lock.json") -Raw -Encoding UTF8 | ConvertFrom-Json).dependencies.aiRules1c
    foreach ($field in @("repo", "ref", "commit", "upstreamCommit", "downstreamRevision")) {
        if ($null -eq $lock.PSObject.Properties[$field] -or [string]::IsNullOrWhiteSpace([string]$lock.$field)) { throw "ai_rules_1c lock is missing '$field'." }
    }
    if ([string]$lock.compatibilityStatus -cne "passed") {
        throw "ai_rules_1c '$($lock.ref)' is published remotely but is not installable: compatibilityStatus=$($lock.compatibilityStatus)."
    }
    $local = Get-DeliveryLocalAiRulesSource -Lock $lock
    $remote = Get-DeliveryAiRulesRemoteState -SourceRoot $local.root -Lock $lock
    if ($remote.status -in @("partial", "mismatch")) {
        throw "Remote ai_rules_1c release '$($lock.ref)' is $($remote.status); immutable refs will not be repaired or repointed."
    }
    $mutated = $false
    if ($remote.status -eq "missing") {
        if ($remote.mainCommit) {
            $ancestor = Invoke-WorktreeGit -Root $local.root -Arguments @("merge-base", "--is-ancestor", $remote.mainCommit, [string]$lock.upstreamCommit) -AllowFailure
            if ($ancestor.exitCode -ne 0) { throw "Remote ai_rules_1c main cannot fast-forward to locked upstream '$($lock.upstreamCommit)'." }
        }
        $pushRefs = @(
            ([string]$lock.upstreamCommit + ":refs/heads/main"),
            ("refs/heads/$($local.releaseBranch):refs/heads/$($local.releaseBranch)"),
            ("refs/tags/$($local.tag):refs/tags/$($local.tag)")
        )
        $push = Invoke-WorktreeGit -Root $local.root -Arguments (@("push", "--atomic", "origin") + $pushRefs) -AllowFailure
        if ($push.exitCode -ne 0) {
            $raced = Get-DeliveryAiRulesRemoteState -SourceRoot $local.root -Lock $lock
            if ($raced.status -cne "matched") { throw "Unable to publish the immutable ai_rules_1c release '$($lock.ref)' atomically." }
        }
        $mutated = $true
        $remote = Get-DeliveryAiRulesRemoteState -SourceRoot $local.root -Lock $lock
    }
    if ($remote.status -cne "matched") { throw "Published ai_rules_1c refs do not match '$($lock.ref)@$($lock.commit)'." }
    $evidence = [ordered]@{
        schemaVersion = 1; status = "passed"; component = "aiRules1c"; candidateCommit = $CandidateCommit
        releaseTag = [string]$lock.ref; releaseBranch = [string]$remote.releaseBranch; commit = ([string]$lock.commit).ToLowerInvariant()
        upstreamCommit = ([string]$lock.upstreamCommit).ToLowerInvariant(); remoteMutated = $mutated
        compatibilityStatus = [string]$lock.compatibilityStatus; installable = $true
        qualificationPath = [string]$local.qualificationPath; verifiedAt = [DateTime]::UtcNow.ToString("o")
    }
    Save-DeliveryComponentPublicationEvidence -CandidateCommit $CandidateCommit -FileName "ai-rules-1c.json" -Evidence $evidence
    return [pscustomobject]$evidence
}

function Invoke-DeliveryGitHubCli {
    param([string[]]$Arguments, [switch]$AllowFailure)
    $gh = Get-Command gh -ErrorAction SilentlyContinue
    if (-not $gh) { throw "GitHub CLI is required for GitHub-backed delivery publication." }
    $previousErrorActionPreference = $ErrorActionPreference
    try {
        # Windows PowerShell converts native stderr redirected through the success
        # stream into ErrorRecord objects. Keep the native exit code authoritative
        # so expected probes such as `gh release view` for a missing release can be
        # classified by the caller when -AllowFailure is used.
        $ErrorActionPreference = "Continue"
        $output = @(& $gh.Source @Arguments 2>&1 | ForEach-Object { [string]$_ })
        $exitCode = $LASTEXITCODE
    } finally {
        $ErrorActionPreference = $previousErrorActionPreference
    }
    if (-not $AllowFailure -and $exitCode -ne 0) { throw "gh $($Arguments -join ' ') failed: $($output -join '; ')" }
    return [pscustomobject]@{ exitCode = [int]$exitCode; output = $output; text = ($output -join "`n") }
}

function Save-DeliveryComponentPublicationEvidence {
    param([string]$CandidateCommit, [string]$FileName, [object]$Evidence)
    $root = Join-Path (Get-DeliveryCommonGitDirectory) "itl\component-publications\$CandidateCommit"
    New-Item -ItemType Directory -Force -Path $root | Out-Null
    [IO.File]::WriteAllText((Join-Path $root $FileName), (($Evidence | ConvertTo-Json -Depth 8) + [Environment]::NewLine), [Text.UTF8Encoding]::new($false))
}

function Invoke-VanessaComponentPublicationFinalize {
    param([string]$CandidateRoot, [string]$CandidateCommit)
    $lockPath = Join-Path $CandidateRoot "templates\dependency-lock.json"
    if (-not (Test-Path -LiteralPath $lockPath -PathType Leaf)) { throw "Component finalization requires templates/dependency-lock.json in the exact candidate." }
    $candidateLock = Get-Content -LiteralPath $lockPath -Raw -Encoding UTF8 | ConvertFrom-Json
    $dependencies = $candidateLock.dependencies
    $lock = $dependencies.vanessaAutomation
    $pairedLock = $dependencies.vanessaMcp.vaExtension
    foreach ($field in @("releaseTag", "url", "assetName", "sha256", "compatibilityVersion", "downstreamRevision")) {
        $property = if ($null -eq $lock) { $null } else { $lock.PSObject.Properties[$field] }
        if ($null -eq $property -or [string]::IsNullOrWhiteSpace([string]$property.Value)) { throw "Vanessa component lock is missing '$field'." }
    }
    foreach ($field in @("releaseTag", "url", "assetName", "sha256", "protocol")) {
        $property = if ($null -eq $pairedLock) { $null } else { $pairedLock.PSObject.Properties[$field] }
        if ($null -eq $property -or [string]::IsNullOrWhiteSpace([string]$property.Value)) { throw "Vanessa paired extension lock is missing '$field'." }
    }
    if ([string]$pairedLock.protocol -cne 'itl-file-code-v1') { throw "Vanessa paired extension protocol is unsupported: $($pairedLock.protocol)" }
    $expectedSha = ([string]$lock.sha256).ToLowerInvariant()
    if ($expectedSha -notmatch '^[a-f0-9]{64}$') { throw "Vanessa component lock has an invalid SHA256: $expectedSha" }
    $pairedExpectedSha = ([string]$pairedLock.sha256).ToLowerInvariant()
    if ($pairedExpectedSha -notmatch '^[a-f0-9]{64}$') { throw "Vanessa paired extension lock has an invalid SHA256: $pairedExpectedSha" }
    $repository = Get-DeliveryGitHubRepository -CandidateRoot $CandidateRoot
    $uri = [Uri]([string]$lock.url)
    $urlMatch = [regex]::Match($uri.AbsolutePath, '^/(?<owner>[^/]+)/(?<repo>[^/]+)/releases/download/(?<tag>[^/]+)/(?<asset>[^/]+)$')
    if ($uri.Scheme -ne "https" -or $uri.Host -ne "github.com" -or -not $urlMatch.Success) { throw "Vanessa immutable URL is not an exact GitHub release asset URL: $($lock.url)" }
    $urlOwner = [Uri]::UnescapeDataString($urlMatch.Groups["owner"].Value)
    $urlRepo = [Uri]::UnescapeDataString($urlMatch.Groups["repo"].Value)
    $urlTag = [Uri]::UnescapeDataString($urlMatch.Groups["tag"].Value)
    $urlAsset = [Uri]::UnescapeDataString($urlMatch.Groups["asset"].Value)
    if ($urlOwner -cne $repository.owner -or $urlRepo -cne $repository.repo -or $urlTag -cne [string]$lock.releaseTag -or $urlAsset -cne [string]$lock.assetName) {
        throw "Vanessa immutable URL owner/repo/tag/asset does not match origin, releaseTag, and assetName."
    }

    $pairedUri = [Uri]([string]$pairedLock.url)
    $pairedUrlMatch = [regex]::Match($pairedUri.AbsolutePath, '^/(?<owner>[^/]+)/(?<repo>[^/]+)/releases/download/(?<tag>[^/]+)/(?<asset>[^/]+)$')
    if ($pairedUri.Scheme -ne "https" -or $pairedUri.Host -ne "github.com" -or -not $pairedUrlMatch.Success) { throw "Vanessa paired extension URL is not an exact GitHub release asset URL: $($pairedLock.url)" }
    $pairedUrlOwner = [Uri]::UnescapeDataString($pairedUrlMatch.Groups["owner"].Value)
    $pairedUrlRepo = [Uri]::UnescapeDataString($pairedUrlMatch.Groups["repo"].Value)
    $pairedUrlTag = [Uri]::UnescapeDataString($pairedUrlMatch.Groups["tag"].Value)
    $pairedUrlAsset = [Uri]::UnescapeDataString($pairedUrlMatch.Groups["asset"].Value)
    if ($pairedUrlOwner -cne $repository.owner -or $pairedUrlRepo -cne $repository.repo -or
        $pairedUrlTag -cne [string]$lock.releaseTag -or $pairedUrlTag -cne [string]$pairedLock.releaseTag -or
        $pairedUrlAsset -cne [string]$pairedLock.assetName -or $pairedUrlAsset -ceq $urlAsset) {
        throw "Vanessa paired extension URL owner/repo/tag/asset does not match the Vanessa release and paired lock."
    }

    $remote = Get-DeliveryRemoteAssetState -Url ([string]$lock.url) -ExpectedSha256 $expectedSha
    $pairedRemote = Get-DeliveryRemoteAssetState -Url ([string]$pairedLock.url) -ExpectedSha256 $pairedExpectedSha
    $mutated = $false
    if ($remote.status -eq "missing" -or $pairedRemote.status -eq "missing") {
        if (-not $RequireRelease) { throw "The locked Vanessa asset is not published. Component upload requires PublishDevelop -RequireRelease so the exact candidate passes Release first." }
        $candidatePath = if ($remote.status -eq 'missing') { Get-DeliveryExactVanessaCandidate -CandidateRoot $CandidateRoot -Lock $lock } else { '' }
        $remoteTagCommit = Get-DeliveryRemoteAnnotatedTagCommit -CandidateRoot $CandidateRoot -Tag ([string]$lock.releaseTag)
        if ($remoteTagCommit) {
            Assert-DeliveryComponentTagLockAgreement -CandidateRoot $CandidateRoot -TagCommit $remoteTagCommit -CandidateLock $candidateLock -AssetPaths @('dependencies.vanessaAutomation', 'dependencies.vanessaMcp.vaExtension')
        } else {
            $localTag = "refs/tags/$($lock.releaseTag)"
            $localTagType = (Invoke-WorktreeGit -Root $CandidateRoot -Arguments @("cat-file", "-t", $localTag) -AllowFailure).stdout.Trim()
            if ($localTagType) {
                $localTagCommit = (Invoke-WorktreeGit -Root $CandidateRoot -Arguments @("rev-parse", "$localTag^{}") -AllowFailure).stdout.Trim()
                if ($localTagType -cne "tag" -or $localTagCommit -cne $CandidateCommit) { throw "Local component tag '$($lock.releaseTag)' is not an annotated tag for exact candidate '$CandidateCommit'." }
            } else {
                [void](Invoke-WorktreeGit -Root $CandidateRoot -Arguments @("tag", "-a", [string]$lock.releaseTag, $CandidateCommit, "-m", "Vanessa Automation $($lock.downstreamRevision)"))
            }
            $tagPush = Invoke-WorktreeGit -Root $CandidateRoot -Arguments @("push", $script:Remote, $localTag) -AllowFailure
            if ($tagPush.exitCode -ne 0) {
                $racedTagCommit = Get-DeliveryRemoteAnnotatedTagCommit -CandidateRoot $CandidateRoot -Tag ([string]$lock.releaseTag)
                if ($racedTagCommit -cne $CandidateCommit) { throw "Unable to publish the immutable component tag '$($lock.releaseTag)' safely." }
            }
            $mutated = $true
        }

        $releaseView = Invoke-DeliveryGitHubCli -Arguments @("release", "view", [string]$lock.releaseTag, "--repo", $repository.slug, "--json", "assets") -AllowFailure
        if ($releaseView.exitCode -ne 0) {
            if ($releaseView.text -notmatch '(?i)(release not found|HTTP 404|not found)') { throw "Unable to inspect GitHub Release '$($lock.releaseTag)': $($releaseView.text)" }
            [void](Invoke-DeliveryGitHubCli -Arguments @("release", "create", [string]$lock.releaseTag, "--repo", $repository.slug, "--verify-tag", "--title", [string]$lock.releaseTag, "--notes", "Immutable Vanessa Automation component $($lock.downstreamRevision)."))
            $mutated = $true
            $releaseView = Invoke-DeliveryGitHubCli -Arguments @("release", "view", [string]$lock.releaseTag, "--repo", $repository.slug, "--json", "assets")
        }
        $release = $releaseView.text | ConvertFrom-Json
        $uploadRoot = Join-Path ([IO.Path]::GetTempPath()) ("itl-component-upload-" + [guid]::NewGuid().ToString("N"))
        New-Item -ItemType Directory -Force -Path $uploadRoot | Out-Null
        try {
            if ($remote.status -eq 'matched') {
                $candidatePath = Join-Path $uploadRoot ([string]$lock.assetName)
                [void](Invoke-ItlImmutableFileDownload -Uri ([string]$lock.url) -DestinationPath $candidatePath -ExpectedSha256 $expectedSha `
                    -Label 'Published Vanessa archive for paired extension' -MaxAttempts 3 -TimeoutSeconds 300)
            }
            $assetExists = @($release.assets | Where-Object { [string]$_.name -ceq [string]$lock.assetName }).Count -gt 0
            if (-not $assetExists) {
                $uploadPath = Join-Path $uploadRoot ([string]$lock.assetName)
                Copy-Item -LiteralPath $candidatePath -Destination $uploadPath
                [void](Invoke-DeliveryGitHubCli -Arguments @("release", "upload", [string]$lock.releaseTag, $uploadPath, "--repo", $repository.slug))
                $mutated = $true
            }
            $pairedAssetExists = @($release.assets | Where-Object { [string]$_.name -ceq [string]$pairedLock.assetName }).Count -gt 0
            if (-not $pairedAssetExists) {
                $pairedUploadPath = Join-Path $uploadRoot ([string]$pairedLock.assetName)
                Copy-DeliveryVanessaPairedExtensionFromArchive -ArchivePath $candidatePath -Lock $pairedLock -DestinationPath $pairedUploadPath | Out-Null
                [void](Invoke-DeliveryGitHubCli -Arguments @("release", "upload", [string]$lock.releaseTag, $pairedUploadPath, "--repo", $repository.slug))
                $mutated = $true
            }
        } finally { Remove-Item -LiteralPath $uploadRoot -Recurse -Force -ErrorAction SilentlyContinue }
        $remote = Get-DeliveryRemoteAssetState -Url ([string]$lock.url) -ExpectedSha256 $expectedSha -AvailabilityAttempts 12
        if ($remote.status -ne "matched") { throw "The Vanessa component was finalized, but its immutable URL is still unavailable. The queue is preserved for a safe retry." }
        $pairedRemote = Get-DeliveryRemoteAssetState -Url ([string]$pairedLock.url) -ExpectedSha256 $pairedExpectedSha -AvailabilityAttempts 12
        if ($pairedRemote.status -ne "matched") { throw "The Vanessa paired extension was finalized, but its immutable URL is still unavailable. The queue is preserved for a safe retry." }
    }

    $evidence = [ordered]@{
        schemaVersion = 1; status = "passed"; component = "vanessaAutomation"; candidateCommit = $CandidateCommit
        releaseTag = [string]$lock.releaseTag; url = [string]$lock.url; assetName = [string]$lock.assetName; sha256 = $expectedSha
        pairedExtension = [ordered]@{ url = [string]$pairedLock.url; assetName = [string]$pairedLock.assetName; sha256 = $pairedExpectedSha; protocol = [string]$pairedLock.protocol }
        githubRepository = $repository.slug; githubMutated = $mutated; verifiedAt = [DateTime]::UtcNow.ToString("o")
    }
    Save-DeliveryComponentPublicationEvidence -CandidateCommit $CandidateCommit -FileName "vanessa-automation.json" -Evidence $evidence
    return [pscustomobject]$evidence
}

function Get-DeliveryExactOnDemandMcpCandidate {
    param([string]$CandidateRoot, [object]$Lock)
    $expected = ([string]$Lock.sha256).ToLowerInvariant()
    $override = [Environment]::GetEnvironmentVariable("ITL_ONDEMAND_MCP_SOURCE_BUILD_EXE", "Process")
    $candidates = @()
    if (-not [string]::IsNullOrWhiteSpace($override)) { $candidates += [IO.Path]::GetFullPath($override) }
    $candidates += Join-Path $CandidateRoot ("tools\itl-ondemand-mcp\build\" + [string]$Lock.assetName)
    foreach ($path in @($candidates | Select-Object -Unique)) {
        if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { continue }
        $actual = (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($actual -cne $expected) { throw "On-demand MCP source-build SHA256 mismatch. expected='$expected'; actual='$actual'; path='$path'." }
        return $path
    }
    throw "The immutable on-demand MCP URL is absent and no exact Release-qualified source build is available."
}

function Invoke-OnDemandMcpComponentPublicationFinalize {
    param([string]$CandidateRoot, [string]$CandidateCommit)
    $candidateLock = Get-Content -LiteralPath (Join-Path $CandidateRoot "templates\dependency-lock.json") -Raw -Encoding UTF8 | ConvertFrom-Json
    $lock = $candidateLock.dependencies.itlOndemandMcp
    foreach ($field in @("releaseTag", "url", "assetName", "sha256", "version")) {
        if ($null -eq $lock.PSObject.Properties[$field] -or [string]::IsNullOrWhiteSpace([string]$lock.$field)) { throw "On-demand MCP component lock is missing '$field'." }
    }
    $expectedSha = ([string]$lock.sha256).ToLowerInvariant()
    if ($expectedSha -notmatch '^[a-f0-9]{64}$') { throw "On-demand MCP component lock has an invalid SHA256: $expectedSha" }
    $repository = Get-DeliveryGitHubRepository -CandidateRoot $CandidateRoot
    $uri = [Uri]([string]$lock.url)
    $urlMatch = [regex]::Match($uri.AbsolutePath, '^/(?<owner>[^/]+)/(?<repo>[^/]+)/releases/download/(?<tag>[^/]+)/(?<asset>[^/]+)$')
    if ($uri.Scheme -ne "https" -or $uri.Host -ne "github.com" -or -not $urlMatch.Success) { throw "On-demand MCP immutable URL is not an exact GitHub release asset URL: $($lock.url)" }
    $urlOwner = [Uri]::UnescapeDataString($urlMatch.Groups["owner"].Value)
    $urlRepo = [Uri]::UnescapeDataString($urlMatch.Groups["repo"].Value)
    $urlTag = [Uri]::UnescapeDataString($urlMatch.Groups["tag"].Value)
    $urlAsset = [Uri]::UnescapeDataString($urlMatch.Groups["asset"].Value)
    if ($urlOwner -cne $repository.owner -or $urlRepo -cne $repository.repo -or $urlTag -cne [string]$lock.releaseTag -or $urlAsset -cne [string]$lock.assetName) {
        throw "On-demand MCP immutable URL owner/repo/tag/asset does not match origin, releaseTag, and assetName."
    }

    $remote = Get-DeliveryRemoteAssetState -Url ([string]$lock.url) -ExpectedSha256 $expectedSha
    $mutated = $false
    if ($remote.status -eq "missing") {
        if (-not $RequireRelease) { throw "The locked on-demand MCP asset is not published. Exact candidate Release qualification is mandatory." }
        $candidatePath = Get-DeliveryExactOnDemandMcpCandidate -CandidateRoot $CandidateRoot -Lock $lock
        $remoteTagCommit = Get-DeliveryRemoteAnnotatedTagCommit -CandidateRoot $CandidateRoot -Tag ([string]$lock.releaseTag)
        if ($remoteTagCommit) {
            Assert-DeliveryComponentTagLockAgreement -CandidateRoot $CandidateRoot -TagCommit $remoteTagCommit -CandidateLock $candidateLock -AssetPaths @('dependencies.itlOndemandMcp')
        } else {
            $localTag = "refs/tags/$($lock.releaseTag)"
            $localTagType = (Invoke-WorktreeGit -Root $CandidateRoot -Arguments @("cat-file", "-t", $localTag) -AllowFailure).stdout.Trim()
            if ($localTagType) {
                $localTagCommit = (Invoke-WorktreeGit -Root $CandidateRoot -Arguments @("rev-parse", "$localTag^{}") -AllowFailure).stdout.Trim()
                if ($localTagType -cne "tag" -or $localTagCommit -cne $CandidateCommit) { throw "Local component tag '$($lock.releaseTag)' is not an annotated tag for exact candidate '$CandidateCommit'." }
            } else {
                [void](Invoke-WorktreeGit -Root $CandidateRoot -Arguments @("tag", "-a", [string]$lock.releaseTag, $CandidateCommit, "-m", "ITL on-demand MCP $($lock.version)"))
            }
            $tagPush = Invoke-WorktreeGit -Root $CandidateRoot -Arguments @("push", $script:Remote, $localTag) -AllowFailure
            if ($tagPush.exitCode -ne 0) {
                $racedTagCommit = Get-DeliveryRemoteAnnotatedTagCommit -CandidateRoot $CandidateRoot -Tag ([string]$lock.releaseTag)
                if ($racedTagCommit -cne $CandidateCommit) { throw "Unable to publish the immutable component tag '$($lock.releaseTag)' safely." }
            }
            $mutated = $true
        }

        $releaseView = Invoke-DeliveryGitHubCli -Arguments @("release", "view", [string]$lock.releaseTag, "--repo", $repository.slug, "--json", "assets") -AllowFailure
        if ($releaseView.exitCode -ne 0) {
            if ($releaseView.text -notmatch '(?i)(release not found|HTTP 404|not found)') { throw "Unable to inspect GitHub Release '$($lock.releaseTag)': $($releaseView.text)" }
            [void](Invoke-DeliveryGitHubCli -Arguments @("release", "create", [string]$lock.releaseTag, "--repo", $repository.slug, "--verify-tag", "--title", [string]$lock.releaseTag, "--notes", "Immutable ITL on-demand MCP $($lock.version)."))
            $mutated = $true
            $releaseView = Invoke-DeliveryGitHubCli -Arguments @("release", "view", [string]$lock.releaseTag, "--repo", $repository.slug, "--json", "assets")
        }
        $release = $releaseView.text | ConvertFrom-Json
        if (@($release.assets | Where-Object { [string]$_.name -ceq [string]$lock.assetName }).Count -eq 0) {
            [void](Invoke-DeliveryGitHubCli -Arguments @("release", "upload", [string]$lock.releaseTag, $candidatePath, "--repo", $repository.slug))
            $mutated = $true
        }
        $remote = Get-DeliveryRemoteAssetState -Url ([string]$lock.url) -ExpectedSha256 $expectedSha -AvailabilityAttempts 12
        if ($remote.status -ne "matched") { throw "The on-demand MCP component was finalized, but its immutable URL is still unavailable." }
    }

    $evidence = [ordered]@{
        schemaVersion = 1; status = "passed"; component = "itlOndemandMcp"; candidateCommit = $CandidateCommit
        releaseTag = [string]$lock.releaseTag; url = [string]$lock.url; assetName = [string]$lock.assetName; sha256 = $expectedSha
        githubRepository = $repository.slug; githubMutated = $mutated; verifiedAt = [DateTime]::UtcNow.ToString("o")
    }
    Save-DeliveryComponentPublicationEvidence -CandidateCommit $CandidateCommit -FileName "itl-ondemand-mcp.json" -Evidence $evidence
    return [pscustomobject]$evidence
}

function Get-DeliveryExactClientMcpCandidates {
    param([string]$CandidateRoot, [object]$Lock)
    $configured = [Environment]::GetEnvironmentVariable('VANESSA_MCP_CLIENT_CFE_PATH', 'Process')
    $relative = 'build/third-party/client-mcp/' + [string]$Lock.version + '-' + [string]$Lock.downstreamRevision + '/candidate'
    $folders = @()
    if ($configured) { $folders += Split-Path -Parent ([IO.Path]::GetFullPath($configured)) }
    foreach ($root in @($CandidateRoot, $script:Root) | Select-Object -Unique) { $folders += Join-Path $root $relative }
    foreach ($folder in @($folders | Select-Object -Unique)) {
        $provenancePath = Join-Path $folder 'candidate.provenance.json'
        if (-not (Test-Path -LiteralPath $provenancePath -PathType Leaf)) { continue }
        $proof = Get-Content -LiteralPath $provenancePath -Raw -Encoding UTF8 | ConvertFrom-Json
        $manifestPath = Join-Path $CandidateRoot 'third-party/client-mcp/v0.6.5-itl-r1/manifest.json'
        $manifest = Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
        if ((Get-FileHash -LiteralPath $manifestPath -Algorithm SHA256).Hash.ToLowerInvariant() -cne [string]$Lock.manifestSha256 -or
            [string]$Lock.assetName -cne [string]$manifest.artifact.fileName -or [string]$Lock.releaseTag -cne [string]$manifest.artifact.releaseTag -or
            [string]$Lock.correspondingSource.assetName -cne [string]$manifest.correspondingSource.fileName -or
            [string]$proof.platformVersion -cne [string]$manifest.build.platformVersion -or [string]$proof.platformSha256 -cne [string]$manifest.build.platformSha256) {
            throw 'clientMcp candidate lock or native toolchain differs from its controlled manifest.'
        }
        if ([string]$proof.component -cne 'clientMcp' -or [string]$proof.status -cne 'built' -or [string]$proof.sourceCommit -cnotmatch '^[a-f0-9]{40}$' -or -not $proof.restored -or -not $proof.released -or
            [string]$proof.compatibilityVersion -cne [string]$Lock.version -or [string]$proof.downstreamRevision -cne [string]$Lock.downstreamRevision -or
            [string]$proof.manifestSha256 -cne [string]$Lock.manifestSha256 -or [string]$proof.upstream.commit -cne [string]$Lock.upstreamCommit -or
            [string]$proof.artifactSha256 -cne [string]$Lock.sha256 -or [string]$proof.sourceArchiveSha256 -cne [string]$Lock.correspondingSource.sha256 -or
            [string]$proof.gate6.sourceFingerprint -cne [string]$proof.sourceIdentity.fingerprint -or
            (@($proof.gate6.steps | ForEach-Object step) -join ',') -cne 'modules,applicability,configuration' -or
            @($proof.gate6.steps | Where-Object { $_.exitCode -ne 0 -or $_.dumpResult -ne 0 }).Count -gt 0) {
            throw 'clientMcp source build has incompatible or incomplete native provenance.'
        }
        $inputProof = $proof
        $qualificationPath = Join-Path $folder 'candidate.native-qualification.json'
        if (Test-Path -LiteralPath $qualificationPath -PathType Leaf) {
            $inputProof = Get-Content -LiteralPath $qualificationPath -Raw -Encoding UTF8 | ConvertFrom-Json
            Assert-ClientMcpNativeQualification -Qualification $inputProof -BuildProof $proof -BuildProofPath $provenancePath
            # Recheck immutable source correspondence; historical build gates never
            # substitute for the fresh checks of the actually retained CFE.
            [void](Get-ClientMcpRetainedBuildEvidence -RepositoryRoot $CandidateRoot -Directory $folder -Manifest $manifest)
        }
        $requiredInputs = @(Get-ClientMcpBuildInputPaths -RepositoryRoot $CandidateRoot)
        if ((@($inputProof.buildInputs.PSObject.Properties | ForEach-Object Name | Sort-Object) -join [char]0) -cne ($requiredInputs -join [char]0)) { throw 'clientMcp native build helper inventory differs from the exact candidate.' }
        foreach ($relativeInput in $requiredInputs) {
            $inputPath = Join-Path $CandidateRoot $relativeInput
            $expectedInput = [string]$inputProof.buildInputs.$relativeInput
            if ($expectedInput -cnotmatch '^[a-f0-9]{64}$' -or
                (Get-FileHash -LiteralPath $inputPath -Algorithm SHA256).Hash.ToLowerInvariant() -cne $expectedInput) {
                throw "clientMcp build input differs from the exact candidate: $relativeInput"
            }
        }
        $assets = @(
            [pscustomobject]@{ path=(Join-Path $folder $Lock.assetName); lock=$Lock },
            [pscustomobject]@{ path=(Join-Path $folder $Lock.correspondingSource.assetName); lock=$Lock.correspondingSource }
        )
        if ($configured -and [IO.Path]::GetFullPath($assets[0].path) -ine [IO.Path]::GetFullPath($configured)) { throw 'clientMcp configured candidate name differs from its lock.' }
        foreach ($asset in $assets) {
            if (-not (Test-Path -LiteralPath $asset.path -PathType Leaf) -or
                (Get-FileHash -LiteralPath $asset.path -Algorithm SHA256).Hash.ToLowerInvariant() -cne [string]$asset.lock.sha256) {
                throw "clientMcp source build SHA256 mismatch: $($asset.path)"
            }
        }
        return $assets
    }
    throw 'No exact clientMcp native-qualified CFE and corresponding-source ZIP are available. Build the controlled candidate and retain both immutable outputs with its provenance.'
}

function Invoke-ClientMcpComponentPublicationFinalize {
    param([string]$CandidateRoot, [string]$CandidateCommit)
    $candidateLock = Get-Content -LiteralPath (Join-Path $CandidateRoot 'templates/dependency-lock.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    $repository = Get-DeliveryGitHubRepository -CandidateRoot $CandidateRoot
    $contracts = @(Get-DeliveryOwnedAssetContracts -Lock $candidateLock -RepositorySlug $repository.slug |
        Where-Object { $_.path -in @('dependencies.vanessaMcp.clientMcp', 'dependencies.vanessaMcp.clientMcp.correspondingSource') })
    if ($contracts.Count -eq 0) { return }
    $lock = $candidateLock.dependencies.vanessaMcp.clientMcp
    $missing = @($contracts | Where-Object { (Get-DeliveryRemoteAssetState -Url $_.url -ExpectedSha256 $_.sha256).status -eq 'missing' })
    $mutated = $false
    if ($missing.Count -gt 0) {
        if (-not $RequireRelease) { throw 'The locked clientMcp asset is not published. Exact candidate ondemand-mcp Release qualification is mandatory.' }
        $candidates = @(Get-DeliveryExactClientMcpCandidates -CandidateRoot $CandidateRoot -Lock $lock)
        $remoteTagCommit = Get-DeliveryRemoteAnnotatedTagCommit -CandidateRoot $CandidateRoot -Tag $lock.releaseTag
        if ($remoteTagCommit) {
            Assert-DeliveryComponentTagLockAgreement -CandidateRoot $CandidateRoot -TagCommit $remoteTagCommit -CandidateLock $candidateLock -AssetPaths @($contracts | ForEach-Object path)
        } else {
            $localTag = 'refs/tags/' + [string]$lock.releaseTag
            $localType = (Invoke-WorktreeGit -Root $CandidateRoot -Arguments @('cat-file', '-t', $localTag) -AllowFailure).stdout.Trim()
            if ($localType) {
                $localCommit = (Invoke-WorktreeGit -Root $CandidateRoot -Arguments @('rev-parse', "$localTag^{}") -AllowFailure).stdout.Trim()
                if ($localType -cne 'tag' -or $localCommit -cne $CandidateCommit) { throw 'clientMcp component tag conflicts with the exact candidate.' }
            } else {
                [void](Invoke-WorktreeGit -Root $CandidateRoot -Arguments @('tag', '-a', [string]$lock.releaseTag, $CandidateCommit, '-m', ('ITL client_mcp ' + $lock.version + ' ' + $lock.downstreamRevision)))
            }
            $push = Invoke-WorktreeGit -Root $CandidateRoot -Arguments @('push', $script:Remote, $localTag) -AllowFailure
            if ($push.exitCode -ne 0 -and (Get-DeliveryRemoteAnnotatedTagCommit -CandidateRoot $CandidateRoot -Tag $lock.releaseTag) -cne $CandidateCommit) {
                throw 'Unable to publish the immutable clientMcp component tag safely.'
            }
            $mutated = $true
        }
        $release = Invoke-DeliveryGitHubCli -Arguments @('release', 'view', [string]$lock.releaseTag, '--repo', $repository.slug, '--json', 'assets') -AllowFailure
        if ($release.exitCode -ne 0) {
            if ($release.text -notmatch '(?i)(release not found|HTTP 404|not found)') { throw "Unable to inspect clientMcp release: $($release.text)" }
            [void](Invoke-DeliveryGitHubCli -Arguments @('release', 'create', [string]$lock.releaseTag, '--repo', $repository.slug, '--verify-tag', '--title', [string]$lock.releaseTag, '--notes', 'Controlled client_mcp metadata repair. Complete corresponding Designer XML source and licenses accompany the CFE.'))
            $mutated = $true
        }
        foreach ($asset in $missing) {
            $local = @($candidates | Where-Object { [string]$_.lock.assetName -ceq $asset.assetName })[0]
            [void](Invoke-DeliveryGitHubCli -Arguments @('release', 'upload', [string]$lock.releaseTag, $local.path, '--repo', $repository.slug))
            $mutated = $true
        }
    }
    foreach ($asset in $contracts) {
        $remote = Get-DeliveryRemoteAssetState -Url $asset.url -ExpectedSha256 $asset.sha256 -AvailabilityAttempts 12
        if ($remote.status -cne 'matched' -or $remote.sha256 -cne $asset.sha256) { throw "clientMcp immutable asset is unavailable after finalization: $($asset.path)" }
    }
    $evidence = [pscustomobject]@{ schemaVersion=1; status='passed'; component='clientMcp'; candidateCommit=$CandidateCommit; assets=$contracts; mutated=$mutated; installable=$true }
    Save-DeliveryComponentPublicationEvidence -CandidateCommit $CandidateCommit -FileName 'client-mcp.json' -Evidence $evidence
    return $evidence
}

function Get-OwnedComponentPublicationPlan {
    param([string]$CandidateRoot, [string]$CandidateCommit)
    if ($script:ComponentFinalizerScript) {
        $fixturePlanPath = "$($script:ComponentFinalizerScript).plan.json"
        if (Test-Path -LiteralPath $fixturePlanPath -PathType Leaf) {
            $fixturePlan = Get-Content -LiteralPath $fixturePlanPath -Raw -Encoding UTF8 | ConvertFrom-Json
            if ([string]$fixturePlan.status -cne "planned") { throw "Component finalizer fixture plan must be planned." }
            $fixturePlan | Add-Member -NotePropertyName candidateCommit -NotePropertyValue $CandidateCommit -Force
            return $fixturePlan
        }
        return [pscustomobject]@{ status = "planned"; requiredReleaseCapabilities = @(); components = @("test-seam") }
    }
    $candidateLock = Get-Content -LiteralPath (Join-Path $CandidateRoot "templates\dependency-lock.json") -Raw -Encoding UTF8 | ConvertFrom-Json
    $lock = $candidateLock.dependencies
    $repository = Get-DeliveryGitHubRepository -CandidateRoot $CandidateRoot
    $ownedAssets = @(Get-DeliveryOwnedAssetContracts -Lock $candidateLock -RepositorySlug ([string]$repository.slug))
    $assetsByPath = @{}
    foreach ($asset in $ownedAssets) { $assetsByPath[$asset.path] = $asset }
    $vanessa = Get-DeliveryRemoteAssetState -Url $assetsByPath['dependencies.vanessaAutomation'].url -ExpectedSha256 $assetsByPath['dependencies.vanessaAutomation'].sha256
    $vanessaPaired = Get-DeliveryRemoteAssetState -Url $assetsByPath['dependencies.vanessaMcp.vaExtension'].url -ExpectedSha256 $assetsByPath['dependencies.vanessaMcp.vaExtension'].sha256
    $onDemand = Get-DeliveryRemoteAssetState -Url $assetsByPath['dependencies.itlOndemandMcp'].url -ExpectedSha256 $assetsByPath['dependencies.itlOndemandMcp'].sha256
    $clientAssets = @($ownedAssets | Where-Object { $_.path -in @('dependencies.vanessaMcp.clientMcp', 'dependencies.vanessaMcp.clientMcp.correspondingSource') })
    $clientStatus = 'external'
    if ($clientAssets.Count -gt 0) {
        $clientStatus = 'matched'
        foreach ($asset in $clientAssets) {
            $remote = Get-DeliveryRemoteAssetState -Url $asset.url -ExpectedSha256 $asset.sha256
            if ($remote.status -eq 'missing') { $clientStatus = 'missing' }
        }
        if ($clientStatus -eq 'missing') {
            $tagCommit = Get-DeliveryRemoteAnnotatedTagCommit -CandidateRoot $CandidateRoot -Tag ([string]$lock.vanessaMcp.clientMcp.releaseTag)
            Assert-DeliveryComponentTagLockAgreement -CandidateRoot $CandidateRoot -TagCommit $tagCommit -CandidateLock $candidateLock -AssetPaths @($clientAssets | ForEach-Object path)
        }
    }
    if ($vanessa.status -eq 'missing' -or $vanessaPaired.status -eq 'missing') {
        $tagCommit = Get-DeliveryRemoteAnnotatedTagCommit -CandidateRoot $CandidateRoot -Tag ([string]$lock.vanessaAutomation.releaseTag)
        Assert-DeliveryComponentTagLockAgreement -CandidateRoot $CandidateRoot -TagCommit $tagCommit -CandidateLock $candidateLock -AssetPaths @('dependencies.vanessaAutomation', 'dependencies.vanessaMcp.vaExtension')
    }
    if ($onDemand.status -eq 'missing') {
        $tagCommit = Get-DeliveryRemoteAnnotatedTagCommit -CandidateRoot $CandidateRoot -Tag ([string]$lock.itlOndemandMcp.releaseTag)
        Assert-DeliveryComponentTagLockAgreement -CandidateRoot $CandidateRoot -TagCommit $tagCommit -CandidateLock $candidateLock -AssetPaths @('dependencies.itlOndemandMcp')
    }
    $rulesSource = Get-DeliveryLocalAiRulesSource -Lock $lock.aiRules1c
    $rules = Get-DeliveryAiRulesRemoteState -SourceRoot $rulesSource.root -Lock $lock.aiRules1c
    if ($rules.status -in @("partial", "mismatch")) { throw "Remote ai_rules_1c release '$($lock.aiRules1c.ref)' is $($rules.status)." }
    return [pscustomobject]@{
        status = "planned"; candidateCommit = $CandidateCommit; ownedAssets = $ownedAssets
        requiredReleaseCapabilities = @(
            if ($vanessa.status -eq "missing" -or $vanessaPaired.status -eq "missing") { "extension-smoke" }
            if ($onDemand.status -eq "missing") { "ondemand-mcp" }
            if ($clientStatus -eq 'missing' -and $onDemand.status -ne 'missing') { 'ondemand-mcp' }
        )
        components = @(
            [pscustomobject]@{
                name = "aiRules1c"; status = $rules.status; requiredReleaseCapabilities = @()
                compatibilityStatus = [string]$lock.aiRules1c.compatibilityStatus
                compatibilityPromotionRequired = ([string]$lock.aiRules1c.compatibilityStatus -cne "passed")
            },
            [pscustomobject]@{
                name = "vanessaAutomation"
                status = $(if ($vanessa.status -eq "matched" -and $vanessaPaired.status -eq "matched") { "matched" } else { "missing" })
                requiredReleaseCapabilities = $(if ($vanessa.status -eq "missing" -or $vanessaPaired.status -eq "missing") { @("extension-smoke") } else { @() })
                assets = @([pscustomobject]@{ name = [string]$lock.vanessaAutomation.assetName; status = $vanessa.status }, [pscustomobject]@{ name = [string]$lock.vanessaMcp.vaExtension.assetName; status = $vanessaPaired.status })
            },
            [pscustomobject]@{ name = "itlOndemandMcp"; status = $onDemand.status; requiredReleaseCapabilities = $(if ($onDemand.status -eq "missing") { @("ondemand-mcp") } else { @() }) }
            if ($clientAssets.Count -gt 0) {
                [pscustomobject]@{ name='clientMcp'; status=$clientStatus; requiredReleaseCapabilities=$(if ($clientStatus -eq 'missing') { @('ondemand-mcp') } else { @() }) }
            }
        )
    }
}

function Assert-ComponentPublicationFinalizerPreflight {
    param(
        [Parameter(Mandatory = $true)][string]$CandidateRoot,
        [Parameter(Mandatory = $true)][string]$CandidateCommit,
        [Parameter(Mandatory = $true)][object]$Plan
    )

    if ([string]$Plan.status -cne "planned" -or [string]$CandidateCommit -notmatch '^[a-f0-9]{40}$') {
        throw "Component publication preflight received an invalid candidate plan."
    }
    if ($script:ComponentFinalizerScript) {
        if (-not (Test-Path -LiteralPath $script:ComponentFinalizerScript -PathType Leaf)) {
            throw "Component finalizer seam was not found: $($script:ComponentFinalizerScript)"
        }
        $tokens = $null
        $parseErrors = $null
        [void][Management.Automation.Language.Parser]::ParseFile($script:ComponentFinalizerScript, [ref]$tokens, [ref]$parseErrors)
        if (@($parseErrors).Count -gt 0) {
            throw "Component finalizer seam has PowerShell parse errors: $($parseErrors[0].Message)"
        }
        return [pscustomobject]@{ status = "passed"; component = "test-seam"; candidateCommit = $CandidateCommit }
    }

    $components = @($Plan.components)
    $expectedNames = @("aiRules1c", "itlOndemandMcp", "vanessaAutomation")
    if (@($Plan.ownedAssets | Where-Object path -CEQ 'dependencies.vanessaMcp.clientMcp').Count -eq 1) { $expectedNames += 'clientMcp' }
    $actualNames = @($components | ForEach-Object { [string]$_.name } | Sort-Object -Unique)
    if (($actualNames -join "`n") -cne (($expectedNames | Sort-Object) -join "`n")) {
        throw "Component publication plan must contain exactly: $($expectedNames -join ', ')."
    }
    foreach ($component in $components) {
        if (-not [string]$component.status) { throw "Component publication plan '$([string]$component.name)' has no status." }
        foreach ($capability in @($component.requiredReleaseCapabilities)) {
            if ([string]$capability -notmatch '^[a-z0-9][a-z0-9-]*$') {
                throw "Component '$([string]$component.name)' has an invalid Release capability '$capability'."
            }
        }
    }
    $declaredCapabilities = @($Plan.requiredReleaseCapabilities | ForEach-Object { [string]$_ } | Sort-Object -Unique)
    $componentCapabilities = @($components | ForEach-Object { @($_.requiredReleaseCapabilities) } | ForEach-Object { [string]$_ } | Where-Object { $_ } | Sort-Object -Unique)
    if (($declaredCapabilities -join "`n") -cne ($componentCapabilities -join "`n")) {
        throw "Component publication capability union does not match its component requirements."
    }

    $repository = Get-DeliveryGitHubRepository -CandidateRoot $CandidateRoot
    foreach ($property in @("owner", "repo", "slug")) {
        if (-not $repository.PSObject.Properties[$property] -or -not [string]$repository.$property) {
            throw "Component publication repository identity lacks '$property'."
        }
    }
    return [pscustomobject]@{ status = "passed"; candidateCommit = $CandidateCommit; githubRepository = [string]$repository.slug }
}

function Invoke-ComponentPublicationFinalizer {
    param([string]$CandidateRoot, [string]$CandidateCommit)
    if (-not $script:ComponentFinalizerScript) {
        $components = @(
            Invoke-AiRulesComponentPublicationFinalize -CandidateRoot $CandidateRoot -CandidateCommit $CandidateCommit
            Invoke-VanessaComponentPublicationFinalize -CandidateRoot $CandidateRoot -CandidateCommit $CandidateCommit
            Invoke-OnDemandMcpComponentPublicationFinalize -CandidateRoot $CandidateRoot -CandidateCommit $CandidateCommit
            Invoke-ClientMcpComponentPublicationFinalize -CandidateRoot $CandidateRoot -CandidateCommit $CandidateCommit
        )
        return [pscustomobject]@{ status = "passed"; candidateCommit = $CandidateCommit; components = $components }
    }
    if (-not (Test-Path -LiteralPath $script:ComponentFinalizerScript -PathType Leaf)) { throw "Component finalizer seam was not found: $($script:ComponentFinalizerScript)" }
    $arguments = @(
        "-NoLogo", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", $script:ComponentFinalizerScript,
        "-RepositoryRoot", $CandidateRoot, "-SourceRepositoryRoot", $script:Root, "-CandidateCommit", $CandidateCommit, "-Remote", $script:Remote
    )
    if ($RequireRelease) { $arguments += "-ReleaseQualified" }
    $quoted = @($arguments | ForEach-Object { ConvertTo-DeliveryNativeArgument -Value ([string]$_) })
    $logRoot = Join-Path $CandidateRoot "build\test-results\delivery"
    New-Item -ItemType Directory -Force -Path $logRoot | Out-Null
    $stdout = Join-Path $logRoot "component-finalizer.stdout.log"; $stderr = Join-Path $logRoot "component-finalizer.stderr.log"
    $process = $null; $processJob = [IntPtr]::Zero; $finalizerError = ""
    try {
        $started = Start-DeliveryProcess -ArgumentList ($quoted -join " ") -WorkingDirectory $CandidateRoot -StandardOutputPath $stdout -StandardErrorPath $stderr
        $process = $started.process
        $processJob = [IntPtr]$started.jobHandle
        while (-not $process.WaitForExit(1000)) {}
        $process.WaitForExit(); $process.Refresh()
        if ([int]$process.ExitCode -ne 0) {
            $detail = if (Test-Path -LiteralPath $stderr -PathType Leaf) { (Get-Content -LiteralPath $stderr -Raw -Encoding UTF8).Trim() } else { "" }
            throw "Component publication finalizer failed with exit code $($process.ExitCode). $detail"
        }
    } catch {
        $finalizerError = $_.Exception.Message
        throw
    } finally {
        $jobCloseError = $null
        try { Close-DeliveryProcessJob -JobHandle $processJob -Process $process -PriorErrorMessage $finalizerError } catch { $jobCloseError = $_ }
        Stop-DeliveryProcessTree -Process $process
        if ($jobCloseError) { throw $jobCloseError }
    }
    return [pscustomobject]@{ status = "passed"; component = "test-seam"; candidateCommit = $CandidateCommit }
}
