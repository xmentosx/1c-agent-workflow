[CmdletBinding()]
param(
    [ValidateSet("Full", "Develop", "Release")]
    [string]$Mode = "Full",
    [string]$RepositoryRoot = "",
    [string]$AiRulesSource = "",
    [string]$E2EProjectRoot = "",
    [string]$AgentTarget = "",
    [string]$OutputPath = "",
    [ValidateSet("Auto", "Restart")]
    [string]$ResumeMode = "Auto",
    [switch]$Offline
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"

if (-not $RepositoryRoot) { $RepositoryRoot = Split-Path -Parent $PSScriptRoot }
$RepositoryRoot = [System.IO.Path]::GetFullPath($RepositoryRoot)
. (Join-Path $PSScriptRoot "git-path-list.ps1")
. (Join-Path $PSScriptRoot "release-qualification.ps1")
. (Join-Path $PSScriptRoot 'stand-env-identity.ps1')
. (Join-Path $PSScriptRoot 'release-e2e/workflow-transition.ps1')
. (Join-Path $PSScriptRoot 'release-e2e/admission.ps1')
. (Join-Path (Split-Path -Parent $PSScriptRoot) ".agents\skills\1c-workflow\scripts\lib\agent-1c.immutable-download.ps1")
. (Join-Path (Split-Path -Parent $PSScriptRoot) ".agents\skills\1c-workflow\scripts\lib\agent-1c.package-content.ps1")
if (-not $OutputPath) { $OutputPath = Join-Path $RepositoryRoot "build\test-results\local\release-context.json" }
$OutputPath = [System.IO.Path]::GetFullPath($OutputPath)
$startedAt = [DateTime]::UtcNow
$issues = New-Object System.Collections.Generic.List[object]

function Add-ReadinessIssue {
    param(
        [string]$Code,
        [ValidateSet("SOURCE_DEFECT", "CANDIDATE_INCOMPLETE", "DEPENDENCY_DRIFT", "STAND_STALE", "ENVIRONMENT", "RUNTIME_FAILURE")]
        [string]$Category,
        [string]$Message,
        [string]$Recovery
    )
    $script:issues.Add([ordered]@{ code = $Code; category = $Category; message = $Message; recovery = $Recovery }) | Out-Null
}

function Get-JsonFile {
    param([string]$Path, [string]$Code, [string]$Label)
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
        Add-ReadinessIssue -Code $Code -Category "CANDIDATE_INCOMPLETE" -Message "$Label is missing: $Path" -Recovery "Restore the managed file from the exact workflow candidate."
        return $null
    }
    try { return Get-Content -LiteralPath $Path -Raw -Encoding UTF8 | ConvertFrom-Json } catch {
        Add-ReadinessIssue -Code $Code -Category "SOURCE_DEFECT" -Message "$Label is not valid UTF-8 JSON: $Path" -Recovery "Regenerate the file from its canonical source."
        return $null
    }
}

function Get-GitValue {
    param([string]$Root, [string[]]$Arguments)
    $value = & git -C $Root @Arguments 2>$null
    if ($LASTEXITCODE -ne 0) { return "" }
    return ([string]($value -join "`n")).Trim()
}

function Get-FileSha256 {
    param([string]$Path)
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return "" }
    $stream = [IO.File]::OpenRead($Path)
    $sha = [Security.Cryptography.SHA256]::Create()
    try { return ([BitConverter]::ToString($sha.ComputeHash($stream))).Replace("-", "").ToLowerInvariant() }
    finally { $sha.Dispose(); $stream.Dispose() }
}

function ConvertTo-NativeArgument {
    param([AllowNull()][string]$Value)
    if ($null -eq $Value -or $Value.Length -eq 0) { return '""' }
    if ($Value -notmatch '[\s"]') { return $Value }
    $escaped = $Value -replace '(\\*)"', '$1$1\"'
    $escaped = $escaped -replace '(\\+)$', '$1$1'
    return '"' + $escaped + '"'
}

function Test-PathInsideRoot {
    param([string]$Path, [string]$Root)
    if (-not $Path -or -not $Root) { return $false }
    try {
        $fullPath = [IO.Path]::GetFullPath($Path)
        $fullRoot = [IO.Path]::GetFullPath($Root).TrimEnd('\', '/')
        return $fullPath.StartsWith($fullRoot + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)
    } catch { return $false }
}

function Get-ManagedTextOrBinarySha256 {
    param([string]$Path)
    $bytes = [System.IO.File]::ReadAllBytes($Path)
    $normalizedBytes = $bytes
    if (-not ($bytes -contains [byte]0)) {
        try {
            $strictUtf8 = New-Object System.Text.UTF8Encoding($false, $true)
            $text = $strictUtf8.GetString($bytes)
            $normalizedText = $text.Replace("`r`n", "`n").Replace("`r", "`n")
            $normalizedBytes = [System.Text.Encoding]::UTF8.GetBytes($normalizedText)
        } catch {
            $normalizedBytes = $bytes
        }
    }
    $sha = [System.Security.Cryptography.SHA256]::Create()
    try {
        return ([System.BitConverter]::ToString($sha.ComputeHash($normalizedBytes))).Replace("-", "").ToLowerInvariant()
    } finally {
        $sha.Dispose()
    }
}

function Test-LockAgreement {
    param([object]$Expected, [object]$Actual, [string]$Label)
    if ($null -eq $Expected -or $null -eq $Actual) { return }
    foreach ($field in @("version", "compatibilityVersion", "downstreamRevision", "assetName", "url", "sha256", "epfSha256", "manifestSha256", "patchSha256", "upstreamCommit")) {
        $expectedProperty = $Expected.PSObject.Properties[$field]
        $actualProperty = $Actual.PSObject.Properties[$field]
        $expectedValue = if ($null -eq $expectedProperty) { "" } else { [string]$expectedProperty.Value }
        $actualValue = if ($null -eq $actualProperty) { "" } else { [string]$actualProperty.Value }
        if ($actualValue -cne $expectedValue) {
            Add-ReadinessIssue -Code "RELEASE_DEPENDENCY_LOCK_DRIFT" -Category "DEPENDENCY_DRIFT" `
                -Message "$Label vanessaAutomation.$field differs from the candidate lock. expected='$expectedValue'; actual='$actualValue'." `
                -Recovery "Run update-workflow from the exact candidate and commit the managed stand update before Release."
        }
    }
}

function Get-ManagedPackageInventory {
    param([string]$Root)
    $relativeRoots = @(
        ".agents\skills\1c-workflow",
        ".agents\skills\1c-workflow-fast",
        ".agents\skills\product-docs",
        ".agents\skills\itl-roctup-1c-data",
        ".agents\skills\itl-vanessa-ui-mcp",
        ".agents\skills\itl-remote-runner",
        ".agents\skills\itl-remote-agent",
        ".agents\skills\itl-performance",
        "docs\itl-workflow",
        "templates"
    )
    $entries = New-Object System.Collections.Generic.List[object]
    foreach ($relativeRoot in $relativeRoots) {
        $fullRoot = Join-Path $Root $relativeRoot
        if (-not (Test-Path -LiteralPath $fullRoot -PathType Container)) { continue }
        foreach ($file in @(Get-ChildItem -LiteralPath $fullRoot -Recurse -File | Sort-Object FullName)) {
            $relative = $file.FullName.Substring($Root.TrimEnd('\', '/').Length).TrimStart('\', '/').Replace('\', '/')
            if (-not (Test-WorkflowPackageContentPath -RelativePath $relative)) { continue }
            $entries.Add([ordered]@{ path = $relative; sha256 = Get-ManagedTextOrBinarySha256 -Path $file.FullName }) | Out-Null
        }
    }
    foreach ($relativeFile in @("AGENT-INSTALL.md", "install-agent-1c-workflow.ps1")) {
        $fullPath = Join-Path $Root $relativeFile
        if (Test-Path -LiteralPath $fullPath -PathType Leaf) {
            $entries.Add([ordered]@{ path = $relativeFile.Replace('\', '/'); sha256 = Get-ManagedTextOrBinarySha256 -Path $fullPath }) | Out-Null
        }
    }
    return @($entries | Sort-Object path)
}

function Test-ManagedPackageAgreement {
    param([object[]]$ExpectedInventory, [string]$TargetRoot, [string]$Label)
    if (-not (Test-Path -LiteralPath $TargetRoot -PathType Container)) {
        Add-ReadinessIssue -Code "RELEASE_STAND_PATH_MISSING" -Category "STAND_STALE" -Message "$Label root is missing: $TargetRoot" -Recovery "Provision a disposable Release stand from the exact candidate."
        return
    }
    $actualInventory = @(Get-ManagedPackageInventory -Root $TargetRoot)
    $expectedByPath = @{}
    foreach ($entry in $ExpectedInventory) { $expectedByPath[[string]$entry.path] = [string]$entry.sha256 }
    $actualByPath = @{}
    foreach ($entry in $actualInventory) { $actualByPath[[string]$entry.path] = [string]$entry.sha256 }
    $mismatches = New-Object System.Collections.Generic.List[string]
    foreach ($path in @($expectedByPath.Keys | Sort-Object)) {
        if (-not $actualByPath.ContainsKey($path) -or $actualByPath[$path] -cne $expectedByPath[$path]) { $mismatches.Add($path) | Out-Null }
    }
    foreach ($path in @($actualByPath.Keys | Sort-Object)) {
        if (-not $expectedByPath.ContainsKey($path)) { $mismatches.Add($path) | Out-Null }
    }
    if ($mismatches.Count -gt 0) {
        $preview = @($mismatches | Select-Object -First 8) -join ", "
        Add-ReadinessIssue -Code "RELEASE_STAND_MANAGED_PACKAGE_DRIFT" -Category "STAND_STALE" `
            -Message "$Label managed workflow package differs from the candidate in $($mismatches.Count) path(s): $preview" `
            -Recovery "Run update-workflow with ITL_WORKFLOW_SOURCE_PATH set to the exact candidate, review, commit, and create or refresh the disposable Release branch."
    }
}

function Resolve-VanessaArchive {
    param([object]$Lock)
    if ($null -eq $Lock) { return $null }
    $expectedSha = [string]$Lock.sha256
    $folderName = ([string]$Lock.compatibilityVersion) + "-" + ([string]$Lock.downstreamRevision)
    $canonicalPath = Join-Path $RepositoryRoot ("build\third-party\vanessa-automation\" + $folderName + "\" + [string]$Lock.assetName)
    $configuredPath = [Environment]::GetEnvironmentVariable("ITL_VANESSA_AUTOMATION_SOURCE_BUILD_ARCHIVE", "Process")
    $candidates = @()
    if (-not [string]::IsNullOrWhiteSpace($configuredPath)) {
        try { $candidates += [System.IO.Path]::GetFullPath($configuredPath) } catch {}
    }
    $candidates += $canonicalPath
    $invalidCandidates = New-Object System.Collections.Generic.List[string]
    foreach ($candidate in @($candidates | Select-Object -Unique)) {
        if (Test-Path -LiteralPath $candidate -PathType Leaf) {
            $actualSha = Get-FileSha256 -Path $candidate
            if ($actualSha -ceq $expectedSha.ToLowerInvariant()) {
                return [ordered]@{ path = $candidate; sha256 = $actualSha; source = $(if ($candidate -eq $configuredPath) { "environment" } else { "candidate-cache" }) }
            }
            $invalidCandidates.Add("$candidate (actual=$actualSha)") | Out-Null
        }
    }
    if ($Offline) {
        if ($invalidCandidates.Count -gt 0) {
            Add-ReadinessIssue -Code "RELEASE_VANESSA_ARCHIVE_HASH_MISMATCH" -Category "DEPENDENCY_DRIFT" `
                -Message "No Vanessa Automation candidate matched SHA256 '$expectedSha'. Invalid candidate(s): $($invalidCandidates -join '; ')." `
                -Recovery "Remove invalid candidates and provide the exact immutable asset."
        }
        Add-ReadinessIssue -Code "RELEASE_VANESSA_ARCHIVE_MISSING" -Category "CANDIDATE_INCOMPLETE" `
            -Message "Qualified Vanessa Automation archive is missing in offline mode: $canonicalPath" `
            -Recovery "Place the immutable locked asset at the canonical path or set ITL_VANESSA_AUTOMATION_SOURCE_BUILD_ARCHIVE."
        return $null
    }
    try {
        $download = Invoke-ItlImmutableFileDownload -Uri ([string]$Lock.url) -DestinationPath $canonicalPath -ExpectedSha256 $expectedSha -Label "Release Vanessa Automation archive"
        $downloadedSha = [string]$download.sha256
        return [ordered]@{ path = $canonicalPath; sha256 = $downloadedSha; source = "locked-url" }
    } catch {
        if ($invalidCandidates.Count -gt 0) {
            Add-ReadinessIssue -Code "RELEASE_VANESSA_ARCHIVE_HASH_MISMATCH" -Category "DEPENDENCY_DRIFT" `
                -Message "No Vanessa Automation candidate matched SHA256 '$expectedSha'. Invalid candidate(s): $($invalidCandidates -join '; ')." `
                -Recovery "Remove invalid candidates and acquire the immutable asset from the locked URL."
        }
        Add-ReadinessIssue -Code "RELEASE_VANESSA_ARCHIVE_ACQUIRE_FAILED" -Category "ENVIRONMENT" `
            -Message "Unable to acquire the immutable Vanessa Automation archive: $($_.Exception.Message)" `
            -Recovery "Verify network access to the locked URL or provide the exact archive through ITL_VANESSA_AUTOMATION_SOURCE_BUILD_ARCHIVE."
        return $null
    }
}

function Get-ZipEntrySha256 {
    param(
        [System.IO.Compression.ZipArchive]$Archive,
        [string]$EntryName
    )
    $entry = $Archive.Entries | Where-Object { $_.FullName -ceq $EntryName } | Select-Object -First 1
    if ($null -eq $entry) { return $null }
    $stream = $entry.Open()
    try {
        $sha = [System.Security.Cryptography.SHA256]::Create()
        try {
            $hash = ([System.BitConverter]::ToString($sha.ComputeHash($stream))).Replace("-", "").ToLowerInvariant()
        } finally {
            $sha.Dispose()
        }
    } finally {
        $stream.Dispose()
    }
    return [ordered]@{ entry = $entry; sha256 = $hash }
}

function Test-VanessaArchiveContract {
    param([object]$ArchiveRecord, [object]$Lock, [object]$PairedExtensionLock)
    if ($null -eq $ArchiveRecord -or $null -eq $Lock) { return }
    try {
        Add-Type -AssemblyName System.IO.Compression.FileSystem
        $zip = [System.IO.Compression.ZipFile]::OpenRead([string]$ArchiveRecord.path)
        try {
            $epf = Get-ZipEntrySha256 -Archive $zip -EntryName "vanessa-automation-single.epf"
            $manifest = Get-ZipEntrySha256 -Archive $zip -EntryName "ITL-PROVENANCE.json"
            $pairedExtension = if ($null -eq $PairedExtensionLock) { $null } else { Get-ZipEntrySha256 -Archive $zip -EntryName ([string]$PairedExtensionLock.assetName) }
            $notice = $zip.Entries | Where-Object { $_.FullName -ceq "ITL-NOTICE.txt" } | Select-Object -First 1
            if ($null -eq $epf -or $null -eq $manifest -or $null -eq $notice -or $null -eq $pairedExtension) {
                Add-ReadinessIssue -Code "RELEASE_VANESSA_ARCHIVE_STRUCTURE_INVALID" -Category "CANDIDATE_INCOMPLETE" `
                    -Message "Vanessa Automation archive must contain the EPF, paired VAExtension, ITL-PROVENANCE.json, and ITL-NOTICE.txt." `
                    -Recovery "Acquire the exact immutable workflow-pinned asset."
                return
            }
            if ([string]$epf.sha256 -cne ([string]$Lock.epfSha256).ToLowerInvariant()) {
                Add-ReadinessIssue -Code "RELEASE_VANESSA_EPF_HASH_MISMATCH" -Category "DEPENDENCY_DRIFT" `
                    -Message "Vanessa Automation EPF SHA256 differs from the lock. expected=$($Lock.epfSha256); actual=$($epf.sha256)." `
                    -Recovery "Use an archive built and published from the exact downstream revision."
            }
            if ([string]$manifest.sha256 -cne ([string]$Lock.manifestSha256).ToLowerInvariant()) {
                Add-ReadinessIssue -Code "RELEASE_VANESSA_MANIFEST_HASH_MISMATCH" -Category "DEPENDENCY_DRIFT" `
                    -Message "Vanessa Automation provenance manifest SHA256 differs from the lock. expected=$($Lock.manifestSha256); actual=$($manifest.sha256)." `
                    -Recovery "Regenerate the lock from the exact immutable artifact manifest."
            }
            if ([string]$pairedExtension.sha256 -cne ([string]$PairedExtensionLock.sha256).ToLowerInvariant()) {
                Add-ReadinessIssue -Code "RELEASE_VANESSA_PAIRED_EXTENSION_HASH_MISMATCH" -Category "DEPENDENCY_DRIFT" `
                    -Message "Vanessa paired VAExtension SHA256 differs from the lock. expected=$($PairedExtensionLock.sha256); actual=$($pairedExtension.sha256)." `
                    -Recovery "Use the paired extension built from the same exact downstream Vanessa revision."
            }
            $reader = [System.IO.StreamReader]::new($manifest.entry.Open(), [System.Text.Encoding]::UTF8, $true)
            try { $provenance = $reader.ReadToEnd() | ConvertFrom-Json } finally { $reader.Dispose() }
            foreach ($pair in @(
                @("compatibilityVersion", [string]$provenance.compatibilityVersion, [string]$Lock.compatibilityVersion),
                @("downstreamRevision", [string]$provenance.downstreamRevision, [string]$Lock.downstreamRevision),
                @("upstreamCommit", [string]$provenance.upstream.commit, [string]$Lock.upstreamCommit),
                @("patchSha256", [string]$provenance.patch.sha256, [string]$Lock.patchSha256),
                @("artifactFileName", [string]$provenance.artifact.fileName, [string]$Lock.assetName),
                @("artifactEntryPoint", [string]$provenance.artifact.entryPoint, "vanessa-automation-single.epf"),
                @("pairedExtensionFileName", [string]$provenance.pairedExtension.fileName, [string]$PairedExtensionLock.assetName),
                @("pairedExtensionProtocol", [string]$provenance.pairedExtension.protocol, [string]$PairedExtensionLock.protocol)
            )) {
                if ([string]$pair[1] -cne [string]$pair[2]) {
                    Add-ReadinessIssue -Code "RELEASE_VANESSA_PROVENANCE_DRIFT" -Category "DEPENDENCY_DRIFT" `
                        -Message "Vanessa Automation provenance $($pair[0]) differs from the lock. expected='$($pair[2])'; actual='$($pair[1])'." `
                        -Recovery "Use one manifest as the source for the asset, compatibility metadata, and dependency lock."
                }
            }
        } finally {
            $zip.Dispose()
        }
    } catch {
        Add-ReadinessIssue -Code "RELEASE_VANESSA_ARCHIVE_UNREADABLE" -Category "CANDIDATE_INCOMPLETE" `
            -Message "Vanessa Automation archive is not a readable qualified ZIP: $($_.Exception.Message)" `
            -Recovery "Acquire the exact immutable workflow-pinned asset."
    }
}

function Test-PowerShellEncoding {
    $reportPath = Join-Path ([IO.Path]::GetTempPath()) ("itl-powershell-encoding-" + [guid]::NewGuid().ToString("N") + ".json")
    try {
        & (Join-Path $PSScriptRoot "test-powershell-encoding.ps1") -RepositoryRoot $RepositoryRoot -OutputPath $reportPath -ReportOnly | Out-Null
        $report = Get-Content -LiteralPath $reportPath -Raw -Encoding UTF8 | ConvertFrom-Json
        foreach ($issue in @($report.issues)) {
            Add-ReadinessIssue -Code ([string]$issue.code) -Category "SOURCE_DEFECT" `
                -Message ([string]$issue.message) `
                -Recovery "Store non-ASCII Windows PowerShell source with a UTF-8 BOM, or keep the script ASCII-safe and pass Unicode through UTF-8 JSON/files, environment variables, or Base64."
        }
        return @($report.changedPowerShellFiles)
    } catch {
        Add-ReadinessIssue -Code "RELEASE_POWERSHELL_ENCODING_INVALID" -Category "SOURCE_DEFECT" `
            -Message "PowerShell encoding preflight failed: $($_.Exception.Message)" `
            -Recovery "Make powershell.exe 5.1 available and keep the decode preflight executable before release."
        return @()
    } finally {
        Remove-Item -LiteralPath $reportPath -Force -ErrorAction SilentlyContinue
    }
}

function Test-ReleaseCheckpointPreflight {
    param(
        [string]$StandProjectRoot,
        [string]$StandWorktree,
        [string]$DevBranchName,
        [string]$CandidateCommit,
        [string]$CandidateTree,
        [string]$AiRulesCommit,
        [string]$AiRulesTree = ""
    )

    $safeRunName = ($DevBranchName -replace '[^A-Za-z0-9_.-]', '_')
    $preferredPath = Join-Path $StandWorktree ".agent-1c\runs\release-e2e\$safeRunName\checkpoint.json"
    $legacyPath = Join-Path $StandWorktree ".agent-1c\release-e2e-runs\$safeRunName\checkpoint.json"
    $checkpointPath = if (Test-Path -LiteralPath $preferredPath -PathType Leaf) { $preferredPath } elseif (Test-Path -LiteralPath $legacyPath -PathType Leaf) { $legacyPath } else { "" }
    $record = [ordered]@{
        path = $checkpointPath
        status = $(if ($checkpointPath) { "found" } else { "absent" })
        expectedHead = ""
        currentHead = Get-GitValue -Root $StandWorktree -Arguments @("rev-parse", "HEAD")
        fixturePath = ""
        verificationFresh = $null
        exactIdentity = $false
    }
    if (-not $checkpointPath) { return $record }

    $checkpoint = Get-JsonFile -Path $checkpointPath -Code "RELEASE_CHECKPOINT_INVALID" -Label "Release E2E checkpoint"
    if ($null -eq $checkpoint) { $record.status = "invalid"; return $record }
    $expectedHeadProperty = $checkpoint.PSObject.Properties["expectedHead"]
    if ($null -ne $expectedHeadProperty) { $record.expectedHead = [string]$expectedHeadProperty.Value }
    $identityProperty = $checkpoint.PSObject.Properties["identity"]
    $identity = if ($null -eq $identityProperty) { $null } else { $identityProperty.Value }
    $checkpointSchema = 0
    $schemaProperty = $checkpoint.PSObject.Properties["schemaVersion"]
    $schemaSupported = $null -ne $schemaProperty -and [int]::TryParse([string]$schemaProperty.Value, [ref]$checkpointSchema) -and $checkpointSchema -in @(1, 2, 3)
    $projectPath = Join-Path $StandWorktree '.agent-1c/project.json'
    $project = Get-Content -LiteralPath $projectPath -Raw -Encoding UTF8 | ConvertFrom-Json
    $standConfig = Get-Content -LiteralPath (Join-Path $StandProjectRoot '.agent-1c/release-e2e.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    $serverConfiguration = [ordered]@{}
    foreach ($name in @('serverProjectRoot', 'serverWorktreePath', 'serverDevBranchName')) { $serverConfiguration[$name] = [string](Get-E2EAdmissionValue $standConfig $name '') }
    $admissionContext = [ordered]@{
        workflowRoot = $RepositoryRoot; workflowCommit = $CandidateCommit; workflowTree = $CandidateTree
        projectRoot = $StandProjectRoot; worktreePath = $StandWorktree; branch = "itldev/$DevBranchName"
        currentHead = $record.currentHead; masterHead = Get-GitValue -Root $StandProjectRoot -Arguments @('rev-parse', 'HEAD')
        worktreeClean = @(Get-RepositoryGitPathList -RepositoryRoot $StandWorktree -Arguments @('status', '--porcelain', '--untracked-files=all', '-z')).Count -eq 0
        exportPath = [string](Get-E2EAdmissionValue $project 'exportPath' ''); resumeMode = $ResumeMode
        runnerSha256 = Get-E2EAdmissionCanonicalTextSha256 -Path (Join-Path $RepositoryRoot 'scripts/invoke-release-e2e.ps1')
        helperSha256 = Get-E2EAdmissionCanonicalTextSha256 -Path (Join-Path $RepositoryRoot '.agents/skills/1c-workflow/scripts/agent-1c.ps1')
        projectConfigSha256 = Get-FileSha256 -Path $projectPath
        aiRulesCommit = $AiRulesCommit; aiRulesTree = $AiRulesTree
        clientSelection = Get-SourceE2EClientIdentity -ProjectRoot $StandProjectRoot -AgentTarget $AgentTarget
        stageModuleRoot = Join-Path $RepositoryRoot 'scripts/release-e2e'
        stageDefinitions = $null
        serverConfiguration = $serverConfiguration
    }
    $admission = Get-E2EReleaseCheckpointAdmission -Context $admissionContext -Checkpoint $checkpoint
    $scopeMatches = $admission.scopeMatches
    if (-not $scopeMatches) {
        Add-ReadinessIssue -Code "RELEASE_CHECKPOINT_SCOPE_MISMATCH" -Category "STAND_STALE" `
            -Message "Release checkpoint has unsupported schema or belongs to another project, worktree, or branch: schema=$checkpointSchema path=$checkpointPath" `
            -Recovery "Use the checkpoint owned by this disposable Release stand, or perform the script-owned Restart on the owning stand."
    }
    if ($schemaSupported -and $checkpointSchema -lt 3 -and $ResumeMode -eq "Auto") {
        Add-ReadinessIssue -Code "RELEASE_CHECKPOINT_UPGRADE_REQUIRED" -Category "STAND_STALE" `
            -Message "Release checkpoint schema v$checkpointSchema requires one script-owned Restart migration." `
            -Recovery "Run Release once with ResumeMode Restart."
    }

    $exactIdentity = $admission.exactIdentity
    $record.exactIdentity = $exactIdentity
    # Serialize the safe decision only, never the transient context or raw env.
    $record['transition'] = [ordered]@{ allowed = $admission.allowed; code = $admission.code; reason = $admission.reason; crossReleaseReuse = $admission.crossReleaseReuse; sourceContinuationRequired = $admission.sourceContinuationRequired; sourceContinuationProven = [bool]$admission.continuationProof }

    if ($ResumeMode -eq 'Auto' -and $scopeMatches -and $checkpointSchema -ge 3 -and -not $admission.allowed) {
        $code = if ($exactIdentity) { 'RELEASE_CHECKPOINT_HEAD_MISMATCH' } else { 'RELEASE_CHECKPOINT_TRANSITION_UNPROVEN' }
        Add-ReadinessIssue -Code $code -Category 'STAND_STALE' `
            -Message "Release checkpoint expected HEAD '$($record.expectedHead)', current='$($record.currentHead)': $($admission.reason)." `
            -Recovery 'Inspect the unsupported transition before Develop. Keep the checkpoint and use the existing script-owned Restart when rollback is intended; an extra refresh after workflow-update is not an admitted chain.'
    }

    if ($admission.allowed) {
        try {
            Assert-E2EAdmissionCheckpointSupport -Context $admissionContext -Checkpoint $checkpoint
            if ($ResumeMode -eq 'Auto') {
                $admissionContext['stageDefinitions'] = Get-E2EAdmissionStageDefinitions -WorkflowRoot $RepositoryRoot
                $record['stageDecisions'] = @(Get-E2EAdmissionCheckpointStageDecisions -Context $admissionContext -Checkpoint $checkpoint -Admission $admission)
            }
        } catch {
            Add-ReadinessIssue -Code 'RELEASE_CHECKPOINT_SUPPORT_INVALID' -Category 'STAND_STALE' -Message $_.Exception.Message -Recovery 'Preserve the checkpoint and its original receipts; repair the exact owned snapshot/state/evidence before continuation.'
        }
    }

    $checkpointFixturePath = ""
    $configEvidenceProperty = $checkpoint.PSObject.Properties["configEvidence"]
    if ($null -ne $configEvidenceProperty -and $null -ne $configEvidenceProperty.Value) {
        $featurePathProperty = $configEvidenceProperty.Value.PSObject.Properties["featurePath"]
        if ($null -ne $featurePathProperty) { $checkpointFixturePath = [string]$featurePathProperty.Value }
    }
    if ($ResumeMode -eq "Auto" -and $checkpointFixturePath) {
        $record.fixturePath = $checkpointFixturePath
        if (-not (Test-PathInsideRoot -Path $checkpointFixturePath -Root $StandWorktree) -or -not (Test-Path -LiteralPath $checkpointFixturePath -PathType Leaf)) {
            Add-ReadinessIssue -Code "RELEASE_CHECKPOINT_FIXTURE_INVALID" -Category "STAND_STALE" `
                -Message "Checkpointed Vanessa fixture is missing or outside the canonical Release worktree: $checkpointFixturePath" `
                -Recovery "Restart from a candidate that creates the feature below the disposable Release worktree."
        }
    }

    $snapshotsProperty = $checkpoint.PSObject.Properties['snapshots']
    if ($null -ne $snapshotsProperty -and $snapshotsProperty.Value -is [pscustomobject]) {
        foreach ($snapshotProperty in @($snapshotsProperty.Value.PSObject.Properties)) {
            $snapshot = $snapshotProperty.Value
            $snapshotPath = if ($snapshot -and $snapshot.PSObject.Properties['path']) { [string]$snapshot.path } else { '' }
            $snapshotSha = if ($snapshot -and $snapshot.PSObject.Properties['sha256']) { ([string]$snapshot.sha256).ToLowerInvariant() } else { '' }
            if (-not $snapshotPath -or -not (Test-PathInsideRoot -Path $snapshotPath -Root $StandWorktree) -or
                -not (Test-Path -LiteralPath $snapshotPath -PathType Leaf) -or
                $snapshotSha -notmatch '^[a-f0-9]{64}$' -or (Get-FileSha256 -Path $snapshotPath) -cne $snapshotSha) {
                Add-ReadinessIssue -Code 'RELEASE_CHECKPOINT_SNAPSHOT_INVALID' -Category 'STAND_STALE' `
                    -Message "Release checkpoint $($snapshotProperty.Name) snapshot is missing, outside its stand, or differs from its recorded SHA256: $snapshotPath" `
                    -Recovery 'Preserve the damaged checkpoint for diagnosis and rebuild the owned disposable Release stand from its fixture.'
            }
        }
    } elseif ($null -ne $snapshotsProperty) {
        Add-ReadinessIssue -Code 'RELEASE_CHECKPOINT_SNAPSHOT_INVALID' -Category 'STAND_STALE' `
            -Message "Release checkpoint snapshots inventory is malformed: $checkpointPath" `
            -Recovery 'Preserve the damaged checkpoint for diagnosis and rebuild the owned disposable Release stand from its fixture.'
    }

    $stagesProperty = $checkpoint.PSObject.Properties["stages"]
    if ($null -ne $stagesProperty -and $stagesProperty.Value -is [pscustomobject] -and
        @($stagesProperty.Value.PSObject.Properties).Count -gt 0 -and
        ($null -eq $snapshotsProperty -or $snapshotsProperty.Value -isnot [pscustomobject] -or
            $null -eq $snapshotsProperty.Value.PSObject.Properties['baseline'])) {
        Add-ReadinessIssue -Code 'RELEASE_CHECKPOINT_SNAPSHOT_INVALID' -Category 'STAND_STALE' `
            -Message "Release checkpoint has executed stages but no baseline snapshot record: $checkpointPath" `
            -Recovery 'Preserve the damaged checkpoint for diagnosis and rebuild the owned disposable Release stand from its fixture.'
    }
    $refreshStage = if ($null -eq $stagesProperty -or $null -eq $stagesProperty.Value) { $null } else { $stagesProperty.Value.PSObject.Properties["verification-refresh"] }
    if ($ResumeMode -eq "Auto" -and $exactIdentity -and $null -ne $refreshStage -and [string]$refreshStage.Value.status -eq "passed") {
        $fresh = $false
        $stateFilesProperty = $checkpoint.PSObject.Properties["stateFiles"]
        $stateRecord = if ($null -eq $stateFilesProperty -or $null -eq $stateFilesProperty.Value) { $null } else { $stateFilesProperty.Value.PSObject.Properties["postConfig"] }
        if ($null -ne $stateRecord) {
            $stateCopyPath = [string]$stateRecord.Value.stateCopyPath
            if (Test-Path -LiteralPath $stateCopyPath -PathType Leaf) {
                try {
                    $savedState = Get-Content -LiteralPath $stateCopyPath -Raw -Encoding UTF8 | ConvertFrom-Json
                    $verifiedAt = [DateTime]::Parse([string]$savedState.lastVerifiedAt).ToUniversalTime()
                    $createdAtProperty = $checkpoint.PSObject.Properties["createdAt"]
                    if ($null -eq $createdAtProperty) { throw "checkpoint createdAt is missing" }
                    $checkpointFloor = [DateTime]::Parse([string]$createdAtProperty.Value).ToUniversalTime()
                    $fresh = [string]$savedState.lastVerificationStatus -eq "passed" -and $verifiedAt -ge $checkpointFloor
                } catch { $fresh = $false }
            }
        }
        $record.verificationFresh = $fresh
        if (-not $fresh) {
            Add-ReadinessIssue -Code "RELEASE_CHECKPOINT_VERIFICATION_STALE" -Category "STAND_STALE" `
                -Message "Checkpoint marks verification-refresh passed, but its saved post-config state has no fresh passed verification." `
                -Recovery "Use the script-owned Restart so verification is refreshed before result/export."
        }
    }
    return $record
}

$commit = Get-GitValue -Root $RepositoryRoot -Arguments @("rev-parse", "HEAD")
$tree = Get-GitValue -Root $RepositoryRoot -Arguments @("rev-parse", "HEAD^{tree}")
$branch = Get-GitValue -Root $RepositoryRoot -Arguments @("branch", "--show-current")
$trackedStatus = @(& git -C $RepositoryRoot status --porcelain)
$worktreeClean = $trackedStatus.Count -eq 0
if (-not $commit -or -not $tree) {
    Add-ReadinessIssue -Code "RELEASE_SOURCE_NOT_GIT" -Category "CANDIDATE_INCOMPLETE" -Message "Workflow source is not a readable Git checkout: $RepositoryRoot" -Recovery "Create a clean worktree from the intended release commit."
}
if ($Mode -eq "Release" -and -not $worktreeClean) {
    Add-ReadinessIssue -Code "RELEASE_SOURCE_DIRTY" -Category "CANDIDATE_INCOMPLETE" -Message "Release candidate worktree has tracked changes." -Recovery "Commit the coherent candidate and rerun Release from the clean commit."
}

$templateLockPath = Join-Path $RepositoryRoot "templates\dependency-lock.json"
$templateLock = Get-JsonFile -Path $templateLockPath -Code "RELEASE_TEMPLATE_LOCK_INVALID" -Label "Workflow dependency lock template"
$vanessaLock = if ($null -eq $templateLock) { $null } else { $templateLock.dependencies.vanessaAutomation }
$vanessaPairedExtensionLock = if ($null -eq $templateLock) { $null } else { $templateLock.dependencies.vanessaMcp.vaExtension }
$compatibilityPath = Join-Path $RepositoryRoot ".agents\skills\1c-workflow\assets\ondemand-mcp\compatibility.json"
$compatibility = Get-JsonFile -Path $compatibilityPath -Code "RELEASE_COMPATIBILITY_INVALID" -Label "On-demand compatibility manifest"
if ($null -ne $vanessaLock -and $null -ne $compatibility) {
    $family = $compatibility.families.'vanessa-ui'
    $pairs = @(
        @("compatibilityVersion", [string]$family.backendVersions.vanessaAutomation),
        @("downstreamRevision", [string]$family.backendRevisions.vanessaAutomation),
        @("sha256", [string]$family.vanessaAutomationArtifact.archiveSha256),
        @("epfSha256", [string]$family.vanessaAutomationArtifact.epfSha256),
        @("manifestSha256", [string]$family.vanessaAutomationArtifact.manifestSha256),
        @("patchSha256", [string]$family.vanessaAutomationArtifact.patchSha256),
        @("upstreamCommit", [string]$family.vanessaAutomationArtifact.upstreamCommit)
    )
    foreach ($pair in $pairs) {
        $field = [string]$pair[0]
        $expected = [string]$vanessaLock.PSObject.Properties[$field].Value
        $actual = [string]$pair[1]
        if ($actual -cne $expected) {
            Add-ReadinessIssue -Code "RELEASE_COMPATIBILITY_LOCK_DRIFT" -Category "DEPENDENCY_DRIFT" `
                -Message "Compatibility manifest $field differs from templates/dependency-lock.json. expected='$expected'; actual='$actual'." `
                -Recovery "Regenerate compatibility metadata and lock expectations from one immutable artifact manifest."
        }
    }
    if ($null -ne $vanessaPairedExtensionLock) {
        foreach ($pair in @(
            @("version", [string]$family.backendVersions.vaExtension),
            @("assetName", [string]$family.pairedExtensionArtifact.assetName),
            @("sha256", [string]$family.pairedExtensionArtifact.sha256),
            @("protocol", [string]$family.pairedExtensionArtifact.protocol)
        )) {
            $field = [string]$pair[0]
            $expected = [string]$vanessaPairedExtensionLock.PSObject.Properties[$field].Value
            $actual = [string]$pair[1]
            if ($actual -cne $expected) {
                Add-ReadinessIssue -Code "RELEASE_COMPATIBILITY_PAIRED_EXTENSION_DRIFT" -Category "DEPENDENCY_DRIFT" `
                    -Message "Compatibility manifest paired VAExtension $field differs from templates/dependency-lock.json. expected='$expected'; actual='$actual'." `
                    -Recovery "Regenerate compatibility metadata and both Vanessa locks from one immutable paired artifact."
            }
        }
    }
}

$archive = Resolve-VanessaArchive -Lock $vanessaLock
Test-VanessaArchiveContract -ArchiveRecord $archive -Lock $vanessaLock -PairedExtensionLock $vanessaPairedExtensionLock
$changedPowerShell = @(Test-PowerShellEncoding)
$managedInventory = @(Get-ManagedPackageInventory -Root $RepositoryRoot)
$managedInventoryText = @($managedInventory | ForEach-Object { "$($_.path)`t$($_.sha256)" }) -join "`n"
$managedInventorySha = ""
if ($managedInventoryText) {
    $sha = [System.Security.Cryptography.SHA256]::Create()
    try { $managedInventorySha = ([System.BitConverter]::ToString($sha.ComputeHash([System.Text.Encoding]::UTF8.GetBytes($managedInventoryText)))).Replace("-", "").ToLowerInvariant() } finally { $sha.Dispose() }
}

$forkRecord = [ordered]@{ sourceRoot = ""; tag = ""; commit = ""; status = "not-local" }
if ($null -ne $templateLock) {
    $forkRecord.tag = [string]$templateLock.dependencies.aiRules1c.ref
    $forkRecord.commit = [string]$templateLock.dependencies.aiRules1c.commit
}
if ($AiRulesSource -and (Test-Path -LiteralPath $AiRulesSource -PathType Container)) {
    $forkRoot = [System.IO.Path]::GetFullPath($AiRulesSource)
    $forkHead = Get-GitValue -Root $forkRoot -Arguments @("rev-parse", "HEAD")
    $forkStatus = @(& git -C $forkRoot status --porcelain)
    $forkRecord.sourceRoot = $forkRoot
    $forkRecord.status = "validated"
    if ($forkHead -cne [string]$forkRecord.commit -or $forkStatus.Count -gt 0) {
        Add-ReadinessIssue -Code "RELEASE_FORK_IDENTITY_MISMATCH" -Category "DEPENDENCY_DRIFT" `
            -Message "Controlled fork checkout is not the clean locked commit. expected='$($forkRecord.commit)'; actual='$forkHead'." `
            -Recovery "Use a clean worktree checked out at the annotated pinned fork tag."
    }
    $tagType = Get-GitValue -Root $forkRoot -Arguments @("cat-file", "-t", "refs/tags/$($forkRecord.tag)")
    $tagCommit = Get-GitValue -Root $forkRoot -Arguments @("rev-parse", "refs/tags/$($forkRecord.tag)^{}")
    if ($tagType -cne "tag" -or $tagCommit -cne [string]$forkRecord.commit) {
        Add-ReadinessIssue -Code "RELEASE_FORK_TAG_INVALID" -Category "DEPENDENCY_DRIFT" `
            -Message "Pinned fork tag is missing, lightweight, or points at another commit: $($forkRecord.tag)." `
            -Recovery "Use the immutable annotated controlled-fork release tag."
    }
} elseif ($Mode -eq "Release") {
    Add-ReadinessIssue -Code "RELEASE_FORK_SOURCE_MISSING" -Category "CANDIDATE_INCOMPLETE" -Message "Release requires a local exact controlled-fork worktree." -Recovery "Pass -AiRulesSource pointing to the clean pinned tag worktree."
}

$standRecord = $null
if ($Mode -in @("Develop", "Release")) {
    if (-not $E2EProjectRoot) {
        Add-ReadinessIssue -Code "RELEASE_STAND_CONFIG_MISSING" -Category "STAND_STALE" -Message "$Mode has no E2E project root." -Recovery "Pass the dedicated E2E project root."
    } else {
        $E2EProjectRoot = [System.IO.Path]::GetFullPath($E2EProjectRoot)
        $standConfigPath = Join-Path $E2EProjectRoot ".agent-1c\release-e2e.json"
        $standConfig = Get-JsonFile -Path $standConfigPath -Code "RELEASE_STAND_CONFIG_INVALID" -Label "Release E2E configuration"
        if ($null -ne $standConfig) {
            if ($Mode -eq "Develop") {
                $developBranchName = [string]$standConfig.developDevBranchName
                $developWorktreeValue = [string]$standConfig.developWorktreePath
                $releaseWorktreeValue = [string]$standConfig.worktreePath
                if (-not $developBranchName -or -not $developWorktreeValue -or -not $releaseWorktreeValue) {
                    Add-ReadinessIssue -Code "DEVELOP_E2E_ISOLATED_STAND_REQUIRED" -Category "STAND_STALE" `
                        -Message "release-e2e.json must define developDevBranchName and developWorktreePath separately from the Release worktree." `
                        -Recovery "Provision and configure a dedicated disposable Develop E2E branch."
                } else {
                    $developWorktree = [IO.Path]::GetFullPath($developWorktreeValue)
                    $releaseWorktree = [IO.Path]::GetFullPath($releaseWorktreeValue)
                    $standRecord = [ordered]@{ projectRoot = $E2EProjectRoot; devBranchName = $developBranchName; worktreePath = $developWorktree; releaseWorktreePath = $releaseWorktree; commit = "" }
                    if ([string]::Equals($developWorktree.TrimEnd('\', '/'), $releaseWorktree.TrimEnd('\', '/'), [StringComparison]::OrdinalIgnoreCase)) {
                        Add-ReadinessIssue -Code "DEVELOP_E2E_ISOLATED_STAND_REQUIRED" -Category "STAND_STALE" `
                            -Message "Develop and Release worktree paths must differ: $developWorktree" `
                            -Recovery "Provision a separate disposable Develop E2E worktree."
                    } elseif (-not (Test-Path -LiteralPath $developWorktree -PathType Container)) {
                        Add-ReadinessIssue -Code "DEVELOP_E2E_ISOLATED_STAND_REQUIRED" -Category "STAND_STALE" `
                            -Message "Configured Develop worktree is missing: $developWorktree" `
                            -Recovery "Provision the configured disposable Develop E2E worktree."
                    } else {
                        $developBranch = Get-GitValue -Root $developWorktree -Arguments @("branch", "--show-current")
                        $standRecord.commit = Get-GitValue -Root $developWorktree -Arguments @("rev-parse", "HEAD")
                        if ($developBranch -cne "itldev/$developBranchName") {
                            Add-ReadinessIssue -Code "DEVELOP_E2E_ISOLATED_STAND_REQUIRED" -Category "STAND_STALE" `
                                -Message "Develop worktree branch is '$developBranch'; expected 'itldev/$developBranchName'." `
                                -Recovery "Point developWorktreePath at its configured disposable Develop branch."
                        }
                        try {
                            $masterCommonGitDirectory = Get-RepositoryCommonGitDirectory -RepositoryRoot $E2EProjectRoot
                            $developCommonGitDirectory = Get-RepositoryCommonGitDirectory -RepositoryRoot $developWorktree
                            if (-not [string]::Equals($masterCommonGitDirectory.TrimEnd('\', '/'), $developCommonGitDirectory.TrimEnd('\', '/'), [StringComparison]::OrdinalIgnoreCase)) {
                                throw "common Git directories differ: master='$masterCommonGitDirectory'; develop='$developCommonGitDirectory'"
                            }
                        } catch {
                            Add-ReadinessIssue -Code "DEVELOP_E2E_ISOLATED_STAND_REQUIRED" -Category "STAND_STALE" `
                                -Message "Develop path is not a registered worktree of the configured E2E project: $($_.Exception.Message)" `
                                -Recovery "Create the Develop branch with git worktree add from the E2E project repository."
                        }
                    }
                }
            } else {
            $devBranchName = [string]$standConfig.devBranchName
            $standWorktree = [System.IO.Path]::GetFullPath([string]$standConfig.worktreePath)
            $standRecord = [ordered]@{ projectRoot = $E2EProjectRoot; devBranchName = $devBranchName; worktreePath = $standWorktree; commit = ""; managedPackageSha256 = ""; unsafeActionProtectionConfirmed = $false; checkpoint = $null }
            $standBranch = Get-GitValue -Root $standWorktree -Arguments @('branch', '--show-current')
            $safeRunName = ($devBranchName -replace '[^A-Za-z0-9_.-]', '_')
            $checkpointExists = (Test-Path -LiteralPath (Join-Path $standWorktree ".agent-1c\runs\release-e2e\$safeRunName\checkpoint.json") -PathType Leaf) -or
                (Test-Path -LiteralPath (Join-Path $standWorktree ".agent-1c\release-e2e-runs\$safeRunName\checkpoint.json") -PathType Leaf)
            $masterBranch = 'master'
            $projectConfig = Get-JsonFile -Path (Join-Path $standWorktree '.agent-1c\project.json') -Code 'RELEASE_STAND_PROJECT_INVALID' -Label 'Release stand project config'
            if ($projectConfig -and $projectConfig.PSObject.Properties['masterBranch'] -and [string]$projectConfig.masterBranch) {
                $masterBranch = [string]$projectConfig.masterBranch
            }
            $masterIsAncestor = $false
            $previousErrorActionPreference = $ErrorActionPreference
            try {
                $ErrorActionPreference = 'Continue'
                & git -C $standWorktree merge-base --is-ancestor $masterBranch HEAD 2>$null
                if ($LASTEXITCODE -eq 0) { $masterIsAncestor = $true }
            } finally { $ErrorActionPreference = $previousErrorActionPreference }
            $standClean = @(& git -C $standWorktree status --porcelain --untracked-files=all).Count -eq 0
            $ownedWorktree = $false
            try {
                $ownedWorktree = [string]::Equals((Get-RepositoryCommonGitDirectory -RepositoryRoot $E2EProjectRoot),
                    (Get-RepositoryCommonGitDirectory -RepositoryRoot $standWorktree), [StringComparison]::OrdinalIgnoreCase)
            } catch {}
            $canRefreshStand = -not $checkpointExists -and -not $masterIsAncestor -and $standClean -and $ownedWorktree -and
                $standBranch -ceq "itldev/$devBranchName" -and $ResumeMode -eq 'Auto'
            Test-ManagedPackageAgreement -ExpectedInventory $managedInventory -TargetRoot $E2EProjectRoot -Label "E2E master"
            if ($ResumeMode -eq "Auto" -and -not $canRefreshStand) {
                Test-ManagedPackageAgreement -ExpectedInventory $managedInventory -TargetRoot $standWorktree -Label "E2E branch"
            }
            $standRecord.managedPackageSha256 = $managedInventorySha
            $standRecord.commit = Get-GitValue -Root $standWorktree -Arguments @("rev-parse", "HEAD")
            if ($standBranch -cne "itldev/$devBranchName") {
                Add-ReadinessIssue -Code "RELEASE_STAND_BRANCH_MISMATCH" -Category "STAND_STALE" -Message "Configured E2E worktree branch is '$standBranch'; expected='itldev/$devBranchName'." -Recovery "Point release-e2e.json at the exact disposable Release branch."
            }
            if (-not $ownedWorktree) {
                Add-ReadinessIssue -Code "RELEASE_STAND_WORKTREE_FOREIGN" -Category "STAND_STALE" `
                    -Message "Configured E2E worktree is not registered in the configured E2E project's Git repository: $standWorktree" `
                    -Recovery "Point release-e2e.json at an owned disposable Release worktree."
            }
            if (-not $standClean) {
                Add-ReadinessIssue -Code "RELEASE_STAND_DIRTY" -Category "STAND_STALE" -Message "Configured E2E worktree has tracked or untracked changes." -Recovery "Use a clean disposable Release branch."
            }
            foreach ($lockRoot in @($E2EProjectRoot, $standWorktree)) {
                $lockPath = Join-Path $lockRoot ".agent-1c\dependency-lock.json"
                $installedLock = Get-JsonFile -Path $lockPath -Code "RELEASE_STAND_LOCK_INVALID" -Label "Installed workflow dependency lock"
                $restartWillRefreshBranch = $ResumeMode -eq "Restart" -and [string]::Equals(
                    [System.IO.Path]::GetFullPath($lockRoot).TrimEnd('\', '/'),
                    $standWorktree.TrimEnd('\', '/'),
                    [StringComparison]::OrdinalIgnoreCase)
                if ($null -ne $installedLock -and -not $restartWillRefreshBranch -and -not ($canRefreshStand -and $lockRoot -eq $standWorktree)) {
                    Test-LockAgreement -Expected $vanessaLock -Actual $installedLock.dependencies.vanessaAutomation -Label $lockRoot
                    $installedWorkflowCommit = [string]$installedLock.dependencies.workflowPackage.commit
                    if ($installedWorkflowCommit -cne $commit) {
                        $standContinuation = Get-WorkflowContinuationProof -RepositoryRoot $RepositoryRoot -QualifiedCommit $installedWorkflowCommit -CurrentCommit $commit -CurrentTree $tree
                        if (-not $standContinuation -or @($standContinuation.scopes) -contains "develop") {
                            Add-ReadinessIssue -Code "RELEASE_STAND_WORKFLOW_COMMIT_DRIFT" -Category "STAND_STALE" `
                                -Message "$lockRoot is installed from workflow commit '$installedWorkflowCommit'; candidate='$commit'." `
                                -Recovery "Run update-workflow from the exact candidate, commit the managed update, and create or refresh the disposable Release branch."
                        }
                    }
                }
            }
            $statePath = Join-Path $standWorktree (".agent-1c\dev-branches\" + $devBranchName + ".json")
            $state = Get-JsonFile -Path $statePath -Code "RELEASE_STAND_STATE_INVALID" -Label "Release branch state"
            if ($null -ne $state) {
                $confirmedProperty = $state.PSObject.Properties["unsafeActionProtectionConfirmed"]
                $confirmed = $null -ne $confirmedProperty -and $confirmedProperty.Value -is [bool] -and [bool]$confirmedProperty.Value
                $standRecord.unsafeActionProtectionConfirmed = $confirmed
                if (-not $confirmed) {
                    Add-ReadinessIssue -Code "RELEASE_STAND_UNSAFE_ACTION_PROTECTION_UNCONFIRMED" -Category "STAND_STALE" `
                        -Message "Release branch unsafe-action protection confirmation is absent." `
                        -Recovery "Run the monitored configure-dev-branch-unsafe-action-protection action in the configured E2E worktree."
                }
            }
            $actualAiRulesCommit = if ($AiRulesSource -and (Test-Path -LiteralPath $AiRulesSource -PathType Container)) { Get-GitValue -Root $AiRulesSource -Arguments @("rev-parse", "HEAD") } else { "" }
            $actualAiRulesTree = if ($actualAiRulesCommit) { Get-GitValue -Root $AiRulesSource -Arguments @('rev-parse', 'HEAD^{tree}') } else { '' }
            $standRecord.checkpoint = Test-ReleaseCheckpointPreflight -StandProjectRoot $E2EProjectRoot -StandWorktree $standWorktree -DevBranchName $devBranchName -CandidateCommit $commit -CandidateTree $tree -AiRulesCommit $actualAiRulesCommit -AiRulesTree $actualAiRulesTree
            $markerPath = Join-Path $standWorktree 'tests\features\workflow-release-e2e.feature'
            $masterMarkerPath = Join-Path $E2EProjectRoot 'tests\features\workflow-release-e2e.feature'
            if (-not (Test-Path -LiteralPath $markerPath -PathType Leaf) -and
                -not ($canRefreshStand -and (Test-Path -LiteralPath $masterMarkerPath -PathType Leaf))) {
                Add-ReadinessIssue -Code 'RELEASE_STAND_MARKER_MISSING' -Category 'STAND_STALE' `
                    -Message "Release fixture marker is missing from the branch and cannot be supplied by a safe refresh: $markerPath" `
                    -Recovery 'Rebuild the owned disposable Release branch from a fixture containing workflow-release-e2e.feature.'
            }
            }
        }
    }
}

$contextStatus = if ($issues.Count -eq 0) { "passed" } else { "failed" }
[object[]]$issueArray = @()
if ($issues.Count -gt 0) { $issueArray = $issues.ToArray() }
$context = [ordered]@{
    schemaVersion = 1
    kind = "itl-release-context"
    status = $contextStatus
    mode = $Mode
    startedAt = $startedAt.ToString("o")
    finishedAt = [DateTime]::UtcNow.ToString("o")
    repository = [ordered]@{ root = $RepositoryRoot; branch = $branch; commit = $commit; tree = $tree; worktreeClean = $worktreeClean }
    fork = $forkRecord
    artifacts = [ordered]@{ vanessaAutomation = $archive }
    managedPackage = [ordered]@{ sha256 = $managedInventorySha; fileCount = $managedInventory.Count }
    stand = $standRecord
    encoding = [ordered]@{
        powershellVersion = [string]$PSVersionTable.PSVersion
        powershellEdition = [string]$PSVersionTable.PSEdition
        consoleOutputEncoding = [Console]::OutputEncoding.WebName
        changedPowerShellFiles = $changedPowerShell
        contract = "windows-powershell-5.1-default-decode-plus-strict-utf8-and-ast"
    }
    issues = $issueArray
}

New-Item -ItemType Directory -Force -Path (Split-Path -Parent $OutputPath) | Out-Null
[System.IO.File]::WriteAllText($OutputPath, (($context | ConvertTo-Json -Depth 12) + [Environment]::NewLine), [System.Text.UTF8Encoding]::new($false))
if ($issues.Count -gt 0) {
    foreach ($issue in $issues) { [Console]::Error.WriteLine("$($issue.code) [$($issue.category)]: $($issue.message) Recovery: $($issue.recovery)") }
    exit 1
}
Write-Host "ITL release readiness passed. Context: $OutputPath"
