﻿[CmdletBinding()]
param(
    [string]$OutputDirectory = "",
    [string]$PlatformBin = "C:\Program Files\1cv8\8.3.27.2130\bin",
    [string]$WorkRoot = "C:\itlvabld",
    [ValidateSet("1.2.043.28", "1.2.043.42")][string]$UpstreamVersion = "1.2.043.28",
    [ValidateSet("itl-r1", "itl-r2", "itl-r3", "itl-r4", "itl-r5", "itl-r6", "itl-r7", "itl-r8", "itl-r9", "itl-r10", "itl-r11", "itl-r12", "itl-r13", "itl-r14")][string]$DownstreamRevision = "itl-r8",
    [string]$ResumeWorkDirectory = "",
    [switch]$KeepWork,
    [switch]$Force
)

$ErrorActionPreference = "Stop"
Set-StrictMode -Version 2.0
[Console]::OutputEncoding = [Text.UTF8Encoding]::new($false)
$OutputEncoding = [Text.UTF8Encoding]::new($false)

function Get-Sha256 {
    param([Parameter(Mandatory = $true)][string]$Path)
    return (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()
}

function Get-VanessaResumeDiffArguments {
    param([Parameter(Mandatory = $true)][object]$Manifest)

    # Existing immutable recipes retain their original Git diff format. New
    # recipes pin full indexes so repository growth cannot change resume proof.
    $format = if ($Manifest.patch.PSObject.Properties['gitDiffFormat']) { [string]$Manifest.patch.gitDiffFormat } else { 'legacy' }
    switch ($format) {
        'legacy' { return @('--binary') }
        'full-index' { return @('--binary', '--full-index') }
        default { throw "VANESSA_BUILD_PATCH_DIFF_FORMAT_UNSUPPORTED: $format. Use the format declared by the exact source-controlled component recipe." }
    }
}

function New-DeterministicZip {
    param(
        [Parameter(Mandatory = $true)][string]$SourceDirectory,
        [Parameter(Mandatory = $true)][string]$DestinationPath
    )

    Add-Type -AssemblyName System.IO.Compression
    Add-Type -AssemblyName System.IO.Compression.FileSystem

    $sourceFull = [System.IO.Path]::GetFullPath($SourceDirectory).TrimEnd("\")
    $relativePaths = [string[]]@(
        Get-ChildItem -LiteralPath $sourceFull -Recurse -File |
            ForEach-Object { $_.FullName.Substring($sourceFull.Length).TrimStart("\") }
    )
    [Array]::Sort($relativePaths, [System.StringComparer]::Ordinal)

    $destinationStream = [System.IO.File]::Open(
        $DestinationPath,
        [System.IO.FileMode]::CreateNew,
        [System.IO.FileAccess]::Write,
        [System.IO.FileShare]::None
    )
    try {
        $archive = [System.IO.Compression.ZipArchive]::new(
            $destinationStream,
            [System.IO.Compression.ZipArchiveMode]::Create,
            $false,
            [System.Text.Encoding]::UTF8
        )
        try {
            $fixedTimestamp = [System.DateTimeOffset]::new(
                2000, 1, 1, 0, 0, 0, [System.TimeSpan]::Zero
            )
            foreach ($relativePath in $relativePaths) {
                $entryName = $relativePath.Replace("\", "/")
                $entry = $archive.CreateEntry(
                    $entryName,
                    [System.IO.Compression.CompressionLevel]::Optimal
                )
                $entry.LastWriteTime = $fixedTimestamp
                $entry.ExternalAttributes = 0

                $inputStream = [System.IO.File]::OpenRead(
                    (Join-Path $sourceFull $relativePath)
                )
                try {
                    $outputStream = $entry.Open()
                    try {
                        $inputStream.CopyTo($outputStream)
                    } finally {
                        $outputStream.Dispose()
                    }
                } finally {
                    $inputStream.Dispose()
                }
            }
        } finally {
            $archive.Dispose()
        }
    } finally {
        $destinationStream.Dispose()
    }
}

function Assert-Equal {
    param(
        [Parameter(Mandatory = $true)][string]$Actual,
        [Parameter(Mandatory = $true)][string]$Expected,
        [Parameter(Mandatory = $true)][string]$Subject
    )
    if ($Actual -ne $Expected) {
        throw "$Subject mismatch. Expected '$Expected', actual '$Actual'."
    }
}

function Invoke-Native {
    param(
        [Parameter(Mandatory = $true)][string]$FilePath,
        [Parameter(Mandatory = $true)][string[]]$Arguments,
        [Parameter(Mandatory = $true)][string]$Description
    )
    & $FilePath @Arguments
    if ($LASTEXITCODE -ne 0) {
        throw "$Description failed with exit code $LASTEXITCODE."
    }
}

function Test-PathInside {
    param(
        [Parameter(Mandatory = $true)][string]$Candidate,
        [Parameter(Mandatory = $true)][string]$Parent
    )
    $candidateFull = [System.IO.Path]::GetFullPath($Candidate).TrimEnd("\")
    $parentFull = [System.IO.Path]::GetFullPath($Parent).TrimEnd("\")
    return $candidateFull.StartsWith($parentFull + "\", [System.StringComparison]::OrdinalIgnoreCase)
}

$repoRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot ".."))
$assetVersion = "$UpstreamVersion-$DownstreamRevision"
$assetRoot = Join-Path $repoRoot ("third-party\vanessa-automation\" + $assetVersion)
$manifestPath = Join-Path $assetRoot "manifest.json"
$patchPath = Join-Path $assetRoot "file-operations.patch"
$noticePath = Join-Path $assetRoot "ITL-NOTICE.txt"
$licenseNoticePath = Join-Path $assetRoot "LICENSE.upstream"

if (-not $OutputDirectory) {
    $OutputDirectory = Join-Path $repoRoot ("build\third-party\vanessa-automation\" + $assetVersion)
}
$OutputDirectory = [System.IO.Path]::GetFullPath($OutputDirectory)
$WorkRoot = [System.IO.Path]::GetFullPath($WorkRoot)

foreach ($requiredPath in @($manifestPath, $patchPath, $noticePath, $licenseNoticePath)) {
    if (-not (Test-Path -LiteralPath $requiredPath -PathType Leaf)) {
        throw "Required controlled asset is missing: $requiredPath"
    }
}

$manifest = Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
Assert-Equal ([string]$manifest.downstreamRevision) $DownstreamRevision "Manifest downstream revision"
Assert-Equal ([string]$manifest.compatibilityVersion) $UpstreamVersion "Manifest upstream compatibility version"
$artifactPath = Join-Path $OutputDirectory ([string]$manifest.artifact.fileName)
$provenancePath = Join-Path $OutputDirectory "candidate.provenance.json"
if ((Test-Path -LiteralPath $artifactPath) -and -not $Force) {
    throw "Candidate already exists: $artifactPath. Use -Force to replace it."
}

Assert-Equal (Get-Sha256 -Path $patchPath) ([string]$manifest.patch.sha256) "Patch SHA-256"

$gitVersion = (& git --version) -replace "^git version\s+", ""
if ($LASTEXITCODE -ne 0) { throw "git --version failed." }
Assert-Equal $gitVersion ([string]$manifest.build.gitVersion) "Git version"

$oscriptCommand = Get-Command oscript.exe -ErrorAction Stop
$opmCommand = Get-Command opm.bat -ErrorAction Stop
$oscriptVersion = (& $oscriptCommand.Source -version).Trim()
if ($LASTEXITCODE -ne 0) { throw "oscript -version failed." }
$oneScriptLibrary = [System.IO.Path]::GetFullPath((Join-Path (Split-Path -Parent $opmCommand.Source) '..\lib'))
$opmVersionSource = Join-Path $oneScriptLibrary 'opm\src\core\Модули\КонстантыOpm.os'
if (-not (Test-Path -LiteralPath $opmVersionSource -PathType Leaf)) { throw "Installed opm version source is missing: $opmVersionSource" }
$opmVersionMatches = [regex]::Matches((Get-Content -LiteralPath $opmVersionSource -Raw -Encoding UTF8), '(?m)^ВерсияПродукта\s*=\s*"([^"]+)";')
if ($opmVersionMatches.Count -ne 1) { throw "Installed opm version is ambiguous: $opmVersionSource" }
$opmVersion = $opmVersionMatches[0].Groups[1].Value
Assert-Equal $oscriptVersion ([string]$manifest.build.oneScript.version) "OneScript version"
Assert-Equal $opmVersion ([string]$manifest.build.oneScript.opmVersion) "OPM version"

foreach ($property in $manifest.build.oneScript.packages.PSObject.Properties) {
    # opm list queries the remote package hub even for local packages. Read the
    # installed package metadata used by this OneScript runtime instead.
    $packageMetadataPath = Join-Path (Join-Path $oneScriptLibrary $property.Name) 'opm-metadata.xml'
    if (-not (Test-Path -LiteralPath $packageMetadataPath -PathType Leaf)) {
        throw "Required OneScript package is absent or has the wrong version: $($property.Name) $($property.Value)."
    }
    [xml]$packageMetadata = Get-Content -LiteralPath $packageMetadataPath -Raw -Encoding UTF8
    if ([string]$packageMetadata.'opm-metadata'.name -cne [string]$property.Name -or
        [string]$packageMetadata.'opm-metadata'.version -cne [string]$property.Value) {
        throw "Required OneScript package is absent or has the wrong version: $($property.Name) $($property.Value)."
    }
}

$platformExe = Join-Path $PlatformBin "1cv8.exe"
if (-not (Test-Path -LiteralPath $platformExe -PathType Leaf)) {
    throw "1C:Enterprise executable was not found: $platformExe"
}
$platformVersion = (Get-Item -LiteralPath $platformExe).VersionInfo.FileVersion
Assert-Equal $platformVersion ([string]$manifest.build.platform.version) "1C:Enterprise platform version"

# Both execution copies explicitly select this manifest-validated executable.
# Other installed platform versions do not determine the build toolchain.

$workDirectory = $(if ($ResumeWorkDirectory) {
    [System.IO.Path]::GetFullPath($ResumeWorkDirectory)
} else {
    Join-Path $WorkRoot ([Guid]::NewGuid().ToString("N").Substring(0, 8))
})
if (-not (Test-PathInside -Candidate $workDirectory -Parent $WorkRoot)) {
    throw "Unsafe work directory: $workDirectory"
}
if ($workDirectory.Length -gt 40) {
    throw "Work directory is too long for upstream MakeVASingle.os: $workDirectory"
}

$sourceDirectory = Join-Path $workDirectory "src"
$singleBuildDirectory = Join-Path $workDirectory "out"
$stageDirectory = Join-Path $workDirectory "stage"
$sourceArchivePath = Join-Path $workDirectory "source.tar"
$nativeRuntimeInvoked = $false
$nativeRuntimeResultPath = Join-Path $workDirectory 'native-runtime-result.json'

if ($ResumeWorkDirectory) {
    if (-not (Test-Path -LiteralPath $workDirectory -PathType Container)) {
        throw "VANESSA_BUILD_RESUME_WORK_DIRECTORY_MISSING: $workDirectory"
    }
    if (Test-Path -LiteralPath $stageDirectory) {
        throw "VANESSA_BUILD_RESUME_STAGE_ALREADY_EXISTS: $stageDirectory"
    }
    if (-not (Test-Path -LiteralPath $nativeRuntimeResultPath -PathType Leaf)) {
        throw "VANESSA_BUILD_RESUME_RESULT_MISSING: $nativeRuntimeResultPath"
    }
    $previousNativeResult = Get-Content -LiteralPath $nativeRuntimeResultPath -Raw -Encoding UTF8 | ConvertFrom-Json
    if (-not [bool]$previousNativeResult.released) {
        throw "VANESSA_BUILD_RESUME_NATIVE_OWNERSHIP_UNCONFIRMED: $nativeRuntimeResultPath"
    }
} else {
    New-Item -ItemType Directory -Path $workDirectory | Out-Null
}
try {
    if (-not $ResumeWorkDirectory) {
    Invoke-Native -FilePath "git" -Arguments @(
        "clone", "--filter=blob:none", "--no-checkout",
        [string]$manifest.upstream.repository, $sourceDirectory
    ) -Description "Clone upstream Vanessa Automation"

    $tagCommit = (& git -C $sourceDirectory rev-parse "$($manifest.upstream.ref)^{commit}").Trim()
    if ($LASTEXITCODE -ne 0) { throw "Could not resolve the pinned upstream tag." }
    Assert-Equal $tagCommit ([string]$manifest.upstream.commit) "Upstream tag commit"

    Invoke-Native -FilePath "git" -Arguments @(
        "-C", $sourceDirectory, "checkout", "--detach", [string]$manifest.upstream.commit
    ) -Description "Checkout pinned upstream commit"

    $headCommit = (& git -C $sourceDirectory rev-parse HEAD).Trim()
    $headTree = (& git -C $sourceDirectory rev-parse "HEAD^{tree}").Trim()
    Assert-Equal $headCommit ([string]$manifest.upstream.commit) "Upstream HEAD"
    Assert-Equal $headTree ([string]$manifest.upstream.tree) "Upstream tree"

    Invoke-Native -FilePath "git" -Arguments @(
        "-C", $sourceDirectory, "archive", "--format=tar",
        "--output=$sourceArchivePath", [string]$manifest.upstream.commit
    ) -Description "Create canonical upstream source archive"
    Assert-Equal (Get-Sha256 -Path $sourceArchivePath) ([string]$manifest.upstream.sourceArchive.sha256) "Upstream source archive SHA-256"

    foreach ($flowFile in $manifest.build.upstreamFlow) {
        $flowPath = Join-Path $sourceDirectory ([string]$flowFile.path).Replace("/", "\")
        Assert-Equal (Get-Sha256 -Path $flowPath) ([string]$flowFile.sha256) "Upstream build file $($flowFile.path)"
    }

    Invoke-Native -FilePath "git" -Arguments @(
        "-C", $sourceDirectory, "apply", "--check", "--whitespace=error-all", $patchPath
    ) -Description "Check downstream patch"
    Invoke-Native -FilePath "git" -Arguments @(
        "-C", $sourceDirectory, "apply", "--whitespace=error-all", $patchPath
    ) -Description "Apply downstream patch"
    } else {
        if (-not (Test-Path -LiteralPath (Join-Path $sourceDirectory '.git') -PathType Container)) {
            throw "VANESSA_BUILD_RESUME_SOURCE_MISSING: $sourceDirectory"
        }
        $tagCommit = (& git -C $sourceDirectory rev-parse "$($manifest.upstream.ref)^{commit}").Trim()
        if ($LASTEXITCODE -ne 0) { throw "Could not resolve the pinned upstream tag in resumed source." }
        Assert-Equal $tagCommit ([string]$manifest.upstream.commit) "Resumed upstream tag commit"
        $headCommit = (& git -C $sourceDirectory rev-parse HEAD).Trim()
        $headTree = (& git -C $sourceDirectory rev-parse "HEAD^{tree}").Trim()
        Assert-Equal $headCommit ([string]$manifest.upstream.commit) "Resumed upstream HEAD"
        Assert-Equal $headTree ([string]$manifest.upstream.tree) "Resumed upstream tree"
        Assert-Equal (Get-Sha256 -Path $sourceArchivePath) ([string]$manifest.upstream.sourceArchive.sha256) "Resumed upstream source archive SHA-256"
        foreach ($flowFile in $manifest.build.upstreamFlow) {
            $flowPath = Join-Path $sourceDirectory ([string]$flowFile.path).Replace("/", "\")
            Assert-Equal (Get-Sha256 -Path $flowPath) ([string]$flowFile.sha256) "Resumed upstream build file $($flowFile.path)"
        }
        $resumeDiffPath = Join-Path $workDirectory 'resume-diff.patch'
        try {
            Invoke-Native -FilePath "git" -Arguments (@(
                "-C", $sourceDirectory, "-c", "core.quotepath=false", "diff"
            ) + @(Get-VanessaResumeDiffArguments -Manifest $manifest) + @("HEAD", "--output=$resumeDiffPath")) -Description "Compare resumed source with pinned patch"
            Assert-Equal (Get-Sha256 -Path $resumeDiffPath) ([string]$manifest.patch.sha256) "Resumed downstream patch"
        } finally {
            Remove-Item -LiteralPath $resumeDiffPath -Force -ErrorAction SilentlyContinue
        }
    }
    Invoke-Native -FilePath "git" -Arguments @(
        "-C", $sourceDirectory, "diff", "--check"
    ) -Description "Check patched source whitespace"

    $sourcePathLists = & {
        param($SourceRoot, $HelperPath)
        . $HelperPath -ProjectRoot $SourceRoot -Action help *> $null
        [pscustomobject]@{
            changed = @(Get-GitPathList -Arguments @('diff', '--name-only', '-z'))
            untracked = @(Get-GitPathList -Arguments @('ls-files', '--others', '--exclude-standard', '-z'))
        }
    } $sourceDirectory (Join-Path $repoRoot '.agents/skills/1c-workflow/scripts/agent-1c.ps1')
    $changedPaths = @($sourcePathLists.changed)
    $expectedChangedPaths = @($manifest.patch.expectedChangedPaths)
    if (($changedPaths -join "`n") -ne ($expectedChangedPaths -join "`n")) {
        throw "Patch changed an unexpected path set. Expected '$($expectedChangedPaths -join ", ")'; actual '$($changedPaths -join ", ")'."
    }
    if ($ResumeWorkDirectory -and @($sourcePathLists.untracked).Count -gt 0) {
        throw "VANESSA_BUILD_RESUME_UNTRACKED_SOURCE: $($sourcePathLists.untracked -join ', ')"
    }

    Push-Location $sourceDirectory
    try {
        if (-not $ResumeWorkDirectory) {
            Invoke-Native -FilePath $oscriptCommand.Source -Arguments @(
                (Join-Path $sourceDirectory "lib\packages.os"), "download"
            ) -Description "Download upstream pinned packages"
        }

        foreach ($dependency in $manifest.build.upstreamBundledDependencies) {
            $dependencyPath = Join-Path $sourceDirectory ([string]$dependency.path).Replace("/", "\")
            Assert-Equal (Get-Sha256 -Path $dependencyPath) ([string]$dependency.sha256) "Bundled dependency $($dependency.name)"
        }

        Invoke-Native -FilePath $oscriptCommand.Source -Arguments @(
            (Join-Path $sourceDirectory "tools\onescript\ZipTemplates.os")
        ) -Description "Build upstream templates"
    } finally {
        Pop-Location
    }

    $nativeRuntimeRequestPath = Join-Path $workDirectory 'native-runtime-request.json'
    $nativeRuntimeRequest = @{ workRoot = $workDirectory; platformExe = $platformExe; oscriptExe = $oscriptCommand.Source; manifestPath = $manifestPath }
    [IO.File]::WriteAllText($nativeRuntimeRequestPath, ($nativeRuntimeRequest | ConvertTo-Json), [Text.UTF8Encoding]::new($false))
    $nativeRuntimeInvoked = $true
    Invoke-Native -FilePath ([Diagnostics.Process]::GetCurrentProcess().MainModule.FileName) -Arguments @(
        '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', (Join-Path $repoRoot 'scripts/run-vanessa-build-runtime.ps1'),
        '-RequestPath', $nativeRuntimeRequestPath
    ) -Description 'Run guarded upstream Compile.os and MakeVASingle.os with the qualified service template'
    $nativeRuntimeResult = Get-Content -LiteralPath $nativeRuntimeResultPath -Raw -Encoding UTF8 | ConvertFrom-Json
    if (-not $nativeRuntimeResult.succeeded -or -not $nativeRuntimeResult.released) { throw 'VANESSA_BUILD_RUNTIME_NOT_QUALIFIED' }

    $distributionDirectory = Join-Path $singleBuildDirectory "Temp\DistribVanessaAutomationsingle"
    $epfPath = Join-Path $distributionDirectory ([string]$manifest.artifact.entryPoint)
    $upstreamLicensePath = Join-Path $distributionDirectory "LICENSE"
    if (-not (Test-Path -LiteralPath $epfPath -PathType Leaf)) {
        throw "Upstream single EPF was not produced: $epfPath"
    }
    Assert-Equal (Get-Sha256 -Path $upstreamLicensePath) ([string]$manifest.license.upstreamSha256) "Artifact upstream license"

    Copy-Item -LiteralPath $distributionDirectory -Destination $stageDirectory -Recurse
    Copy-Item -LiteralPath $noticePath -Destination (Join-Path $stageDirectory "ITL-NOTICE.txt")
    Copy-Item -LiteralPath $manifestPath -Destination (Join-Path $stageDirectory "ITL-PROVENANCE.json")
    if ($manifest.PSObject.Properties['pairedExtension'] -and $manifest.pairedExtension.required) {
        if (-not $nativeRuntimeResult.PSObject.Properties['pairedExtension']) { throw 'VANESSA_BUILD_PAIRED_EXTENSION_MISSING' }
        $pairedExtension = $nativeRuntimeResult.pairedExtension
        Assert-Equal (Get-Sha256 -Path $pairedExtension.path) ([string]$pairedExtension.sha256) 'Paired extension SHA-256'
        Copy-Item -LiteralPath $pairedExtension.path -Destination (Join-Path $stageDirectory $manifest.pairedExtension.fileName)
    }

    New-Item -ItemType Directory -Path $OutputDirectory -Force | Out-Null
    if (Test-Path -LiteralPath $artifactPath) {
        if (-not $Force) { throw "Refusing to replace existing candidate: $artifactPath" }
        Remove-Item -LiteralPath $artifactPath -Force
    }

    New-DeterministicZip -SourceDirectory $stageDirectory -DestinationPath $artifactPath

    $candidateProvenance = [ordered]@{
        schemaVersion = 1
        artifactPath = $artifactPath
        artifactSha256 = (Get-Sha256 -Path $artifactPath)
        artifactSize = (Get-Item -LiteralPath $artifactPath).Length
        epfSha256 = (Get-Sha256 -Path (Join-Path $stageDirectory ([string]$manifest.artifact.entryPoint)))
        epfSize = (Get-Item -LiteralPath (Join-Path $stageDirectory ([string]$manifest.artifact.entryPoint))).Length
        manifestSha256 = (Get-Sha256 -Path $manifestPath)
        patchSha256 = (Get-Sha256 -Path $patchPath)
        upstreamCommit = [string]$manifest.upstream.commit
        compatibilityVersion = [string]$manifest.compatibilityVersion
        downstreamRevision = [string]$manifest.downstreamRevision
        platformVersion = $platformVersion
        oneScriptVersion = $oscriptVersion
        opmVersion = $opmVersion
        nativeRuntime = $nativeRuntimeResult
        builtAtUtc = (Get-Date).ToUniversalTime().ToString("o")
    }
    $candidateProvenanceJson = $candidateProvenance | ConvertTo-Json -Depth 8
    [System.IO.File]::WriteAllText($provenancePath, $candidateProvenanceJson + [Environment]::NewLine, [System.Text.UTF8Encoding]::new($false))

    Write-Host "Candidate: $artifactPath"
    Write-Host "SHA256: $($candidateProvenance.artifactSha256)"
    Write-Host "Provenance: $provenancePath"
} finally {
    $nativeCleanupConfirmed = -not $nativeRuntimeInvoked
    if ($nativeRuntimeInvoked -and (Test-Path -LiteralPath $nativeRuntimeResultPath -PathType Leaf)) {
        try { $nativeCleanupConfirmed = [bool](Get-Content -LiteralPath $nativeRuntimeResultPath -Raw -Encoding UTF8 | ConvertFrom-Json).released } catch { $nativeCleanupConfirmed = $false }
    }
    if ($KeepWork -or -not $nativeCleanupConfirmed) {
        Write-Host "Build work directory retained: $workDirectory"
    } elseif (Test-Path -LiteralPath $workDirectory) {
        if (-not (Test-PathInside -Candidate $workDirectory -Parent $WorkRoot)) {
            throw "Refusing to remove unsafe work directory: $workDirectory"
        }
        Remove-Item -LiteralPath $workDirectory -Recurse -Force
    }
}
