﻿function New-VanessaBuildExecutionCopy {
    param(
        [string]$SourcePath, [string]$DestinationPath, [string]$ExpectedSha256,
        [switch]$SingleBuild
    )
    $actual = (Get-FileHash -LiteralPath $SourcePath -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($actual -cne $ExpectedSha256) { throw 'VANESSA_BUILD_UPSTREAM_FLOW_HASH_MISMATCH' }
    $text = [IO.File]::ReadAllText($SourcePath, [Text.Encoding]::UTF8)
    $changes = @(
        ,@('КаталогБазы = ПолучитьИмяВременногоФайла();', ('УправлениеКонфигуратором.ПутьКПлатформе1С(ПолучитьПеременнуюСреды("PLATFORM_PATH"));' + [Environment]::NewLine + 'КаталогБазы = ПолучитьПеременнуюСреды("ITL_VANESSA_BUILD_SCRATCH_BASE");'))
    )
    if ($SingleBuild) {
        $changes += ,@(' Enterprise /F""" + КаталогБазы', ' Enterprise /N""" + ПолучитьПеременнуюСреды("ITL_VANESSA_BUILD_USER") + """ /F""" + КаталогБазы')
        $changes += ,@('ЗапуститьПриложение(СтрокаКоманды, , Ложь, retCode);', 'retCode = 0; // ITL: no directory window during a noninteractive build.')
        $cacheRead = 'Стр = Текст.Прочитать();'
        $cacheCheck = $cacheRead + [Environment]::NewLine + 'Если Найти(Стр, "ЯЗапускаюМониторингКаталогаДляВнешнихСобытийРасширение") = 0 Тогда ВызватьИсключение "VANESSA_BUILD_VAEXTENSION_STEPS_MISSING"; КонецЕсли;'
        $changes += ,@($cacheRead, $cacheCheck)
    }
    foreach ($change in $changes) {
        if ([regex]::Matches($text, [regex]::Escape($change[0])).Count -ne 1) {
            throw "VANESSA_BUILD_EXECUTION_ADAPTER_MISMATCH: $SourcePath"
        }
        $text = $text.Replace($change[0], $change[1])
    }
    [void][IO.Directory]::CreateDirectory((Split-Path -Parent $DestinationPath))
    [IO.File]::WriteAllText($DestinationPath, $text, [Text.UTF8Encoding]::new($true))
    return [pscustomobject]@{
        sourcePath = $SourcePath; sourceSha256 = $actual; executionPath = $DestinationPath
        executionSha256 = (Get-FileHash -LiteralPath $DestinationPath -Algorithm SHA256).Hash.ToLowerInvariant()
    }
}

function Invoke-VanessaBuildPairedExtension {
    param([string]$SourceRoot, [string]$WorkRoot, [string]$InfoBasePath, [string]$User, [object]$Specification)
    if ($Specification.sourcePath -cne 'lib/VAExtension' -or
        $Specification.fileName -cnotmatch '^VAExtension\.[0-9]+\.[0-9]+-itl-r[0-9]+\.cfe$' -or
        $Specification.protocol -cne 'itl-file-code-v1') { throw 'VANESSA_BUILD_PAIRED_EXTENSION_CONTRACT_INVALID' }
    $extensionSource = Join-Path $SourceRoot 'lib/VAExtension'
    $metadataPath = Join-Path $extensionSource 'Configuration.xml'
    if (-not (Test-Path -LiteralPath $metadataPath -PathType Leaf)) { throw 'VANESSA_BUILD_PAIRED_EXTENSION_METADATA_MISSING' }
    [xml]$metadata = [IO.File]::ReadAllText($metadataPath, [Text.Encoding]::UTF8)
    $versionNode = $metadata.SelectSingleNode("/*[local-name()='MetaDataObject']/*[local-name()='Configuration']/*[local-name()='Properties']/*[local-name()='Version']")
    $version = if ($null -ne $versionNode) { [string]$versionNode.InnerText } else { '' }
    if ($version -cnotmatch '^[0-9]+\.[0-9]+$' -or
        $Specification.fileName -cnotmatch ('^VAExtension\.' + [regex]::Escape($version) + '-itl-r[0-9]+\.cfe$')) {
        throw 'VANESSA_BUILD_PAIRED_EXTENSION_VERSION_MISMATCH'
    }
    $outputPath = Join-Path $WorkRoot $Specification.fileName
    Invoke-Designer -InfoBaseKind file -InfoBasePath $InfoBasePath -User $User -Password '' `
        -DesignerArgs @('/LoadConfigFromFiles', $extensionSource, '-Extension', 'VAExtension', '-Format', 'Hierarchical', '/UpdateDBCfg') | Out-Null
    Invoke-Designer -InfoBaseKind file -InfoBasePath $InfoBasePath -User $User -Password '' `
        -DesignerArgs @('/DumpCfg', $outputPath, '-Extension', 'VAExtension') | Out-Null
    if (-not (Test-Path -LiteralPath $outputPath -PathType Leaf) -or (Get-Item -LiteralPath $outputPath).Length -eq 0) {
        throw 'VANESSA_BUILD_PAIRED_EXTENSION_NOT_PRODUCED'
    }
    return [pscustomobject]@{
        path = $outputPath; sha256 = (Get-FileHash -LiteralPath $outputPath -Algorithm SHA256).Hash.ToLowerInvariant()
        protocol = $Specification.protocol
    }
}

function Get-VanessaBuildDatabasePlan {
    param([Parameter(Mandatory = $true)][string]$WorkRoot)
    $root = [IO.Path]::GetFullPath($WorkRoot)
    @('scratch-compile', 'scratch-single', 'base') | ForEach-Object {
        [pscustomobject]@{ kind = 'file'; path = (Join-Path $root $_) }
    }
}

function Invoke-VanessaBuildOwnedNative {
    param(
        [string]$FilePath, [string[]]$Arguments, [object[]]$Bases,
        [string]$Purpose, [switch]$CreateInfoBase,
        [int]$TimeoutSeconds = 3600,
        [int]$PostExitProbeSeconds = 60,
        [string]$RunParamsPath = ''
    )
    if (@($Bases).Count -eq 0) { throw 'VANESSA_BUILD_NATIVE_RESOURCES_REQUIRED' }
    if (@($Arguments | Where-Object { $_ -ieq '/TESTMANAGER' }).Count -gt 0 -and -not $RunParamsPath) { throw 'VANESSA_BUILD_NATIVE_RUN_SCOPE_REQUIRED' }
    $scopes = @(if ($RunParamsPath) { Get-OneCNativeRunProcessScopes -RunParamsPath $RunParamsPath -Resources $Bases })
    $probe = New-DesignerInvocationProbeState -LauncherProcessId 0 -OwnedProcessScopes $scopes
    $evidence = [pscustomobject]@{ record = $null }
    $result = $null
    $released = $false
    $additional = @($Bases | Select-Object -Skip 1 | ForEach-Object {
        [pscustomobject]@{ infoBaseKind = 'file'; infoBasePath = $_.path; requiredSessions = 1; expectedChildRole = ''; purpose = $Purpose }
    })
    $outputRoot = [IO.Path]::GetDirectoryName([IO.Path]::GetFullPath([string]$Bases[0].path))
    $stdoutPath = Join-Path $outputRoot ($Purpose + '.stdout.log')
    $stderrPath = Join-Path $outputRoot ($Purpose + '.stderr.log')
    try {
        $result = Invoke-WithOneCSessionAdmissionContext -InfoBaseKind file -InfoBasePath $Bases[0].path `
            -RequiredSessions 1 -Purpose $Purpose -AdditionalAdmissions $additional `
            -SessionWaitTimeoutSeconds 300 -ScriptBlock {
                $evidence.record = $script:OneCSessionLaunchContext.nativeOperationRecord
                if ($null -ne $evidence.record) { $evidence.record.ownedProcessScopes = $scopes }
                Invoke-NativeProcessAndWaitResult -FilePath $FilePath -Arguments $Arguments `
                    -OneCCreateInfoBaseSyntax:$CreateInfoBase -TimeoutSeconds $TimeoutSeconds `
                    -StdoutPath $stdoutPath -StderrPath $stderrPath `
                    -CompletionGraceSeconds 0 -PostExitProbeSeconds $PostExitProbeSeconds -RequirePostExitProbeOnFailure `
                    -CompletionProbe {
                        param($context)
                        Test-OneCNativeInvocationReleased -ProbeState $probe -ProbeContext $context -LogPath ''
                    }
            }
    } finally {
        $scanReleased = $true
        if ($null -ne $probe.processScanProcess) { $scanReleased = [bool](Stop-DesignerProcessEnumeration -ProbeState $probe).confirmed }
        $released = $scanReleased -and [bool]$probe.processesReleaseConfirmed
        if ($CreateInfoBase -and $null -ne $result) {
            # The native creation owner takes a later live observation. Its
            # unresolved cleanup cannot be replaced by this earlier probe.
            $released = $released -and [bool](Get-StateValue -State $result -Name 'ownedProcessesReleased' -Default $false)
        }
        Confirm-OneCNativeOperationRelease -Record $evidence.record `
            -LauncherExited ([bool](Get-StateValue -State $result -Name 'launcherExited' -Default $false)) `
            -OwnedProcessesReleased $released -Evidence 'vanessa-build-owned-process-release'
    }
    if (-not $released -or $null -eq $result -or $result.timedOut -or $result.completionProbeFailed -or
        $result.postExitProbeTimedOut -or $result.launcherExitCode -ne 0) {
        throw "VANESSA_BUILD_NATIVE_STAGE_FAILED: purpose='$Purpose'; ownedReleased=$released; stdout='$stdoutPath'; stderr='$stderrPath'; result=$($result | ConvertTo-Json -Depth 3 -Compress)"
    }
    return [pscustomobject]@{ purpose = $Purpose; ownedReleased = $released; exitCode = $result.launcherExitCode }
}
