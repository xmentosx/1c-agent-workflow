[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$PlanPath,
    [Parameter(Mandatory = $true)][string]$JunitPath,
    [Parameter(Mandatory = $true)][string]$ResultPath
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"
$utf8NoBom = [System.Text.UTF8Encoding]::new($false)
[Console]::InputEncoding = $utf8NoBom
[Console]::OutputEncoding = $utf8NoBom
$OutputEncoding = $utf8NoBom

if ($env:OS -eq "Windows_NT" -and [string]$PSVersionTable.PSEdition -eq "Desktop") {
    $documents = [Environment]::GetFolderPath([Environment+SpecialFolder]::MyDocuments)
    $userModuleRoot = [IO.Path]::GetFullPath((Join-Path $documents "WindowsPowerShell\Modules"))
    $moduleRoots = @($env:PSModulePath -split ';' | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })
    if (-not @($moduleRoots | Where-Object {
        try { [string]::Equals([IO.Path]::GetFullPath($_).TrimEnd('\'), $userModuleRoot.TrimEnd('\'), [StringComparison]::OrdinalIgnoreCase) }
        catch { $false }
    }).Count) {
        $env:PSModulePath = (@($userModuleRoot) + $moduleRoots) -join ';'
    }
}

$plan = Get-Content -LiteralPath $PlanPath -Raw -Encoding UTF8 | ConvertFrom-Json
$fixtureRuntimeRoot = Join-Path ([System.IO.Path]::GetTempPath()) ("itl-pester-worker-{0}-{1}" -f [int]$plan.worker, [guid]::NewGuid().ToString("N"))
$env:ITL_ONDEMAND_MCP_INSTALL_ROOT = Join-Path $fixtureRuntimeRoot "ondemand"
$env:ITL_TEST_EXECUTION_GUARD_FALLBACK_ROOT = Join-Path $fixtureRuntimeRoot "execution-guards-v2"
$startedAt = [DateTime]::UtcNow
$stopwatch = [System.Diagnostics.Stopwatch]::StartNew()
$result = $null
$failure = $null
try {
    Import-Module Pester -MinimumVersion 5.0.0 -Force
    $configuration = New-PesterConfiguration
    $configuration.Run.Path = @($plan.paths)
    $configuration.Run.PassThru = $true
    $configuration.Output.Verbosity = "Detailed"
    $configuration.TestResult.Enabled = $true
    $configuration.TestResult.OutputFormat = "JUnitXml"
    $configuration.TestResult.OutputPath = $JunitPath
    # Test files own their error policy. In particular, native tools such as Git
    # legitimately write progress to stderr, which PowerShell must not promote
    # to a terminating RemoteException merely because the shard host is strict.
    $previousErrorActionPreference = $ErrorActionPreference
    $ErrorActionPreference = "Continue"
    try {
        $result = Invoke-Pester -Configuration $configuration
    } finally {
        $ErrorActionPreference = $previousErrorActionPreference
    }
    if ([string]$result.Result -ne "Passed") {
        throw "Pester shard $($plan.worker) did not pass: result=$($result.Result), failed=$($result.FailedCount)."
    }
} catch {
    $failure = $_.Exception.Message
} finally {
    [Environment]::SetEnvironmentVariable("ITL_ONDEMAND_MCP_INSTALL_ROOT", $null, "Process")
    [Environment]::SetEnvironmentVariable("ITL_TEST_EXECUTION_GUARD_FALLBACK_ROOT", $null, "Process")
    if (Test-Path -LiteralPath $fixtureRuntimeRoot -PathType Container) {
        Remove-Item -LiteralPath $fixtureRuntimeRoot -Recurse -Force -ErrorAction SilentlyContinue
    }
    $stopwatch.Stop()
    $payload = [ordered]@{
        schemaVersion = 1
        worker = [int]$plan.worker
        status = $(if ($failure) { "failed" } else { "passed" })
        startedAt = $startedAt.ToString("o")
        finishedAt = [DateTime]::UtcNow.ToString("o")
        durationMs = [int64]$stopwatch.ElapsedMilliseconds
        pesterVersion = $(if (Get-Module Pester) { [string](Get-Module Pester | Select-Object -First 1 -ExpandProperty Version) } else { "" })
        paths = @($plan.paths)
        junitPath = $JunitPath
        passed = $(if ($result) { [int]$result.PassedCount } else { 0 })
        failed = $(if ($result) { [int]$result.FailedCount } else { 1 })
        skipped = $(if ($result) { [int]$result.SkippedCount } else { 0 })
        error = $failure
    }
    [System.IO.File]::WriteAllText($ResultPath, (($payload | ConvertTo-Json -Depth 8) + [Environment]::NewLine), [System.Text.UTF8Encoding]::new($false))
}

if ($failure) { [Console]::Error.WriteLine($failure); exit 1 }
